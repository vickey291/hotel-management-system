<?php
// POST JSON {type, table_id, room_id, notes, discount, items:[{id, variant_id, qty, addons:[addon_id], note}]}
require_once __DIR__ . '/../../includes/functions.php';
header('Content-Type: application/json');
if (!user() || !can('pos')) { http_response_code(403); echo json_encode(['ok' => false, 'error' => 'Not allowed']); exit; }
csrf_check();
$in = json_decode(file_get_contents('php://input'), true) ?: [];
$pdo = db();
try {
    $type = $in['type'] ?? '';
    if (!isset(ORDER_TYPES[$type])) throw new RuntimeException('Choose an order type.');
    $items = $in['items'] ?? [];
    if (!$items) throw new RuntimeException('Cart is empty.');
    $pdo->beginTransaction();
    $tableId = null; $roomId = null; $bookingId = null; $guestId = null;
    if ($type === 'dine_in') {
        $tableId = (int)($in['table_id'] ?? 0);
        if (!val('SELECT id FROM restaurant_tables WHERE id=? AND is_active=1', [$tableId])) throw new RuntimeException('Select a table.');
    } elseif ($type === 'room_service') {
        $roomId = (int)($in['room_id'] ?? 0);
        $br = row("SELECT b.id, b.guest_id FROM booking_rooms br JOIN bookings b ON b.id=br.booking_id WHERE br.room_id=? AND br.room_status='checked_in' AND b.booking_status='checked_in' LIMIT 1", [$roomId]);
        if (!$br) throw new RuntimeException('That room has no checked-in guest, so room service cannot be charged.');
        $bookingId = (int)$br['id']; $guestId = (int)$br['guest_id'];
    }
    $sub = 0; $lines = [];
    foreach ($items as $it) {
        $m = row('SELECT * FROM menu_items WHERE id=? AND is_available=1 FOR UPDATE', [(int)$it['id']]);
        if (!$m) throw new RuntimeException('An item in the cart is no longer available.');
        $qty = max(1, (int)$it['qty']); $price = (float)$m['sale_price']; $name = $m['item_name']; $vid = null;
        if (!empty($it['variant_id'])) {
            $v = row('SELECT * FROM menu_item_variants WHERE id=? AND menu_item_id=? AND is_active=1', [(int)$it['variant_id'], $m['id']]);
            if (!$v) throw new RuntimeException('Invalid variant.');
            $price = (float)$v['price']; $name .= ' (' . $v['variant_name'] . ')'; $vid = (int)$v['id'];
        }
        $adds = [];
        foreach ((array)($it['addons'] ?? []) as $aid) {
            $a = row('SELECT a.* FROM menu_addons a JOIN menu_item_addons x ON x.addon_id=a.id WHERE a.id=? AND x.menu_item_id=? AND a.is_active=1', [(int)$aid, $m['id']]);
            if ($a) { $adds[] = $a; $price += (float)$a['addon_price']; }
        }
        if ($m['is_stock_managed']) {
            if ($m['stock_quantity'] < $qty) throw new RuntimeException("Not enough stock for {$m['item_name']} (left: {$m['stock_quantity']}).");
            q('UPDATE menu_items SET stock_quantity = stock_quantity - ? WHERE id=?', [$qty, $m['id']]);
        }
        $total = round($price * $qty, 2); $sub += $total;
        $lines[] = [$m['id'], $vid, $name, $qty, $price, $total, mb_substr(trim($it['note'] ?? ''), 0, 250), $adds];
    }
    $disc = min(max(0, (float)($in['discount'] ?? 0)), $sub);
    $net = $sub - $disc;
    $tax = $type === 'room_service' ? 0 : round($net * (float)setting('restaurant_tax_percent', 0) / 100, 2);
    $svc = $type === 'dine_in' ? round($net * (float)setting('service_charge_percent', 0) / 100, 2) : 0;
    $grand = round($net + $tax + $svc, 2);
    q('INSERT INTO orders (order_number, order_type, guest_id, booking_id, room_id, table_id, order_status, subtotal, discount, tax, service_charges, grand_total, notes, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [next_number('ORD-', 'orders'), $type, $guestId, $bookingId, $roomId, $tableId, 'open', $sub, $disc, $tax, $svc, $grand, mb_substr(trim($in['notes'] ?? ''), 0, 250), user()['id']]);
    $oid = (int)$pdo->lastInsertId();
    foreach ($lines as [$mid, $vid, $name, $qty, $price, $total, $note, $adds]) {
        q('INSERT INTO order_items (order_id, menu_item_id, variant_id, item_name, quantity, unit_price, total_price, item_notes) VALUES (?,?,?,?,?,?,?,?)', [$oid, $mid, $vid, $name, $qty, $price, $total, $note]);
        $oiid = (int)$pdo->lastInsertId();
        foreach ($adds as $a) q('INSERT INTO order_item_addons (order_item_id, addon_name, addon_price) VALUES (?,?,?)', [$oiid, $a['addon_name'], $a['addon_price']]);
    }
    q('INSERT INTO kitchen_orders (order_id) VALUES (?)', [$oid]);
    if ($tableId) q("UPDATE restaurant_tables SET status='occupied' WHERE id=?", [$tableId]);
    if ($bookingId) rebuild_invoice($bookingId);
    audit('create', 'orders', $oid);
    $pdo->commit();
    echo json_encode(['ok' => true, 'order_id' => $oid, 'url' => url('modules/orders/details.php?id=' . $oid), 'kitchen_token' => url('print/kitchen_token.php?id=' . $oid)]);
} catch (Throwable $ex) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['ok' => false, 'error' => $ex->getMessage()]);
}
