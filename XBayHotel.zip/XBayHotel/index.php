<?php
require_once __DIR__ . '/includes/functions.php';
if (user()) redirect('modules/dashboard/');
$dbOk = true; $types = []; $cats = [];
try {
    $types = rows("SELECT t.*, (SELECT COUNT(*) FROM rooms r WHERE r.room_type_id=t.id AND r.is_active=1) AS room_count FROM room_types t WHERE t.is_active=1 AND t.booking_mode <> 'monthly' ORDER BY t.default_price");
    $cats = rows('SELECT category_name FROM menu_categories WHERE is_active=1 ORDER BY sort_order LIMIT 12');
} catch (Throwable $ex) { $dbOk = false; }
$H = hotel();
?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($H['hotel_name']) ?> &middot; <?= e($H['tagline']) ?> &middot; Kotli, Azad Kashmir</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= e(url('assets/css/style.css')) ?>" rel="stylesheet"></head>
<body>
<nav class="site-nav navbar navbar-dark navbar-expand-md"><div class="container">
  <a class="navbar-brand d-flex align-items-center gap-2" href="#"><span class="brand-mark">XB</span><strong style="letter-spacing:2px"><?= e(strtoupper($H['hotel_name'])) ?></strong></a>
  <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nv"><span class="navbar-toggler-icon"></span></button>
  <div class="collapse navbar-collapse" id="nv"><ul class="navbar-nav ms-auto align-items-md-center gap-md-2">
    <li class="nav-item"><a class="nav-link" href="#rooms">Rooms</a></li><li class="nav-item"><a class="nav-link" href="#restaurant">Restaurant</a></li>
    <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
    <li class="nav-item"><a class="btn btn-gold btn-sm" href="<?= e(url('login.php')) ?>"><i class="bi bi-box-arrow-in-right me-1"></i>Staff Login</a></li>
  </ul></div></div></nav>
<section class="hero"><div class="container text-center">
  <div class="tag mb-3">Kotli &middot; Azad Kashmir</div>
  <h1 class="display-3"><?= e(strtoupper($H['hotel_name'])) ?></h1>
  <p class="lead mb-1"><?= e($H['tagline']) ?></p>
  <p class="text-white-50">Rooms &middot; Restaurant &middot; Bookings &middot; Monthly Stay</p>
  <a href="#rooms" class="btn btn-gold btn-lg mt-3 me-2">Our Rooms</a>
  <?php if ($H['phone']): ?><a href="tel:<?= e($H['phone']) ?>" class="btn btn-outline-light btn-lg mt-3"><i class="bi bi-telephone me-1"></i><?= e($H['phone']) ?></a><?php endif; ?>
  <?php if (!$dbOk): ?><div class="alert alert-warning mt-5 d-inline-block">Database is not set up yet. Import <code>database/schema.sql</code> in phpMyAdmin and reload.</div><?php endif; ?>
</div></section>
<section class="sect" id="rooms"><div class="container"><h2>Rooms &amp; Stay</h2><div class="bar"></div>
  <div class="row g-4">
  <?php foreach ($types as $t): ?>
    <div class="col-md-4"><div class="feature"><i class="bi bi-door-open"></i><h5 class="mt-2"><?= e($t['type_name']) ?></h5>
      <p class="text-muted small mb-2"><?= e($t['description']) ?></p>
      <div class="d-flex justify-content-between"><span class="fw-bold" style="color:var(--gold-d)">From <?= money($t['default_price']) ?> / night</span><span class="small text-muted"><?= (int)$t['room_count'] ?> rooms</span></div></div></div>
  <?php endforeach; ?>
  <div class="col-md-4"><div class="feature"><i class="bi bi-calendar-month"></i><h5 class="mt-2">Monthly Rooms</h5><p class="text-muted small mb-0">Permanent rooms on monthly rent for long stays. Contact reception for availability.</p></div></div>
  </div></div></section>
<section class="sect bg-white" id="restaurant"><div class="container"><h2>Restaurant</h2><div class="bar"></div>
  <p class="text-muted">Dine-in, room service and takeaway. Fresh BBQ, Pakistani, Chinese and fast food.</p>
  <div class="d-flex flex-wrap gap-2"><?php foreach ($cats as $c): ?><span class="badge rounded-pill text-bg-light border px-3 py-2"><?= e($c['category_name']) ?></span><?php endforeach; ?></div></div></section>
<section class="sect" id="contact"><div class="container"><h2>Contact</h2><div class="bar"></div>
  <div class="row g-4"><div class="col-md-4"><div class="feature"><i class="bi bi-geo-alt"></i><p class="mb-0 mt-2"><?= e($H['address']) ?><br><?= e($H['city']) ?>, <?= e($H['country']) ?></p></div></div>
  <div class="col-md-4"><div class="feature"><i class="bi bi-telephone"></i><p class="mb-0 mt-2"><?= e($H['phone']) ?></p></div></div>
  <div class="col-md-4"><div class="feature"><i class="bi bi-envelope"></i><p class="mb-0 mt-2"><?= e($H['email']) ?></p></div></div></div></div></section>
<footer class="site-foot text-center"><div class="container">&copy; <?= date('Y') ?> <?= e($H['hotel_name']) ?> &mdash; <?= e(APP_FULL_NAME) ?>, Kotli, Azad Kashmir</div></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html>
