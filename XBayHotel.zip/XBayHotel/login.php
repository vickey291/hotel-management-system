<?php
require_once __DIR__ . '/includes/functions.php';
if (user()) redirect('modules/dashboard/');
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    try {
        $fails = (int)val("SELECT COUNT(*) FROM login_logs WHERE ip_address=? AND status='failed' AND login_time > DATE_SUB(NOW(), INTERVAL 15 MINUTE)", [$ip]);
        if ($fails >= 5) { $err = 'Too many failed attempts. Please wait 15 minutes and try again.'; }
        else {
            $un = trim($_POST['username'] ?? ''); $pw = $_POST['password'] ?? '';
            $u = row('SELECT u.*, r.role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.username=? AND u.is_active=1', [$un]);
            $ok = false;
            if ($u) {
                if ($u['password_hash'] === 'RESET_ON_FIRST_LOGIN') {      // first run: default admin password
                    if ($pw === 'Admin@123') { $ok = true; q('UPDATE users SET password_hash=? WHERE id=?', [password_hash($pw, PASSWORD_DEFAULT), $u['id']]); $_SESSION['must_change_pw'] = true; }
                } elseif (password_verify($pw, $u['password_hash'])) $ok = true;
            }
            if ($ok) {
                session_regenerate_id(true);
                unset($u['password_hash']);
                $_SESSION['user'] = $u;
                load_permissions((int)$u['role_id']);
                q("INSERT INTO login_logs (user_id, username, ip_address, status) VALUES (?,?,?,'success')", [$u['id'], $un, $ip]);
                $_SESSION['login_log_id'] = (int)db()->lastInsertId();
                if (!empty($_SESSION['must_change_pw'])) { flash('Welcome! Please change the default password now.', 'warning'); redirect('modules/staff/profile.php'); }
                redirect($u['role_id'] == 5 ? 'modules/kitchen/' : 'modules/dashboard/');
            }
            q("INSERT INTO login_logs (user_id, username, ip_address, status) VALUES (?,?,?,'failed')", [$u['id'] ?? null, $un, $ip]);
            $err = 'Invalid username or password.';
        }
    } catch (Throwable $ex) { $err = 'Database not ready. Import database/schema.sql first. (' . $ex->getMessage() . ')'; }
}
$H = hotel();
?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login &middot; <?= e($H['hotel_name']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= e(url('assets/css/style.css')) ?>" rel="stylesheet"></head>
<body class="login-bg">
<div class="login-card">
  <div class="text-center mb-4">
    <?php if (!empty($H['logo'])): ?><img src="<?= e(url('uploads/' . $H['logo'])) ?>" height="64" alt=""><?php else: ?><span class="brand-mark mx-auto" style="height:60px;width:60px;font-size:1.4rem">XB</span><?php endif; ?>
    <h4 class="mt-3 mb-0 fw-bold" style="letter-spacing:2px"><?= e(strtoupper($H['hotel_name'])) ?></h4>
    <div class="small text-uppercase" style="color:var(--gold-d);letter-spacing:3px"><?= e($H['tagline']) ?></div>
    <div class="text-muted small mt-1">Hotel Management &amp; POS System</div>
  </div>
  <?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
  <form method="post" autocomplete="off">
    <?= csrf_field() ?>
    <div class="mb-3"><label class="form-label">Username</label><div class="input-group"><span class="input-group-text"><i class="bi bi-person"></i></span><input name="username" class="form-control" required autofocus></div></div>
    <div class="mb-3"><label class="form-label">Password</label><div class="input-group"><span class="input-group-text"><i class="bi bi-lock"></i></span><input type="password" name="password" class="form-control" required></div></div>
    <button class="btn btn-gold w-100 py-2">Sign in</button>
  </form>
  <div class="text-center mt-3"><a href="<?= e(url('')) ?>" class="small text-muted text-decoration-none">&larr; Back to website</a></div>
</div></body></html>
