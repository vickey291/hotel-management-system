-- Demo data (optional). Import AFTER schema.sql.
USE xbay_hotel_db;
INSERT INTO rooms (room_number, room_type_id, floor_number, room_name, capacity, room_price, description) VALUES
('101', 1, 'First Floor', 'Standard 101', 3, 6000, 'AC, TV, attached bath'),
('102', 1, 'First Floor', 'Standard 102', 3, 6000, 'AC, TV, attached bath'),
('103', 3, 'Ground Floor', 'VIP 103', 4, 8000, 'VIP suite'),
('104', 3, 'Ground Floor', 'VIP 104', 4, 8000, 'VIP suite'),
('105', 2, 'First Floor', 'Deluxe 105', 4, 7500, 'Deluxe family room'),
('201', 4, 'Second Floor', 'Monthly 201', 2, 25000, 'Permanent rent room'),
('202', 4, 'Second Floor', 'Monthly 202', 2, 22000, 'Permanent rent room');

INSERT INTO restaurant_tables (table_number, table_name, floor, seating_capacity) VALUES
('T1','Table 1','Ground',4),('T2','Table 2','Ground',4),('T3','Table 3','Ground',6),('T4','Table 4','Ground',2),
('T5','Table 5','Terrace',4),('T6','Table 6','Terrace',8);

INSERT INTO menu_addons (addon_name, addon_price) VALUES ('Extra Cheese',100),('Extra Sauce',50),('Raita',40);

INSERT INTO menu_items (category_id, item_name, item_code, description, purchase_price, sale_price) VALUES
(1,'Zinger Burger','FF001','Crispy chicken burger',250,450),
(1,'Club Sandwich','FF002','Grilled club sandwich',220,400),
(1,'Pizza','FF003','Chicken tikka pizza',500,900),
(2,'Chicken Tikka (Leg)','BB001','Charcoal grilled',200,380),
(2,'Seekh Kabab (4 pcs)','BB002','Beef seekh kabab',250,450),
(3,'Chicken Chowmein','CH001','Wok tossed noodles',250,500),
(4,'Chicken Karahi (Half)','PK001','Desi karahi',900,1500),
(4,'Daal Mash','PK002','Home-style daal',150,300),
(4,'Roti / Naan','PK003','Fresh tandoor',10,30),
(5,'Paratha with Chai','BF001','Desi breakfast',100,250),
(5,'Halwa Puri','BF002','Traditional breakfast',150,300),
(8,'Fresh Lime','BV001','',40,120),
(9,'Cold Drink 500ml','CD001','',70,120),
(10,'Doodh Pati Chai','TC001','',30,100),
(10,'Coffee','TC002','',70,200),
(11,'Kheer','DS001','',80,200);

INSERT INTO menu_item_variants (menu_item_id, variant_name, price) VALUES
(3,'Small',600),(3,'Medium',900),(3,'Large',1300),(7,'Full',2800);

INSERT INTO menu_item_addons (menu_item_id, addon_id) VALUES (3,1),(3,2),(1,1),(1,2),(2,2),(8,3);
