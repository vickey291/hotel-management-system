<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('billing');
$id = (int)($_GET['id'] ?? 0);
$i = row('SELECT i.*, g.full_name, g.phone FROM invoices i LEFT JOIN guests g ON g.id=i.guest_id WHERE i.id=?', [$id]);
if (!$i) { flash('Invoice not found.', 'danger'); redirect('modules/billing/'); }
if ($i['booking_id'] && in_array($i['invoice_type'], ['room']) ) { rebuild_invoice((int)$i['booking_id']); $i = row('SELECT i.*, g.full_name, g.phone FROM invoices i LEFT JOIN guests g ON g.id=i.guest_id WHERE i.id=?', [$id]); }
$items = rows('SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY id', [$id]);
$pays = rows('SELECT p.*, u.full_name AS who FROM payments p LEFT JOIN users u ON u.id=p.received_by WHERE p.invoice_id=? ORDER BY p.id', [$id]);
$pageTitle = 'Invoice ' . $i['invoice_number'];
include ROOT . '/includes/header.php';
?>
<div class="d-flex flex-wrap gap-2 mb-3 align-items-center"><a href="index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a><h4 class="mb-0"><?= e($i['invoice_number']) ?></h4><?= badge(ucfirst($i['invoice_status']), status_class($i['invoice_status'])) ?>
 <div class="ms-auto d-flex gap-2 flex-wrap">
  <?php foreach ([80 => '80mm', 58 => '58mm', 'a4' => 'A4'] as $sz => $l): ?><a target="_blank" class="btn btn-sm btn-outline-dark" href="<?= e(url('print/invoice.php?id=' . $id . '&size=' . $sz)) ?>"><i class="bi bi-printer me-1"></i><?= $l ?></a><?php endforeach; ?>
  <?php if ($i['booking_id']): ?><a class="btn btn-sm btn-outline-dark" href="<?= e(url('modules/bookings/details.php?id=' . $i['booking_id'])) ?>">Booking</a><?php endif; ?></div></div>
<div class="row g-3"><div class="col-lg-8">
 <div class="card mb-3"><div class="card-header fw-semibold">Items &mdash; <?= e(ucwords(str_replace('_', ' ', $i['invoice_type']))) ?> invoice &middot; <?= e($i['full_name'] ?: 'Walk-in') ?> &middot; <?= e(dt($i['invoice_date'])) ?></div>
 <div class="table-responsive"><table class="table mb-0"><thead><tr><th>Description</th><th class="text-end">Qty</th><th class="text-end">Price</th><th class="text-end">Total</th></tr></thead><tbody>
 <?php foreach ($items as $x): ?><tr><td><?= e($x['description']) ?></td><td class="text-end"><?= e($x['quantity'] + 0) ?></td><td class="text-end"><?= money($x['unit_price']) ?></td><td class="text-end"><?= money($x['total_price']) ?></td></tr><?php endforeach; ?></tbody>
 <tfoot><tr><td colspan="3" class="text-end">Subtotal</td><td class="text-end"><?= money($i['subtotal']) ?></td></tr>
 <?php if ($i['discount'] > 0): ?><tr><td colspan="3" class="text-end">Discount</td><td class="text-end">- <?= money($i['discount']) ?></td></tr><?php endif; ?>
 <?php if ($i['tax_amount'] > 0): ?><tr><td colspan="3" class="text-end">Tax</td><td class="text-end"><?= money($i['tax_amount']) ?></td></tr><?php endif; ?>
 <?php if ($i['service_charges'] > 0): ?><tr><td colspan="3" class="text-end">Service charges</td><td class="text-end"><?= money($i['service_charges']) ?></td></tr><?php endif; ?>
 <tr class="fw-bold"><td colspan="3" class="text-end">Grand total</td><td class="text-end"><?= money($i['grand_total']) ?></td></tr></tfoot></table></div></div>
 <div class="card"><div class="card-header fw-semibold">Payments</div><div class="table-responsive"><table class="table table-sm mb-0"><tbody>
 <?php foreach ($pays as $p): ?><tr><td><?= e($p['payment_number']) ?></td><td><?= e(dt($p['payment_date'], 'd M, h:i A')) ?></td><td><?= e(PAYMENT_METHODS[$p['payment_method']] ?? '') ?></td><td><?= e($p['notes']) ?></td><td class="text-end"><?= money($p['amount']) ?></td><td><a target="_blank" href="<?= e(url('print/payment_receipt.php?id=' . $p['id'])) ?>"><i class="bi bi-printer"></i></a></td></tr><?php endforeach; if (!$pays) echo '<tr><td class="text-muted">No payments yet.</td></tr>'; ?></tbody></table></div></div>
</div><div class="col-lg-4"><div class="card"><div class="card-body">
 <div class="d-flex justify-content-between"><span>Total</span><b><?= money($i['grand_total']) ?></b></div><div class="d-flex justify-content-between text-success"><span>Paid</span><b><?= money($i['paid_amount']) ?></b></div>
 <div class="d-flex justify-content-between text-danger fs-5"><span>Remaining</span><b><?= money($i['remaining_amount']) ?></b></div>
 <?php if ($i['remaining_amount'] > 0 && can('payments')): ?><hr><form method="post" action="<?= e(url('modules/payments/receive.php')) ?>" class="row g-2"><?= csrf_field() ?><input type="hidden" name="invoice_id" value="<?= $id ?>"><input type="hidden" name="back" value="<?= e($_SERVER['REQUEST_URI']) ?>">
  <div class="col-12"><label class="small">Amount</label><input type="number" step="any" min="1" max="<?= e($i['remaining_amount'] + 0) ?>" name="amount" value="<?= e($i['remaining_amount'] + 0) ?>" class="form-control" required></div>
  <div class="col-12"><select name="payment_method" class="form-select"><?php foreach (PAYMENT_METHODS as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
  <div class="col-12"><input name="reference" class="form-control" placeholder="Reference (optional)"></div>
  <div class="col-12"><button class="btn btn-gold w-100">Receive payment</button></div></form><?php endif; ?>
</div></div></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
