<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('billing');
$pageTitle = 'Billing';
$st = $_GET['status'] ?? ''; $ty = $_GET['type'] ?? ''; $s = trim($_GET['q'] ?? '');
$sql = 'SELECT i.*, g.full_name FROM invoices i LEFT JOIN guests g ON g.id=i.guest_id WHERE 1=1'; $p = [];
if (in_array($st, ['paid', 'unpaid', 'partial', 'pending'])) { $sql .= ' AND i.invoice_status=?'; $p[] = $st; }
if (in_array($ty, ['room', 'restaurant', 'room_service', 'monthly', 'checkout'])) { $sql .= ' AND i.invoice_type=?'; $p[] = $ty; }
if ($s !== '') { $sql .= ' AND (i.invoice_number LIKE ? OR g.full_name LIKE ?)'; $p = array_merge($p, ["%$s%", "%$s%"]); }
$list = rows($sql . ' ORDER BY i.id DESC LIMIT 300', $p);
include ROOT . '/includes/header.php';
?>
<form class="d-flex flex-wrap gap-2 mb-3"><input name="q" value="<?= e($s) ?>" class="form-control" style="max-width:240px" placeholder="Invoice no / guest">
 <select name="type" class="form-select w-auto" onchange="this.form.submit()"><option value="">All types</option><?php foreach (['room' => 'Room', 'checkout' => 'Final checkout', 'restaurant' => 'Restaurant', 'room_service' => 'Room service'] as $k => $l): ?><option value="<?= $k ?>" <?= $ty === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select>
 <select name="status" class="form-select w-auto" onchange="this.form.submit()"><option value="">All status</option><?php foreach (['paid', 'unpaid', 'partial', 'pending'] as $k): ?><option value="<?= $k ?>" <?= $st === $k ? 'selected' : '' ?>><?= ucfirst($k) ?></option><?php endforeach; ?></select>
 <button class="btn btn-outline-dark">Search</button><a href="<?= e(url('modules/monthly_rooms/rent.php')) ?>" class="btn btn-outline-dark ms-auto">Monthly invoices</a></form>
<div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Invoice</th><th>Date</th><th>Type</th><th>Guest</th><th>Status</th><th class="text-end">Total</th><th class="text-end">Paid</th><th class="text-end">Remaining</th><th></th></tr></thead><tbody>
<?php foreach ($list as $i): ?><tr><td><a class="fw-semibold" href="details.php?id=<?= (int)$i['id'] ?>"><?= e($i['invoice_number']) ?></a></td><td><?= e(dt($i['invoice_date'], 'd M y')) ?></td><td><?= e(ucwords(str_replace('_', ' ', $i['invoice_type']))) ?></td><td><?= e($i['full_name'] ?: 'Walk-in') ?></td>
 <td><?= badge(ucfirst($i['invoice_status']), status_class($i['invoice_status'])) ?></td><td class="text-end"><?= money($i['grand_total']) ?></td><td class="text-end text-success"><?= money($i['paid_amount']) ?></td><td class="text-end text-danger"><?= money($i['remaining_amount']) ?></td>
 <td class="text-end"><a class="btn btn-sm btn-outline-dark" href="details.php?id=<?= (int)$i['id'] ?>"><i class="bi bi-eye"></i></a></td></tr>
<?php endforeach; if (!$list) echo '<tr><td colspan="9" class="text-center text-muted py-4">No invoices.</td></tr>'; ?></tbody></table></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
