<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('bookings');
$bid = (int)($_GET['booking_id'] ?? $_POST['booking_id'] ?? 0);
$b = row('SELECT b.*, g.full_name, g.phone FROM bookings b JOIN guests g ON g.id=b.guest_id WHERE b.id=?', [$bid]);
if (!$b || $b['booking_status'] !== 'checked_in') { flash('Only checked-in bookings can be checked out.', 'warning'); redirect('modules/bookings/'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = db();
    try {
        $pdo->beginTransaction();
        $iid = rebuild_invoice($bid);
        $payNow = round((float)($_POST['pay_now'] ?? 0), 2);
        if ($payNow > 0) record_payment($iid, $payNow, array_key_exists($_POST['payment_method'] ?? '', PAYMENT_METHODS) ? $_POST['payment_method'] : 'cash', null, 'Payment at check-out');
        $inv = row('SELECT * FROM invoices WHERE id=?', [$iid]);
        $mgr = in_array((int)user()['role_id'], [1, 2], true);
        if ($inv['remaining_amount'] > 0.009 && !($mgr && !empty($_POST['allow_balance']))) throw new RuntimeException('Bill is not cleared. Remaining: ' . money($inv['remaining_amount']) . '. Receive the payment first' . ($mgr ? ' (or tick "allow check-out with balance").' : '.'));
        // rooms that never arrived are released
        q("UPDATE booking_rooms SET room_status='cancelled' WHERE booking_id=? AND room_status='reserved'", [$bid]);
        foreach (rows("SELECT * FROM booking_rooms WHERE booking_id=? AND room_status='checked_in'", [$bid]) as $br) {
            q("UPDATE booking_rooms SET room_status='checked_out' WHERE id=?", [$br['id']]);
            if (!val('SELECT id FROM checkin_checkout WHERE booking_room_id=?', [$br['id']])) q('INSERT INTO checkin_checkout (booking_room_id, actual_checkin) VALUES (?, NOW())', [$br['id']]);
            q('UPDATE checkin_checkout SET actual_checkout=NOW(), checked_out_by=?, checkout_notes=? WHERE booking_room_id=?', [user()['id'], trim($_POST['notes'] ?? ''), $br['id']]);
            q("UPDATE rooms SET cleaning_status='dirty' WHERE id=?", [$br['room_id']]);
        }
        q("UPDATE orders SET order_status='completed' WHERE booking_id=? AND order_type='room_service' AND order_status='open'", [$bid]);
        q("UPDATE bookings SET booking_status='checked_out' WHERE id=?", [$bid]);
        q("UPDATE invoices SET invoice_type='checkout' WHERE id=?", [$iid]);
        rebuild_invoice($bid);
        q('INSERT INTO booking_status_history (booking_id, old_status, new_status, changed_by, remarks) VALUES (?,?,?,?,?)', [$bid, 'checked_in', 'checked_out', user()['id'], 'Checked out. Rooms marked dirty for cleaning.']);
        audit('checkout', 'bookings', $bid, $b['booking_number']);
        $pdo->commit();
        flash('Check-out complete. Rooms are marked "dirty" and become Available after cleaning.');
        redirect('modules/billing/details.php?id=' . $iid);
    } catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); flash($ex->getMessage(), 'danger'); }
}
$iid = rebuild_invoice($bid);
$inv = row('SELECT * FROM invoices WHERE id=?', [$iid]);
$items = rows('SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY id', [$iid]);
$overstay = strtotime($b['checkout_datetime']) < time() - 3600;
$pageTitle = 'Check-out ' . $b['booking_number'];
include ROOT . '/includes/header.php';
?>
<div class="row g-3"><div class="col-lg-7"><div class="card"><div class="card-header fw-semibold">Final bill &mdash; <?= e($b['full_name']) ?> (<?= e($b['booking_number']) ?>)</div>
<?php if ($overstay): ?><div class="alert alert-warning m-3 mb-0 py-2 small">Planned check-out was <?= e(dt($b['checkout_datetime'])) ?>. If the guest stayed longer, <a href="<?= e(url('modules/bookings/edit.php?id=' . $bid)) ?>">extend the stay</a> first so the extra nights are billed.</div><?php endif; ?>
<table class="table mb-0"><tbody><?php foreach ($items as $x): ?><tr><td><?= e($x['description']) ?></td><td class="text-end"><?= money($x['total_price']) ?></td></tr><?php endforeach; ?>
 <tr><td class="text-end">Discount</td><td class="text-end">- <?= money($inv['discount']) ?></td></tr><tr><td class="text-end">Tax</td><td class="text-end"><?= money($inv['tax_amount']) ?></td></tr>
 <tr class="fw-bold"><td class="text-end">Grand total</td><td class="text-end"><?= money($inv['grand_total']) ?></td></tr><tr class="text-success"><td class="text-end">Paid</td><td class="text-end"><?= money($inv['paid_amount']) ?></td></tr>
 <tr class="text-danger fw-bold"><td class="text-end">Remaining</td><td class="text-end"><?= money($inv['remaining_amount']) ?></td></tr></tbody></table></div></div>
<div class="col-lg-5"><div class="card"><div class="card-header fw-semibold">Complete check-out</div><div class="card-body">
 <form method="post" class="row g-3"><?= csrf_field() ?><input type="hidden" name="booking_id" value="<?= $bid ?>">
  <div class="col-7"><label class="form-label">Receive now</label><input type="number" step="any" min="0" max="<?= e($inv['remaining_amount'] + 0) ?>" name="pay_now" value="<?= e($inv['remaining_amount'] + 0) ?>" class="form-control"></div>
  <div class="col-5"><label class="form-label">Method</label><select name="payment_method" class="form-select"><?php foreach (PAYMENT_METHODS as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
  <div class="col-12"><label class="form-label">Check-out notes</label><input name="notes" class="form-control"></div>
  <?php if (in_array((int)user()['role_id'], [1, 2], true)): ?><div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="allow_balance" value="1" id="ab"><label for="ab" class="form-check-label small">Allow check-out with unpaid balance (manager override)</label></div></div><?php endif; ?>
  <div class="col-12"><button class="btn btn-danger w-100 py-2" onclick="return confirm('Complete check-out for all rooms of this booking?')"><i class="bi bi-box-arrow-right me-1"></i>Pay &amp; Check-out</button></div>
 </form></div></div></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
