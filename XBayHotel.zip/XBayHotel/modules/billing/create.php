<?php
// Generates / refreshes the running bill of a booking and opens it.
require_once __DIR__ . '/../../includes/functions.php';
require_perm('billing');
$bid = (int)($_GET['booking_id'] ?? 0);
if (!$bid || !val('SELECT id FROM bookings WHERE id=?', [$bid])) { flash('Pick a booking first.', 'warning'); redirect('modules/bookings/'); }
$iid = rebuild_invoice($bid);
redirect('modules/billing/details.php?id=' . $iid);
