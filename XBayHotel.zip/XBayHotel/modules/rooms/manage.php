<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = [
 'title' => 'Manage Rooms', 'table' => 'rooms', 'perm' => 'rooms',
 'select' => 'SELECT r.*, t.type_name FROM rooms r JOIN room_types t ON t.id=r.room_type_id ORDER BY r.room_number',
 'columns' => ['room_number' => 'Room', 'type_name' => 'Type', 'floor_number' => 'Floor', 'capacity' => 'Cap.', 'room_price' => 'Price', 'maintenance_status' => 'Maintenance', 'is_active' => 'Status'],
 'format' => ['room_price' => 'money', 'is_active' => 'bool'],
 'toolbar' => '<a class="btn btn-outline-dark" href="index.php"><i class="bi bi-grid me-1"></i>Room cards</a><a class="btn btn-outline-dark" href="../room_types/">Room types</a><a class="btn btn-outline-dark" href="amenities.php">Amenities</a>',
 'fields' => [
  ['name' => 'room_number', 'label' => 'Room number', 'required' => true],
  ['name' => 'room_type_id', 'label' => 'Room type', 'type' => 'select', 'required' => true, 'sql' => 'SELECT id, type_name FROM room_types WHERE is_active=1 ORDER BY type_name'],
  ['name' => 'floor_number', 'label' => 'Floor (e.g. Ground Floor)'],
  ['name' => 'room_name', 'label' => 'Room name'],
  ['name' => 'capacity', 'label' => 'Capacity', 'type' => 'number', 'step' => '1', 'required' => true, 'default' => 2],
  ['name' => 'room_price', 'label' => 'Rent (per night, or per month for monthly rooms)', 'type' => 'number', 'required' => true],
  ['name' => 'maintenance_status', 'label' => 'Maintenance', 'type' => 'select', 'required' => true, 'options' => ['active' => 'Active (usable)', 'maintenance' => 'Under maintenance']],
  ['name' => 'description', 'label' => 'Description'],
  ['name' => 'is_active', 'label' => 'Active', 'type' => 'checkbox'],
 ]];
require ROOT . '/includes/crud.php';
