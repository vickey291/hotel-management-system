<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = ['title' => 'Room Amenities', 'table' => 'room_amenities', 'perm' => 'rooms',
 'select' => 'SELECT * FROM room_amenities ORDER BY amenity_name',
 'columns' => ['amenity_name' => 'Amenity', 'description' => 'Description'],
 'fields' => [['name' => 'amenity_name', 'label' => 'Amenity', 'required' => true], ['name' => 'description', 'label' => 'Description']]];
require ROOT . '/includes/crud.php';
