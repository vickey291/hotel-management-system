<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('rooms');
$id = (int)($_GET['id'] ?? 0);
$r = row('SELECT r.*, t.type_name, t.booking_mode FROM rooms r JOIN room_types t ON t.id=r.room_type_id WHERE r.id=?', [$id]);
if (!$r) { flash('Room not found.', 'danger'); redirect('modules/rooms/'); }
$pageTitle = 'Room ' . $r['room_number'];
[$key, $label, $cls] = room_state($r);
$cur = row("SELECT b.*, g.full_name, g.phone, br.checkin_datetime AS r_in, br.checkout_datetime AS r_out, br.room_rate, br.room_status, br.id AS br_id
            FROM booking_rooms br JOIN bookings b ON b.id=br.booking_id JOIN guests g ON g.id=b.guest_id
            WHERE br.room_id=? AND br.room_status IN ('checked_in','reserved') AND b.booking_status NOT IN ('cancelled','no_show','checked_out')
            ORDER BY (br.room_status='checked_in') DESC, br.checkin_datetime LIMIT 1", [$id]);
$cnic = $cur ? val("SELECT document_number FROM guest_documents WHERE guest_id=? ORDER BY id DESC LIMIT 1", [$cur['guest_id']]) : null;
$charges = $cur ? rows('SELECT * FROM room_charges WHERE booking_id=? ORDER BY id', [$cur['id']]) : [];
$orders = $cur ? rows("SELECT * FROM orders WHERE booking_id=? AND order_type='room_service' AND order_status<>'cancelled'", [$cur['id']]) : [];
$inv = $cur ? row("SELECT * FROM invoices WHERE booking_id=? AND invoice_type IN ('room','checkout') LIMIT 1", [$cur['id']]) : null;
$tenant = $key === 'monthly' ? row("SELECT mt.*, g.full_name, g.phone FROM monthly_tenants mt JOIN guests g ON g.id=mt.guest_id WHERE mt.room_id=? AND mt.tenant_status='active' LIMIT 1", [$id]) : null;
$upcoming = rows("SELECT b.id, b.booking_number, br.checkin_datetime, br.checkout_datetime, g.full_name FROM booking_rooms br JOIN bookings b ON b.id=br.booking_id JOIN guests g ON g.id=b.guest_id WHERE br.room_id=? AND br.room_status='reserved' AND br.checkout_datetime > NOW() AND b.booking_status='confirmed' ORDER BY br.checkin_datetime LIMIT 5", [$id]);
$allAm = rows('SELECT * FROM room_amenities ORDER BY amenity_name');
$myAm = array_column(rows('SELECT amenity_id FROM room_amenity_map WHERE room_id=?', [$id]), 'amenity_id');
include ROOT . '/includes/header.php';
?>
<a href="index.php" class="btn btn-sm btn-outline-secondary mb-3"><i class="bi bi-arrow-left"></i> All rooms</a>
<div class="row g-3">
<div class="col-lg-5"><div class="card h-100"><div class="card-body">
  <div class="d-flex justify-content-between"><h3 class="fw-bold mb-0">Room <?= e($r['room_number']) ?></h3><span class="badge text-bg-<?= $cls ?> align-self-start fs-6"><?= e($label) ?></span></div>
  <dl class="row mt-3 mb-0 small">
    <dt class="col-5">Category</dt><dd class="col-7"><?= e($r['type_name']) ?> (<?= e($r['booking_mode']) ?>)</dd>
    <dt class="col-5">Floor</dt><dd class="col-7"><?= e($r['floor_number']) ?></dd>
    <dt class="col-5">Rent</dt><dd class="col-7"><?= money($r['room_price']) ?> / <?= $r['booking_mode'] === 'monthly' ? 'month' : 'night' ?></dd>
    <dt class="col-5">Capacity</dt><dd class="col-7"><?= (int)$r['capacity'] ?> persons</dd>
    <dt class="col-5">Cleaning</dt><dd class="col-7"><?= e(ucfirst(str_replace('_', ' ', $r['cleaning_status']))) ?></dd>
  </dl><hr>
  <form method="post" action="status.php" class="d-flex gap-2 flex-wrap mb-2"><?= csrf_field() ?><input type="hidden" name="room_id" value="<?= $id ?>"><input type="hidden" name="what" value="cleaning">
    <select name="value" class="form-select form-select-sm w-auto"><?php foreach (['clean' => 'Clean', 'dirty' => 'Dirty', 'in_progress' => 'Cleaning in progress'] as $k => $l): ?><option value="<?= $k ?>" <?= $r['cleaning_status'] === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select>
    <button class="btn btn-sm btn-outline-dark">Update cleaning</button></form>
  <form method="post" action="status.php" class="d-flex gap-2 mb-3"><?= csrf_field() ?><input type="hidden" name="room_id" value="<?= $id ?>"><input type="hidden" name="what" value="maintenance">
    <input type="hidden" name="value" value="<?= $r['maintenance_status'] === 'active' ? 'maintenance' : 'active' ?>">
    <button class="btn btn-sm <?= $r['maintenance_status'] === 'active' ? 'btn-outline-danger' : 'btn-outline-success' ?>"><?= $r['maintenance_status'] === 'active' ? 'Put under maintenance' : 'Mark as usable again' ?></button></form>
  <form method="post" action="status.php"><?= csrf_field() ?><input type="hidden" name="room_id" value="<?= $id ?>"><input type="hidden" name="what" value="amenities">
    <div class="fw-semibold small mb-1">Amenities</div>
    <?php foreach ($allAm as $a): ?><div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="amenity[]" value="<?= (int)$a['id'] ?>" id="am<?= (int)$a['id'] ?>" <?= in_array($a['id'], $myAm) ? 'checked' : '' ?>><label class="form-check-label small" for="am<?= (int)$a['id'] ?>"><?= e($a['amenity_name']) ?></label></div><?php endforeach; ?>
    <div><button class="btn btn-sm btn-outline-dark mt-2">Save amenities</button></div></form>
</div></div></div>
<div class="col-lg-7">
<?php if ($cur): ?>
 <div class="card mb-3"><div class="card-header fw-semibold d-flex justify-content-between"><span><?= $cur['room_status'] === 'checked_in' ? 'Current guest' : 'Next reservation' ?></span><a href="<?= e(url('modules/bookings/details.php?id=' . $cur['id'])) ?>" class="small"><?= e($cur['booking_number']) ?> &rarr;</a></div>
 <div class="card-body"><dl class="row small mb-0">
   <dt class="col-4">Guest</dt><dd class="col-8"><?= e($cur['full_name']) ?> <?= e($cur['phone']) ?></dd>
   <?php if (can('guests')): ?><dt class="col-4">CNIC</dt><dd class="col-8"><?= e($cnic ?: '-') ?></dd><?php endif; ?>
   <dt class="col-4">Check-in</dt><dd class="col-8"><?= e(dt($cur['r_in'])) ?></dd>
   <dt class="col-4">Expected check-out</dt><dd class="col-8"><?= e(dt($cur['r_out'])) ?></dd>
   <dt class="col-4">Room rate</dt><dd class="col-8"><?= money($cur['room_rate']) ?> / night</dd></dl></div></div>
 <div class="card mb-3"><div class="card-header fw-semibold">Services &amp; food</div><div class="card-body p-0"><table class="table table-sm mb-0">
   <?php foreach ($charges as $c): ?><tr><td><?= e(ucfirst(str_replace('_', ' ', $c['charge_type']))) ?> <small class="text-muted"><?= e($c['description']) ?></small></td><td class="text-end"><?= money($c['total_amount']) ?></td></tr><?php endforeach; ?>
   <?php foreach ($orders as $o): ?><tr><td>Food order <a href="<?= e(url('modules/orders/details.php?id=' . $o['id'])) ?>"><?= e($o['order_number']) ?></a></td><td class="text-end"><?= money($o['grand_total']) ?></td></tr><?php endforeach; ?>
   <?php if (!$charges && !$orders): ?><tr><td class="text-muted">No extra charges yet.</td></tr><?php endif; ?></table></div></div>
 <div class="card"><div class="card-body">
   <div class="d-flex justify-content-between"><span>Total bill</span><b><?= money($inv['grand_total'] ?? 0) ?></b></div>
   <div class="d-flex justify-content-between text-success"><span>Paid</span><b><?= money($inv['paid_amount'] ?? 0) ?></b></div>
   <div class="d-flex justify-content-between text-danger"><span>Remaining</span><b><?= money($inv['remaining_amount'] ?? 0) ?></b></div>
   <div class="d-flex gap-2 mt-3 flex-wrap"><a class="btn btn-sm btn-gold" href="<?= e(url('modules/room_services/add_charge.php?booking_id=' . $cur['id'] . '&room_id=' . $id)) ?>">Add charge</a>
   <?php if ($inv): ?><a class="btn btn-sm btn-outline-dark" href="<?= e(url('modules/billing/details.php?id=' . $inv['id'])) ?>">Open bill</a><?php endif; ?>
   <?php if ($cur['room_status'] === 'checked_in'): ?><a class="btn btn-sm btn-outline-danger" href="<?= e(url('modules/billing/checkout.php?booking_id=' . $cur['id'])) ?>">Check-out</a><?php endif; ?></div>
 </div></div>
<?php elseif ($tenant): ?>
 <div class="card"><div class="card-header fw-semibold">Monthly tenant</div><div class="card-body"><dl class="row small mb-2">
   <dt class="col-4">Tenant</dt><dd class="col-8"><?= e($tenant['full_name']) ?> <?= e($tenant['phone']) ?></dd>
   <dt class="col-4">Monthly rent</dt><dd class="col-8"><?= money($tenant['monthly_rent']) ?></dd>
   <dt class="col-4">Agreement</dt><dd class="col-8"><?= e(dt($tenant['start_date'], 'd M Y')) ?> &rarr; <?= e(dt($tenant['end_date'], 'd M Y')) ?></dd></dl>
   <a class="btn btn-sm btn-gold" href="<?= e(url('modules/monthly_rooms/rent.php?tenant_id=' . $tenant['id'])) ?>">Rent &amp; payments</a></div></div>
<?php else: ?>
 <div class="card"><div class="card-body text-center text-muted py-5"><i class="bi bi-door-open fs-1"></i><p class="mb-3">No guest in this room right now.</p>
   <?php if (can('bookings') && $r['booking_mode'] !== 'monthly'): ?><a href="<?= e(url('modules/bookings/create.php?room_id=' . $id)) ?>" class="btn btn-gold">Book this room</a><?php endif; ?></div></div>
<?php endif; ?>
<?php if ($upcoming): ?><div class="card mt-3"><div class="card-header fw-semibold">Upcoming reservations</div><ul class="list-group list-group-flush">
  <?php foreach ($upcoming as $u): ?><li class="list-group-item small"><a href="<?= e(url('modules/bookings/details.php?id=' . $u['id'])) ?>"><?= e($u['booking_number']) ?></a> &middot; <?= e($u['full_name']) ?> &middot; <?= e(dt($u['checkin_datetime'], 'd M h:i A')) ?> &rarr; <?= e(dt($u['checkout_datetime'], 'd M h:i A')) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
</div></div>
<?php include ROOT . '/includes/footer.php'; ?>
