<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('rooms');
$pageTitle = 'Room Management';
$filter = $_GET['type'] ?? '';
$rooms = rows('SELECT r.*, t.type_name, t.booking_mode FROM rooms r JOIN room_types t ON t.id=r.room_type_id WHERE r.is_active=1 ORDER BY r.floor_number, r.room_number');
$types = rows('SELECT id, type_name FROM room_types WHERE is_active=1');
$legend = ['available' => ['Available', 'success'], 'occupied' => ['Occupied', 'danger'], 'reserved' => ['Reserved', 'primary'], 'cleaning' => ['Cleaning', 'warning'], 'monthly' => ['Monthly', 'info'], 'maintenance' => ['Maintenance', 'dark']];
include ROOT . '/includes/header.php';
?>
<div class="d-flex flex-wrap gap-2 align-items-center mb-3">
  <?php foreach ($legend as [$l, $c]): ?><span class="badge text-bg-<?= $c ?>"><?= e($l) ?></span><?php endforeach; ?>
  <div class="ms-auto d-flex gap-2">
    <select class="form-select form-select-sm" onchange="location='?type='+this.value"><option value="">All types</option>
      <?php foreach ($types as $t): ?><option value="<?= (int)$t['id'] ?>" <?= $filter == $t['id'] ? 'selected' : '' ?>><?= e($t['type_name']) ?></option><?php endforeach; ?></select>
    <a href="manage.php" class="btn btn-outline-dark btn-sm text-nowrap"><i class="bi bi-sliders me-1"></i>Manage rooms</a>
    <a href="<?= e(url('modules/bookings/create.php')) ?>" class="btn btn-gold btn-sm text-nowrap"><i class="bi bi-plus-lg me-1"></i>New Booking</a>
  </div>
</div>
<div class="row g-3">
<?php foreach ($rooms as $r):
    if ($filter && $r['room_type_id'] != $filter) continue;
    [$key, $label, $cls] = room_state($r);
    $guest = null;
    if ($key === 'occupied') $guest = val("SELECT g.full_name FROM booking_rooms br JOIN bookings b ON b.id=br.booking_id JOIN guests g ON g.id=b.guest_id WHERE br.room_id=? AND br.room_status='checked_in' LIMIT 1", [$r['id']]);
    if ($key === 'monthly') $guest = val("SELECT g.full_name FROM monthly_tenants mt JOIN guests g ON g.id=mt.guest_id WHERE mt.room_id=? AND mt.tenant_status='active' LIMIT 1", [$r['id']]);
?>
  <div class="col-6 col-md-4 col-xl-3"><a class="room-card s-<?= e($key) ?>" href="details.php?id=<?= (int)$r['id'] ?>">
    <div class="d-flex justify-content-between align-items-start"><span class="rn"><?= e($r['room_number']) ?></span><span class="badge text-bg-<?= $cls ?>"><?= e($label) ?></span></div>
    <div class="fw-semibold"><?= e($r['type_name']) ?></div><div class="small text-muted"><?= e($r['floor_number']) ?></div>
    <div class="mt-2 fw-bold" style="color:var(--gold-d)"><?= money($r['room_price']) ?><small class="text-muted fw-normal"> / <?= $r['booking_mode'] === 'monthly' ? 'month' : 'night' ?></small></div>
    <?php if ($guest): ?><div class="small mt-1"><i class="bi bi-person me-1"></i><?= e($guest) ?></div><?php endif; ?>
  </a></div>
<?php endforeach; if (!$rooms): ?><div class="col-12"><div class="alert alert-info">No rooms yet. Click <b>Manage rooms</b> to add your first room (or import <code>database/seed.sql</code> for demo rooms).</div></div><?php endif; ?>
</div>
<?php include ROOT . '/includes/footer.php'; ?>
