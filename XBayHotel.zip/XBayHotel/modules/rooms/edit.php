<?php header("Location: manage.php?action=edit&id=" . (int)($_GET["id"] ?? 0)); exit;
