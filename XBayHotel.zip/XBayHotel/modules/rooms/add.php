<?php header("Location: manage.php?action=add&id=" . (int)($_GET["id"] ?? 0)); exit;
