<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('rooms');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('modules/rooms/');
$id = (int)($_POST['room_id'] ?? 0);
try {
    $what = $_POST['what'] ?? '';
    if ($what === 'cleaning' && in_array($_POST['value'] ?? '', ['clean', 'dirty', 'in_progress'], true)) {
        q('UPDATE rooms SET cleaning_status=? WHERE id=?', [$_POST['value'], $id]);
        audit('cleaning', 'rooms', $id, 'Cleaning status: ' . $_POST['value']); flash('Cleaning status updated.');
    } elseif ($what === 'maintenance' && in_array($_POST['value'] ?? '', ['active', 'maintenance'], true)) {
        q('UPDATE rooms SET maintenance_status=? WHERE id=?', [$_POST['value'], $id]);
        audit('maintenance', 'rooms', $id, 'Maintenance: ' . $_POST['value']); flash('Maintenance status updated.');
    } elseif ($what === 'amenities') {
        q('DELETE FROM room_amenity_map WHERE room_id=?', [$id]);
        foreach ((array)($_POST['amenity'] ?? []) as $a) q('INSERT IGNORE INTO room_amenity_map (room_id, amenity_id) VALUES (?,?)', [$id, (int)$a]);
        flash('Amenities saved.');
    }
} catch (Throwable $ex) { flash($ex->getMessage(), 'danger'); }
redirect('modules/rooms/details.php?id=' . $id);
