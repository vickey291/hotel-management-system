<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = ['title' => 'Restaurant Tables', 'table' => 'restaurant_tables', 'perm' => 'menu',
 'select' => 'SELECT * FROM restaurant_tables ORDER BY table_number',
 'columns' => ['table_number' => 'No.', 'table_name' => 'Name', 'floor' => 'Floor', 'seating_capacity' => 'Seats', 'status' => 'Status', 'is_active' => 'Active'],
 'format' => ['status' => 'status', 'is_active' => 'bool'],
 'toolbar' => '<a class="btn btn-outline-dark" href="reservations.php">Reservations</a><a class="btn btn-outline-dark" href="../restaurant/floor_plan.php">Floor plan</a>',
 'fields' => [['name' => 'table_number', 'label' => 'Table number', 'required' => true], ['name' => 'table_name', 'label' => 'Table name'], ['name' => 'floor', 'label' => 'Floor / area'],
  ['name' => 'seating_capacity', 'label' => 'Seats', 'type' => 'number', 'step' => '1', 'default' => 4, 'required' => true], ['name' => 'is_active', 'label' => 'Active', 'type' => 'checkbox']]];
require ROOT . '/includes/crud.php';
