<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = ['title' => 'Table Reservations', 'table' => 'table_reservations', 'perm' => 'menu',
 'select' => 'SELECT r.*, t.table_number FROM table_reservations r JOIN restaurant_tables t ON t.id=r.table_id ORDER BY r.reservation_date DESC, r.start_time DESC LIMIT 300',
 'columns' => ['reservation_date' => 'Date', 'start_time' => 'From', 'table_number' => 'Table', 'guest_name' => 'Guest', 'phone' => 'Phone', 'guests_count' => 'Guests', 'reservation_status' => 'Status'],
 'format' => ['reservation_date' => 'date', 'reservation_status' => 'status'], 'toolbar' => '<a class="btn btn-outline-dark" href="index.php">Tables</a>',
 'fields' => [['name' => 'table_id', 'label' => 'Table', 'type' => 'select', 'required' => true, 'sql' => 'SELECT id, table_number FROM restaurant_tables WHERE is_active=1 ORDER BY table_number'],
  ['name' => 'guest_name', 'label' => 'Guest name', 'required' => true], ['name' => 'phone', 'label' => 'Phone'], ['name' => 'guests_count', 'label' => 'Guests', 'type' => 'number', 'step' => '1', 'default' => 2],
  ['name' => 'reservation_date', 'label' => 'Date', 'type' => 'date', 'required' => true], ['name' => 'start_time', 'label' => 'Start time', 'type' => 'time', 'required' => true], ['name' => 'end_time', 'label' => 'End time', 'type' => 'time', 'nullable' => true],
  ['name' => 'reservation_status', 'label' => 'Status', 'type' => 'select', 'required' => true, 'options' => ['booked' => 'Booked', 'seated' => 'Seated', 'completed' => 'Completed', 'cancelled' => 'Cancelled']]]];
require ROOT . '/includes/crud.php';
