<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('pos');
$pageTitle = 'Restaurant POS';
$cats = rows('SELECT * FROM menu_categories WHERE is_active=1 ORDER BY sort_order');
$items = rows('SELECT m.*, c.category_name FROM menu_items m JOIN menu_categories c ON c.id=m.category_id WHERE m.is_available=1 AND c.is_active=1 AND (m.is_stock_managed=0 OR m.stock_quantity>0) ORDER BY m.item_name');
$vars = []; foreach (rows('SELECT * FROM menu_item_variants WHERE is_active=1 ORDER BY price') as $v) $vars[$v['menu_item_id']][] = ['id' => (int)$v['id'], 'name' => $v['variant_name'], 'price' => (float)$v['price']];
$adds = []; foreach (rows('SELECT a.*, x.menu_item_id FROM menu_addons a JOIN menu_item_addons x ON x.addon_id=a.id WHERE a.is_active=1') as $a) $adds[$a['menu_item_id']][] = ['id' => (int)$a['id'], 'name' => $a['addon_name'], 'price' => (float)$a['addon_price']];
$data = ['taxPct' => (float)setting('restaurant_tax_percent', 0), 'svcPct' => (float)setting('service_charge_percent', 0), 'items' => []];
foreach ($items as $m) $data['items'][] = ['id' => (int)$m['id'], 'name' => $m['item_name'], 'price' => (float)$m['sale_price'], 'variants' => $vars[$m['id']] ?? [], 'addons' => $adds[$m['id']] ?? []];
$tables = rows('SELECT * FROM restaurant_tables WHERE is_active=1 ORDER BY table_number');
$occRooms = rows("SELECT r.id, r.room_number, g.full_name FROM booking_rooms br JOIN bookings b ON b.id=br.booking_id JOIN rooms r ON r.id=br.room_id JOIN guests g ON g.id=b.guest_id WHERE br.room_status='checked_in' AND b.booking_status='checked_in' ORDER BY r.room_number");
$pre = (int)($_GET['table_id'] ?? 0);
$pageScripts = ['assets/js/pos.js'];
$inlineScript = '';
include ROOT . '/includes/header.php';
?>
<script>window.POS_DATA = <?= json_encode($data) ?>;</script>
<div class="pos-wrap">
 <div class="pos-menu">
  <div class="d-flex gap-2 mb-2"><input id="posSearch" class="form-control" placeholder="Search item..."><a href="<?= e(url('modules/orders/')) ?>" class="btn btn-outline-dark text-nowrap">Open orders</a></div>
  <div class="cat-tabs"><button class="active" data-cat="all">All</button><?php foreach ($cats as $c): ?><button data-cat="<?= (int)$c['id'] ?>"><?= e($c['category_name']) ?></button><?php endforeach; ?></div>
  <div class="pos-items" id="posItems">
  <?php foreach ($items as $m): ?><div class="pos-item" data-id="<?= (int)$m['id'] ?>" data-cat="<?= (int)$m['category_id'] ?>" data-name="<?= e(strtolower($m['item_name'] . ' ' . $m['item_code'])) ?>">
    <?php if ($m['item_image']): ?><img src="<?= e(url('uploads/' . $m['item_image'])) ?>" alt=""><?php else: ?><div class="ph"><i class="bi bi-egg-fried"></i></div><?php endif; ?>
    <div class="nm"><?= e($m['item_name']) ?></div><div class="pr"><?= money($m['sale_price']) ?></div></div><?php endforeach; ?>
  <?php if (!$items): ?><div class="text-muted">No menu items yet. Add items in Menu Management.</div><?php endif; ?></div>
 </div>
 <div class="pos-cart">
  <div class="p-3 border-bottom"><div class="row g-2">
   <div class="col-12"><select id="orderType" class="form-select"><?php foreach (ORDER_TYPES as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
   <div class="col-12" id="tableBox"><select id="tableSel" class="form-select"><option value="">-- select table --</option><?php foreach ($tables as $t): ?><option value="<?= (int)$t['id'] ?>" <?= $pre == $t['id'] ? 'selected' : '' ?>><?= e($t['table_number'] . ' (' . $t['seating_capacity'] . ' seats)' . ($t['status'] === 'occupied' ? ' - occupied' : '')) ?></option><?php endforeach; ?></select></div>
   <div class="col-12" id="roomBox" style="display:none"><select id="roomSel" class="form-select"><option value="">-- guest room --</option><?php foreach ($occRooms as $r): ?><option value="<?= (int)$r['id'] ?>">Room <?= e($r['room_number'] . ' - ' . $r['full_name']) ?></option><?php endforeach; ?></select></div>
  </div></div>
  <div class="cart-lines" id="cartLines"></div>
  <div class="p-3 border-top">
   <div class="row g-2 mb-2"><div class="col-6"><input id="discount" type="number" min="0" step="any" class="form-control form-control-sm" placeholder="Discount"></div><div class="col-6"><input id="orderNotes" class="form-control form-control-sm" placeholder="Order note"></div></div>
   <div class="d-flex justify-content-between small"><span>Subtotal</span><span id="tSub">0</span></div><div class="d-flex justify-content-between small"><span>Tax / service</span><span id="tTax">0</span></div>
   <div class="d-flex justify-content-between fs-5 fw-bold"><span>Total</span><span id="tGrand">0</span></div>
   <button id="placeOrder" class="btn btn-gold w-100 mt-2 py-2"><i class="bi bi-send me-1"></i>Place order &amp; send to kitchen</button>
  </div>
 </div>
</div>
<div class="modal fade" id="itemModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="mName"></h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
 <div class="modal-body"><div id="mVariants"></div><div id="mAddons"></div><input id="mNote" class="form-control mt-3" placeholder="Special instruction (optional)"></div>
 <div class="modal-footer"><button class="btn btn-gold" id="mAdd">Add to order</button></div></div></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
