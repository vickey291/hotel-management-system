<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('pos');
$pageTitle = 'Floor Plan';
$tables = rows("SELECT t.*, (SELECT COALESCE(SUM(grand_total),0) FROM orders o WHERE o.table_id=t.id AND o.order_status='open') AS open_total, (SELECT COUNT(*) FROM orders o WHERE o.table_id=t.id AND o.order_status='open') AS open_orders,
 (SELECT COUNT(*) FROM table_reservations r WHERE r.table_id=t.id AND r.reservation_date=CURDATE() AND r.reservation_status='booked') AS booked FROM restaurant_tables t WHERE t.is_active=1 ORDER BY t.floor, t.table_number");
include ROOT . '/includes/header.php';
?>
<div class="row g-3"><?php foreach ($tables as $t): $s = $t['open_orders'] ? 'occupied' : ($t['booked'] ? 'reserved' : 'available'); ?>
 <div class="col-6 col-md-3 col-xl-2"><a class="tbl-tile tbl-<?= $s ?>" href="<?= e(url($t['open_orders'] ? 'modules/orders/?table_id=' . $t['id'] : 'modules/restaurant/?table_id=' . $t['id'])) ?>">
  <div class="fs-3 fw-bold"><?= e($t['table_number']) ?></div><div class="small"><?= (int)$t['seating_capacity'] ?> seats &middot; <?= e($t['floor']) ?></div><div class="mt-1 fw-semibold"><?= ucfirst($s) ?></div>
  <?php if ($t['open_orders']): ?><div class="small"><?= (int)$t['open_orders'] ?> order(s) &middot; <?= money($t['open_total']) ?></div><?php endif; ?></a></div>
<?php endforeach; ?></div>
<?php include ROOT . '/includes/footer.php'; ?>
