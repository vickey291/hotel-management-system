<?php $_GET["status"] = "preparing"; require __DIR__ . "/index.php";
