<?php $_GET["status"] = "pending"; require __DIR__ . "/index.php";
