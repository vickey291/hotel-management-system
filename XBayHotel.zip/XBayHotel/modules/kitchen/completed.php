<?php $_GET["status"] = "completed"; require __DIR__ . "/index.php";
