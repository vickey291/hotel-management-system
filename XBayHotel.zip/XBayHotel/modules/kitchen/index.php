<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('kitchen');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kid = (int)$_POST['kitchen_id']; $to = $_POST['to'] ?? '';
    $col = ['preparing' => 'preparing_at', 'ready' => 'ready_at', 'completed' => 'completed_at'][$to] ?? null;
    if ($col) { q("UPDATE kitchen_orders SET kitchen_status=?, $col=NOW() WHERE id=?", [$to, $kid]); }
    redirect($_SERVER['REQUEST_URI']);
}
$pageTitle = 'Kitchen Orders';
$only = $_GET['status'] ?? '';
$rowsK = rows("SELECT k.*, o.order_number, o.order_type, o.notes, o.order_date, t.table_number, r.room_number FROM kitchen_orders k JOIN orders o ON o.id=k.order_id LEFT JOIN restaurant_tables t ON t.id=o.table_id LEFT JOIN rooms r ON r.id=o.room_id
  WHERE o.order_status <> 'cancelled' AND (k.kitchen_status <> 'completed' OR DATE(k.completed_at)=CURDATE()) ORDER BY k.sent_at");
$cols = ['pending' => ['New / Pending', 'warning', 'preparing', 'Start preparing'], 'preparing' => ['Preparing', 'info', 'ready', 'Mark ready'], 'ready' => ['Ready to serve', 'success', 'completed', 'Mark served'], 'completed' => ['Served today', 'secondary', null, null]];
if ($only && isset($cols[$only])) $cols = [$only => $cols[$only]];
$inlineScript = 'setTimeout(function(){location.reload()},20000);';
include ROOT . '/includes/header.php';
?>
<div class="d-flex gap-2 mb-3"><a class="btn btn-sm btn-outline-dark" href="index.php">Board</a><a class="btn btn-sm btn-outline-dark" href="pending.php">Pending</a><a class="btn btn-sm btn-outline-dark" href="preparing.php">Preparing</a><a class="btn btn-sm btn-outline-dark" href="completed.php">Served</a><span class="ms-auto small text-muted">Auto-refreshes every 20 seconds</span></div>
<div class="row g-3"><?php foreach ($cols as $key => [$title, $cls, $next, $btn]): $tickets = array_filter($rowsK, fn($r) => $r['kitchen_status'] === $key); ?>
 <div class="col-lg-<?= count($cols) === 1 ? 6 : 3 ?>"><div class="k-col"><div class="d-flex justify-content-between mb-2"><b><?= e($title) ?></b><span class="badge text-bg-<?= $cls ?>"><?= count($tickets) ?></span></div>
 <?php foreach ($tickets as $t): $its = rows('SELECT oi.id, oi.item_name, oi.quantity, oi.item_notes FROM order_items oi WHERE oi.order_id=?', [$t['order_id']]); $mins = (int)((time() - strtotime($t['sent_at'])) / 60); ?>
  <div class="k-ticket"><div class="d-flex justify-content-between"><b><?= e($t['order_number']) ?></b><span class="small <?= $mins > 20 && $key !== 'completed' ? 'text-danger fw-bold' : 'text-muted' ?>"><?= $mins ?> min</span></div>
   <div class="small mb-1"><?= e(ORDER_TYPES[$t['order_type']]) ?> &middot; <b><?= e($t['table_number'] ? 'Table ' . $t['table_number'] : ($t['room_number'] ? 'Room ' . $t['room_number'] : 'Takeaway')) ?></b></div>
   <?php foreach ($its as $x): $ad = array_column(rows('SELECT addon_name FROM order_item_addons WHERE order_item_id=?', [$x['id']]), 'addon_name'); ?><div><b><?= (int)$x['quantity'] ?>&times;</b> <?= e($x['item_name']) ?><?= $ad ? ' <small class="text-muted">+ ' . e(implode(', ', $ad)) . '</small>' : '' ?><?= $x['item_notes'] ? ' <small class="text-info">(' . e($x['item_notes']) . ')</small>' : '' ?></div><?php endforeach; ?>
   <?php if ($t['notes']): ?><div class="small text-info mt-1">Note: <?= e($t['notes']) ?></div><?php endif; ?>
   <?php if ($next): ?><form method="post" class="mt-2"><?= csrf_field() ?><input type="hidden" name="kitchen_id" value="<?= (int)$t['id'] ?>"><input type="hidden" name="to" value="<?= $next ?>"><button class="btn btn-sm btn-gold w-100"><?= e($btn) ?></button></form><?php endif; ?></div>
 <?php endforeach; ?></div></div>
<?php endforeach; ?></div>
<?php include ROOT . '/includes/footer.php'; ?>
