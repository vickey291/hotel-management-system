<?php $_GET["r"] = "payments"; require __DIR__ . "/index.php";
