<?php $_GET["r"] = "bookings"; require __DIR__ . "/index.php";
