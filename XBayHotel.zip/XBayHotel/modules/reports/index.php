<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('reports');
$from = $_GET['from'] ?? date('Y-m-01'); $to = $_GET['to'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = date('Y-m-01');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) $to = date('Y-m-d');
if ($to < $from) [$from, $to] = [$to, $from];
$P = [$from, $to];
$m = 'money'; $n = 'num'; $t = 'text';

function group_by_day(string $sql, array $p, string $fmt = '%Y-%m-%d'): array { $o = []; foreach (rows(str_replace('{F}', $fmt, $sql), $p) as $r) $o[$r['d']] = (float)$r['s']; return $o; }

$reports = [
 'revenue' => ['Daily Hotel Revenue (collections)', function () use ($P, $from, $to, $m, $t) {
    $a = group_by_day("SELECT DATE_FORMAT(payment_date,'{F}') d, SUM(amount) s FROM payments WHERE DATE(payment_date) BETWEEN ? AND ? GROUP BY d", $P);
    $b = group_by_day("SELECT DATE_FORMAT(payment_date,'{F}') d, SUM(amount) s FROM tenant_payments WHERE DATE(payment_date) BETWEEN ? AND ? GROUP BY d", $P);
    $r = []; for ($d = strtotime($from); $d <= strtotime($to) && count($r) < 400; $d += 86400) { $k = date('Y-m-d', $d); $x = $a[$k] ?? 0; $y = $b[$k] ?? 0; if ($x || $y) $r[] = ['d' => date('d M Y', $d), 'a' => $x, 'b' => $y, 'c' => $x + $y]; }
    return ['cols' => ['d' => ['Date', $t], 'a' => ['Rooms + restaurant payments', $m], 'b' => ['Monthly rent', $m], 'c' => ['Total', $m]], 'rows' => $r, 'sum' => ['a', 'b', 'c'], 'chart' => 'c'];
 }],
 'monthly_revenue' => ['Monthly Hotel Revenue', function () use ($P, $m, $t) {
    $a = group_by_day("SELECT DATE_FORMAT(payment_date,'{F}') d, SUM(amount) s FROM payments WHERE DATE(payment_date) BETWEEN ? AND ? GROUP BY d", $P, '%Y-%m');
    $b = group_by_day("SELECT DATE_FORMAT(payment_date,'{F}') d, SUM(amount) s FROM tenant_payments WHERE DATE(payment_date) BETWEEN ? AND ? GROUP BY d", $P, '%Y-%m');
    $k = array_unique(array_merge(array_keys($a), array_keys($b))); sort($k); $r = [];
    foreach ($k as $x) $r[] = ['d' => date('M Y', strtotime($x . '-01')), 'a' => $a[$x] ?? 0, 'b' => $b[$x] ?? 0, 'c' => ($a[$x] ?? 0) + ($b[$x] ?? 0)];
    return ['cols' => ['d' => ['Month', $t], 'a' => ['Rooms + restaurant', $m], 'b' => ['Monthly rent', $m], 'c' => ['Total', $m]], 'rows' => $r, 'sum' => ['a', 'b', 'c'], 'chart' => 'c'];
 }],
 'bookings' => ['Room Booking Report', function () use ($P, $m, $t) {
    return ['cols' => ['booking_number' => ['Booking', $t], 'full_name' => ['Guest', $t], 'rooms' => ['Rooms', $t], 'ci' => ['Check-in', $t], 'co' => ['Check-out', $t], 'booking_status' => ['Status', $t], 'grand_total' => ['Total', $m], 'paid' => ['Paid', $m]],
     'rows' => rows("SELECT b.booking_number, g.full_name, (SELECT GROUP_CONCAT(r.room_number) FROM booking_rooms br JOIN rooms r ON r.id=br.room_id WHERE br.booking_id=b.id) rooms, DATE_FORMAT(b.checkin_datetime,'%d %b %Y %h:%i %p') ci, DATE_FORMAT(b.checkout_datetime,'%d %b %Y %h:%i %p') co, b.booking_status, b.grand_total, COALESCE((SELECT SUM(p.amount) FROM payments p JOIN invoices i ON i.id=p.invoice_id WHERE i.booking_id=b.id),0) paid FROM bookings b JOIN guests g ON g.id=b.guest_id WHERE DATE(b.checkin_datetime) BETWEEN ? AND ? ORDER BY b.checkin_datetime", $P), 'sum' => ['grand_total', 'paid']];
 }],
 'vip' => ['VIP Room Report', function () use ($P, $m, $t, $n) {
    return ['cols' => ['room_number' => ['Room', $t], 'bookings' => ['Bookings', $n], 'nights' => ['Nights sold', $n], 'revenue' => ['Room revenue', $m]],
     'rows' => rows("SELECT r.room_number, COUNT(DISTINCT br.booking_id) bookings, COALESCE(SUM(GREATEST(1,CEIL(TIMESTAMPDIFF(HOUR,br.checkin_datetime,br.checkout_datetime)/24))),0) nights, COALESCE(SUM(br.room_rate*GREATEST(1,CEIL(TIMESTAMPDIFF(HOUR,br.checkin_datetime,br.checkout_datetime)/24))),0) revenue FROM rooms r JOIN room_types t ON t.id=r.room_type_id AND t.booking_mode='vip' LEFT JOIN booking_rooms br ON br.room_id=r.id AND br.room_status<>'cancelled' AND DATE(br.checkin_datetime) BETWEEN ? AND ? GROUP BY r.id ORDER BY r.room_number", $P), 'sum' => ['bookings', 'nights', 'revenue']];
 }],
 'occupancy' => ['Occupancy Report', function () use ($from, $to, $t, $n) {
    $total = (int)val("SELECT COUNT(*) FROM rooms r JOIN room_types t ON t.id=r.room_type_id WHERE r.is_active=1 AND t.booking_mode<>'monthly'"); $r = [];
    for ($d = strtotime($from); $d <= strtotime($to) && count($r) < 120; $d += 86400) {
        $s = date('Y-m-d 00:00:00', $d); $e = date('Y-m-d 23:59:59', $d);
        $occ = (int)val("SELECT COUNT(DISTINCT br.room_id) FROM booking_rooms br WHERE br.room_status IN ('reserved','checked_in','checked_out') AND br.checkin_datetime <= ? AND br.checkout_datetime > ?", [$e, $s]);
        $r[] = ['d' => date('D, d M Y', $d), 'occ' => $occ, 'tot' => $total, 'pct' => $total ? round($occ * 100 / $total) . '%' : '-'];
    }
    return ['cols' => ['d' => ['Date', $t], 'occ' => ['Rooms occupied/reserved', $n], 'tot' => ['Total rooms', $n], 'pct' => ['Occupancy', $t]], 'rows' => $r];
 }],
 'payments' => ['Payments Report', function () use ($P, $m, $t) {
    return ['cols' => ['payment_number' => ['No.', $t], 'dt' => ['Date', $t], 'invoice_number' => ['Invoice', $t], 'full_name' => ['Guest', $t], 'payment_method' => ['Method', $t], 'amount' => ['Amount', $m]],
     'rows' => rows("SELECT p.payment_number, DATE_FORMAT(p.payment_date,'%d %b %Y %h:%i %p') dt, i.invoice_number, COALESCE(g.full_name,'Walk-in') full_name, p.payment_method, p.amount FROM payments p JOIN invoices i ON i.id=p.invoice_id LEFT JOIN guests g ON g.id=i.guest_id WHERE DATE(p.payment_date) BETWEEN ? AND ? ORDER BY p.payment_date", $P), 'sum' => ['amount']];
 }],
 'tenants' => ['Monthly Tenant Report', function () use ($P, $m, $t) {
    return ['cols' => ['room_number' => ['Room', $t], 'full_name' => ['Tenant', $t], 'monthly_rent' => ['Rent', $m], 'billed' => ['Billed (period)', $m], 'paid' => ['Paid (period)', $m], 'balance' => ['Total outstanding', $m]],
     'rows' => rows("SELECT r.room_number, g.full_name, mt.monthly_rent, COALESCE((SELECT SUM(total_amount) FROM monthly_rent_invoices i WHERE i.tenant_id=mt.id AND i.billing_month BETWEEN DATE_FORMAT(?,'%Y-%m') AND DATE_FORMAT(?,'%Y-%m')),0) billed, COALESCE((SELECT SUM(amount) FROM tenant_payments p WHERE p.tenant_id=mt.id AND DATE(p.payment_date) BETWEEN ? AND ?),0) paid, COALESCE((SELECT SUM(total_amount-paid_amount) FROM monthly_rent_invoices i WHERE i.tenant_id=mt.id),0) balance FROM monthly_tenants mt JOIN guests g ON g.id=mt.guest_id JOIN rooms r ON r.id=mt.room_id WHERE mt.tenant_status='active' ORDER BY r.room_number", [$P[0], $P[1], $P[0], $P[1]]), 'sum' => ['billed', 'paid', 'balance']];
 }],
 'restaurant' => ['Restaurant Sales Report', function () use ($P, $m, $t, $n) {
    return ['cols' => ['d' => ['Date', $t], 'orders' => ['Orders', $n], 'dine' => ['Dine-in', $m], 'room' => ['Room service', $m], 'take' => ['Takeaway', $m], 'total' => ['Total sales', $m]],
     'rows' => rows("SELECT DATE_FORMAT(order_date,'%d %b %Y') d, COUNT(*) orders, SUM(IF(order_type='dine_in',grand_total,0)) dine, SUM(IF(order_type='room_service',grand_total,0)) room, SUM(IF(order_type='takeaway',grand_total,0)) take, SUM(grand_total) total FROM orders WHERE order_status<>'cancelled' AND DATE(order_date) BETWEEN ? AND ? GROUP BY DATE(order_date) ORDER BY DATE(order_date)", $P), 'sum' => ['orders', 'dine', 'room', 'take', 'total'], 'chart' => 'total'];
 }],
 'items' => ['Food Item Sales Report', function () use ($P, $m, $t, $n) {
    return ['cols' => ['item_name' => ['Item', $t], 'qty' => ['Quantity sold', $n], 'revenue' => ['Revenue', $m]],
     'rows' => rows("SELECT oi.item_name, SUM(oi.quantity) qty, SUM(oi.total_price) revenue FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.order_status<>'cancelled' AND DATE(o.order_date) BETWEEN ? AND ? GROUP BY oi.item_name ORDER BY qty DESC", $P), 'sum' => ['qty', 'revenue']];
 }],
 'pending' => ['Pending Payment Report (all dates)', function () use ($m, $t) {
    return ['cols' => ['ref' => ['Invoice', $t], 'kind' => ['Type', $t], 'full_name' => ['Guest / Tenant', $t], 'total' => ['Total', $m], 'paid' => ['Paid', $m], 'due' => ['Remaining', $m]],
     'rows' => rows("SELECT i.invoice_number ref, i.invoice_type kind, COALESCE(g.full_name,'Walk-in') full_name, i.grand_total total, i.paid_amount paid, i.remaining_amount due FROM invoices i LEFT JOIN guests g ON g.id=i.guest_id WHERE i.remaining_amount>0 AND i.invoice_status IN ('unpaid','partial','pending')
        UNION ALL SELECT mi.invoice_number, 'monthly rent', g.full_name, mi.total_amount, mi.paid_amount, mi.total_amount-mi.paid_amount FROM monthly_rent_invoices mi JOIN monthly_tenants mt ON mt.id=mi.tenant_id JOIN guests g ON g.id=mt.guest_id WHERE mi.invoice_status<>'paid' ORDER BY due DESC"), 'sum' => ['total', 'paid', 'due']];
 }],
 'expenses' => ['Expenses Report', function () use ($P, $m, $t) {
    return ['cols' => ['d' => ['Date', $t], 'expense_title' => ['Title', $t], 'expense_category' => ['Category', $t], 'payment_method' => ['Method', $t], 'amount' => ['Amount', $m]],
     'rows' => rows("SELECT DATE_FORMAT(expense_date,'%d %b %Y') d, expense_title, expense_category, payment_method, amount FROM expenses WHERE expense_date BETWEEN ? AND ? ORDER BY expense_date", $P), 'sum' => ['amount']];
 }],
 'pnl' => ['Profit & Loss', function () use ($P, $m, $t) {
    $room = (float)val("SELECT COALESCE(SUM(p.amount),0) FROM payments p JOIN invoices i ON i.id=p.invoice_id WHERE i.invoice_type IN ('room','checkout') AND DATE(p.payment_date) BETWEEN ? AND ?", $P);
    $rest = (float)val("SELECT COALESCE(SUM(p.amount),0) FROM payments p JOIN invoices i ON i.id=p.invoice_id WHERE i.invoice_type NOT IN ('room','checkout') AND DATE(p.payment_date) BETWEEN ? AND ?", $P);
    $rent = (float)val('SELECT COALESCE(SUM(amount),0) FROM tenant_payments WHERE DATE(payment_date) BETWEEN ? AND ?', $P);
    $cogs = (float)val("SELECT COALESCE(SUM(oi.quantity*m.purchase_price),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id JOIN menu_items m ON m.id=oi.menu_item_id WHERE o.order_status<>'cancelled' AND DATE(o.order_date) BETWEEN ? AND ?", $P);
    $exp = (float)val('SELECT COALESCE(SUM(amount),0) FROM expenses WHERE expense_date BETWEEN ? AND ?', $P);
    $inc = $room + $rest + $rent; $net = $inc - $cogs - $exp;
    return ['cols' => ['l' => ['Item', $t], 'v' => ['Amount', $m]], 'rows' => [['l' => 'Room & checkout collections (incl. room-service food)', 'v' => $room], ['l' => 'Restaurant collections', 'v' => $rest], ['l' => 'Monthly rent collections', 'v' => $rent], ['l' => 'TOTAL INCOME', 'v' => $inc], ['l' => 'Less: cost of food sold (purchase price)', 'v' => -$cogs], ['l' => 'Less: expenses', 'v' => -$exp], ['l' => 'NET PROFIT / (LOSS)', 'v' => $net]],
     'note' => 'Income is cash actually received in the period. Room-service food paid through the room bill appears under room collections, while its cost is still in "cost of food sold".'];
 }],
 'staff' => ['Staff Activity Report', function () use ($P, $t, $n) {
    return ['cols' => ['full_name' => ['Staff', $t], 'module_name' => ['Module', $t], 'actions' => ['Actions', $n]],
     'rows' => rows("SELECT COALESCE(u.full_name,'System') full_name, a.module_name, COUNT(*) actions FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id WHERE DATE(a.created_at) BETWEEN ? AND ? GROUP BY a.user_id, a.module_name ORDER BY full_name, actions DESC", $P), 'sum' => ['actions']];
 }],
];
$key = $_GET['r'] ?? 'revenue'; if (!isset($reports[$key])) $key = 'revenue';
$res = ($reports[$key][1])();
$cols = $res['cols']; $data = $res['rows']; $sumKeys = $res['sum'] ?? [];

if (($_GET['export'] ?? '') === 'csv') {
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="xbay_' . $key . '_' . $from . '_to_' . $to . '.csv"');
    $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF"); fputcsv($o, array_map(fn($c) => $c[0], $cols));
    foreach ($data as $r) fputcsv($o, array_map(fn($k) => $r[$k] ?? '', array_keys($cols)));
    exit;
}
$pageTitle = 'Reports';
$chartKey = $res['chart'] ?? null;
if ($chartKey && $data) {
    $labels = array_map(fn($r) => $r[array_key_first($cols)], $data); $vals = array_map(fn($r) => (float)$r[$chartKey], $data);
    $pageScripts = ['https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js'];
    $inlineScript = 'new Chart(document.getElementById("rc"),{type:"bar",data:{labels:' . json_encode($labels) . ',datasets:[{label:"Amount",data:' . json_encode($vals) . ',backgroundColor:"#c9a24a"}]},options:{plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});';
}
include ROOT . '/includes/header.php';
$qs = fn($extra = []) => '?' . http_build_query(array_merge(['r' => $key, 'from' => $from, 'to' => $to], $extra));
?>
<div class="row g-3"><div class="col-lg-3 no-print"><div class="list-group">
 <?php foreach ($reports as $k => [$title]): ?><a class="list-group-item list-group-item-action <?= $k === $key ? 'active' : '' ?>" href="?r=<?= e($k) ?>&from=<?= e($from) ?>&to=<?= e($to) ?>"><?= e($title) ?></a><?php endforeach; ?></div></div>
<div class="col-lg-9"><div class="card mb-3 no-print"><div class="card-body"><form class="row g-2 align-items-end"><input type="hidden" name="r" value="<?= e($key) ?>">
 <div class="col-auto"><label class="small">From</label><input type="date" name="from" value="<?= e($from) ?>" class="form-control"></div><div class="col-auto"><label class="small">To</label><input type="date" name="to" value="<?= e($to) ?>" class="form-control"></div>
 <div class="col-auto"><button class="btn btn-gold">Show</button></div>
 <div class="col-auto ms-auto d-flex gap-2"><a class="btn btn-outline-dark" href="<?= e($qs(['export' => 'csv'])) ?>"><i class="bi bi-file-earmark-excel me-1"></i>Excel (CSV)</a><button type="button" class="btn btn-outline-dark" onclick="window.print()"><i class="bi bi-file-earmark-pdf me-1"></i>PDF / Print</button></div></form></div></div>
<div class="card"><div class="card-header"><b><?= e($reports[$key][0]) ?></b> <span class="text-muted small ms-2"><?= e(date('d M Y', strtotime($from))) ?> &ndash; <?= e(date('d M Y', strtotime($to))) ?></span></div>
 <?php if ($chartKey && $data): ?><div class="card-body pb-0"><canvas id="rc" height="90"></canvas></div><?php endif; ?>
 <div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><?php foreach ($cols as [$l, $ty]): ?><th class="<?= $ty !== 'text' ? 'text-end' : '' ?>"><?= e($l) ?></th><?php endforeach; ?></tr></thead><tbody>
 <?php foreach ($data as $r): ?><tr><?php foreach ($cols as $k => [$l, $ty]): $v = $r[$k] ?? ''; ?><td class="<?= $ty !== 'text' ? 'text-end' : '' ?>"><?= $ty === 'money' ? money($v) : ($ty === 'num' ? e(number_format((float)$v)) : e($v)) ?></td><?php endforeach; ?></tr><?php endforeach; ?>
 <?php if (!$data): ?><tr><td colspan="<?= count($cols) ?>" class="text-center text-muted py-4">No data for this period.</td></tr><?php endif; ?></tbody>
 <?php if ($sumKeys && $data): ?><tfoot><tr class="fw-bold table-light"><?php $first = true; foreach ($cols as $k => [$l, $ty]): ?><td class="<?= $ty !== 'text' ? 'text-end' : '' ?>"><?php if (in_array($k, $sumKeys)) { $s = array_sum(array_map(fn($r) => (float)$r[$k], $data)); echo $ty === 'money' ? money($s) : e(number_format($s)); } elseif ($first) echo 'TOTAL'; $first = false; ?></td><?php endforeach; ?></tr></tfoot><?php endif; ?></table></div>
 <?php if (!empty($res['note'])): ?><div class="card-footer small text-muted"><?= e($res['note']) ?></div><?php endif; ?></div></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
