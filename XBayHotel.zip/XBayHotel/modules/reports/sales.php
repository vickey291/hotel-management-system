<?php $_GET["r"] = "restaurant"; require __DIR__ . "/index.php";
