<?php $_GET["r"] = "occupancy"; require __DIR__ . "/index.php";
