<?php header("Location: index.php?action=add&id=" . (int)($_GET["id"] ?? 0)); exit;
