<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('guests');
$id = (int)($_GET['id'] ?? 0);
$g = row('SELECT * FROM guests WHERE id=?', [$id]);
if (!$g) { flash('Guest not found.', 'danger'); redirect('modules/guests/'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (($_POST['_action'] ?? '') === 'add_doc') {
            $front = upload_file('front_image', 'guest_documents', true, true);
            $back = upload_file('back_image', 'guest_documents', true, true);
            q('INSERT INTO guest_documents (guest_id, document_type, document_number, front_image, back_image, issue_date, expiry_date) VALUES (?,?,?,?,?,?,?)',
                [$id, $_POST['document_type'] ?: 'CNIC', trim($_POST['document_number']), $front, $back, $_POST['issue_date'] ?: null, $_POST['expiry_date'] ?: null]);
            audit('create', 'guest_documents', (int)db()->lastInsertId(), "Document added for guest {$g['guest_code']}");
            flash('Document saved (stored privately).');
        } elseif (($_POST['_action'] ?? '') === 'verify') {
            q('UPDATE guest_documents SET verification_status=? WHERE id=? AND guest_id=?', [in_array($_POST['status'], ['pending', 'verified', 'rejected']) ? $_POST['status'] : 'pending', (int)$_POST['doc_id'], $id]);
            flash('Verification status updated.');
        }
    } catch (Throwable $ex) { flash($ex->getMessage(), 'danger'); }
    redirect('modules/guests/details.php?id=' . $id);
}
$docs = rows('SELECT * FROM guest_documents WHERE guest_id=? ORDER BY id DESC', [$id]);
$bookings = rows('SELECT b.*, (SELECT GROUP_CONCAT(r.room_number) FROM booking_rooms br JOIN rooms r ON r.id=br.room_id WHERE br.booking_id=b.id) AS rooms FROM bookings b WHERE b.guest_id=? ORDER BY b.id DESC', [$id]);
$invoices = rows('SELECT * FROM invoices WHERE guest_id=? ORDER BY id DESC LIMIT 20', [$id]);
$pageTitle = $g['full_name'];
include ROOT . '/includes/header.php';
?>
<a href="index.php" class="btn btn-sm btn-outline-secondary mb-3"><i class="bi bi-arrow-left"></i> Guests</a>
<div class="row g-3">
<div class="col-lg-4"><div class="card"><div class="card-body">
  <h5 class="fw-bold mb-0"><?= e($g['full_name']) ?></h5><div class="text-muted small mb-2"><?= e($g['guest_code']) ?></div>
  <dl class="row small mb-2"><dt class="col-5">Father/Husband</dt><dd class="col-7"><?= e($g['father_husband_name']) ?></dd><dt class="col-5">Phone</dt><dd class="col-7"><?= e($g['phone']) ?></dd>
  <dt class="col-5">Email</dt><dd class="col-7"><?= e($g['email']) ?></dd><dt class="col-5">Address</dt><dd class="col-7"><?= e($g['address']) ?>, <?= e($g['city']) ?></dd></dl>
  <a href="index.php?action=edit&id=<?= $id ?>" class="btn btn-sm btn-outline-primary">Edit</a> <a href="<?= e(url('modules/bookings/create.php?guest_id=' . $id)) ?>" class="btn btn-sm btn-gold">New booking</a>
</div></div>
<div class="card mt-3"><div class="card-header fw-semibold">Add ID document</div><div class="card-body">
 <form method="post" enctype="multipart/form-data" class="row g-2"><?= csrf_field() ?><input type="hidden" name="_action" value="add_doc">
  <div class="col-6"><select name="document_type" class="form-select form-select-sm"><option>CNIC</option><option>Passport</option><option>Driving License</option><option>Other</option></select></div>
  <div class="col-6"><input name="document_number" class="form-control form-control-sm" placeholder="00000-0000000-0" required></div>
  <div class="col-12"><label class="small">Front image</label><input type="file" name="front_image" class="form-control form-control-sm" accept="image/*,application/pdf"></div>
  <div class="col-12"><label class="small">Back image</label><input type="file" name="back_image" class="form-control form-control-sm" accept="image/*,application/pdf"></div>
  <div class="col-6"><label class="small">Issue date</label><input type="date" name="issue_date" class="form-control form-control-sm"></div>
  <div class="col-6"><label class="small">Expiry date</label><input type="date" name="expiry_date" class="form-control form-control-sm"></div>
  <div class="col-12"><button class="btn btn-sm btn-gold">Save document</button></div></form></div></div></div>
<div class="col-lg-8">
 <div class="card mb-3"><div class="card-header fw-semibold">Identity documents <small class="text-muted">(visible to authorised staff only; every view is logged)</small></div>
 <div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Type</th><th>Number</th><th>Images</th><th>Status</th></tr></thead><tbody>
 <?php foreach ($docs as $d): ?><tr><td><?= e($d['document_type']) ?></td><td><?= e($d['document_number']) ?></td>
  <td><?php if ($d['front_image']): ?><a target="_blank" href="doc.php?id=<?= (int)$d['id'] ?>&side=front">Front</a><?php endif; ?> <?php if ($d['back_image']): ?>&middot; <a target="_blank" href="doc.php?id=<?= (int)$d['id'] ?>&side=back">Back</a><?php endif; ?></td>
  <td><form method="post" class="d-flex gap-1"><?= csrf_field() ?><input type="hidden" name="_action" value="verify"><input type="hidden" name="doc_id" value="<?= (int)$d['id'] ?>">
   <select name="status" class="form-select form-select-sm" onchange="this.form.submit()"><?php foreach (['pending', 'verified', 'rejected'] as $s): ?><option <?= $d['verification_status'] === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?></select></form></td></tr>
 <?php endforeach; if (!$docs) echo '<tr><td colspan="4" class="text-muted">No documents yet.</td></tr>'; ?></tbody></table></div></div>
 <div class="card mb-3"><div class="card-header fw-semibold">Stay history</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Booking</th><th>Rooms</th><th>Check-in</th><th>Check-out</th><th>Status</th><th class="text-end">Total</th></tr></thead><tbody>
 <?php foreach ($bookings as $b): ?><tr><td><a href="<?= e(url('modules/bookings/details.php?id=' . $b['id'])) ?>"><?= e($b['booking_number']) ?></a></td><td><?= e($b['rooms']) ?></td><td><?= e(dt($b['checkin_datetime'], 'd M y')) ?></td><td><?= e(dt($b['checkout_datetime'], 'd M y')) ?></td><td><?= badge(BOOKING_STATUSES[$b['booking_status']], status_class($b['booking_status'])) ?></td><td class="text-end"><?= money($b['grand_total']) ?></td></tr>
 <?php endforeach; if (!$bookings) echo '<tr><td colspan="6" class="text-muted">No stays.</td></tr>'; ?></tbody></table></div></div>
 <div class="card"><div class="card-header fw-semibold">Invoices</div><div class="table-responsive"><table class="table table-sm mb-0"><tbody>
 <?php foreach ($invoices as $i): ?><tr><td><a href="<?= e(url('modules/billing/details.php?id=' . $i['id'])) ?>"><?= e($i['invoice_number']) ?></a></td><td><?= e(ucfirst($i['invoice_type'])) ?></td><td><?= badge(ucfirst($i['invoice_status']), status_class($i['invoice_status'])) ?></td><td class="text-end"><?= money($i['grand_total']) ?></td><td class="text-end text-danger"><?= money($i['remaining_amount']) ?></td></tr>
 <?php endforeach; if (!$invoices) echo '<tr><td class="text-muted">No invoices.</td></tr>'; ?></tbody></table></div></div>
</div></div>
<?php include ROOT . '/includes/footer.php'; ?>
