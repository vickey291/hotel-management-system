<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = [
 'title' => 'Guest Management', 'table' => 'guests', 'perm' => 'guests',
 'select' => 'SELECT g.*, (SELECT document_number FROM guest_documents d WHERE d.guest_id=g.id ORDER BY d.id DESC LIMIT 1) AS cnic, (SELECT COUNT(*) FROM bookings b WHERE b.guest_id=g.id) AS stays FROM guests g ORDER BY g.id DESC LIMIT 1000',
 'columns' => ['guest_code' => 'Code', 'full_name' => 'Name', 'father_husband_name' => 'Father / Husband', 'cnic' => 'CNIC', 'phone' => 'Phone', 'city' => 'City', 'stays' => 'Stays'],
 'row_actions' => fn($r) => '<a class="btn btn-sm btn-outline-dark" href="details.php?id=' . (int)$r['id'] . '"><i class="bi bi-eye"></i></a> ',
 'fields' => [
  ['name' => 'guest_code', 'label' => 'Guest code', 'required' => true, 'default' => guest_code()],
  ['name' => 'full_name', 'label' => 'Full name', 'required' => true],
  ['name' => 'father_husband_name', 'label' => 'Father / Husband name'],
  ['name' => 'phone', 'label' => 'Mobile number', 'type' => 'tel'],
  ['name' => 'email', 'label' => 'Email', 'type' => 'email'],
  ['name' => 'address', 'label' => 'Address'],
  ['name' => 'city', 'label' => 'City'],
  ['name' => 'country', 'label' => 'Country', 'default' => 'Pakistan'],
 ]];
require ROOT . '/includes/crud.php';
