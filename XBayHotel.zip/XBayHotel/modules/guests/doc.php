<?php
// Streams a private CNIC/ID image only to logged-in staff with the 'guests' permission.
require_once __DIR__ . '/../../includes/functions.php';
require_perm('guests');
$d = row('SELECT * FROM guest_documents WHERE id=?', [(int)($_GET['id'] ?? 0)]);
$side = ($_GET['side'] ?? 'front') === 'back' ? 'back_image' : 'front_image';
if (!$d || empty($d[$side])) { http_response_code(404); die('Not found'); }
$path = realpath(ROOT . '/storage/' . $d[$side]);
$base = realpath(ROOT . '/storage');
if (!$path || !$base || !str_starts_with($path, $base) || !is_file($path)) { http_response_code(404); die('File missing'); }
audit('view_document', 'guest_documents', (int)$d['id'], "Viewed {$side}");
header('Content-Type: ' . (new finfo(FILEINFO_MIME_TYPE))->file($path));
header('Content-Length: ' . filesize($path));
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
readfile($path);
