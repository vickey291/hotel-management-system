<?php header("Location: index.php?action=edit&id=" . (int)($_GET["id"] ?? 0)); exit;
