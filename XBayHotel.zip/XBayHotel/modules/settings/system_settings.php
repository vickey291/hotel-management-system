<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('settings');
$pageTitle = 'System Settings';
$keys = ['checkin_time' => ['Default check-in time', 'time', 'booking'], 'checkout_time' => ['Default check-out time', 'time', 'booking'], 'tax_percent' => ['Room tax %', 'number', 'billing'],
 'restaurant_tax_percent' => ['Restaurant tax %', 'number', 'billing'], 'service_charge_percent' => ['Dine-in service charge %', 'number', 'billing'], 'monthly_grace_days' => ['Monthly rent grace days', 'number', 'billing']];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($keys as $k => [$l, $t, $g]) { $v = trim($_POST[$k] ?? ''); if ($t === 'number') $v = (string)max(0, (float)$v); if ($v !== '') set_setting($k, $v, $g); }
    audit('update', 'system_settings', null, 'System settings updated'); flash('Settings saved.'); redirect('modules/settings/system_settings.php');
}
include ROOT . '/includes/header.php';
?>
<div class="card" style="max-width:620px"><div class="card-header fw-semibold">System settings</div><div class="card-body"><form method="post" class="row g-3"><?= csrf_field() ?>
<?php foreach ($keys as $k => [$l, $t]): ?><div class="col-md-6"><label class="form-label"><?= e($l) ?></label><input type="<?= $t ?>" step="any" name="<?= e($k) ?>" value="<?= e(setting($k)) ?>" class="form-control"></div><?php endforeach; ?>
<div class="col-12"><button class="btn btn-gold">Save</button></div></form></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
