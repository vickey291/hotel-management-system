<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('settings');
$pageTitle = 'Hotel Profile';
$h = row('SELECT * FROM hotel_settings LIMIT 1');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $logo = upload_file('logo', 'hotel_logo') ?: ($h['logo'] ?? null);
        $d = [trim($_POST['hotel_name']), trim($_POST['tagline']), $logo, trim($_POST['phone']), trim($_POST['email']), trim($_POST['address']), trim($_POST['city']), trim($_POST['country']), trim($_POST['website']), trim($_POST['currency']) ?: 'Rs.', trim($_POST['tax_number']), trim($_POST['receipt_footer'])];
        if ($d[0] === '') throw new RuntimeException('Hotel name is required.');
        if ($h) q('UPDATE hotel_settings SET hotel_name=?, tagline=?, logo=?, phone=?, email=?, address=?, city=?, country=?, website=?, currency=?, tax_number=?, receipt_footer=? WHERE id=?', [...$d, $h['id']]);
        else q('INSERT INTO hotel_settings (hotel_name, tagline, logo, phone, email, address, city, country, website, currency, tax_number, receipt_footer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', $d);
        audit('update', 'hotel_settings', null, 'Hotel profile updated'); flash('Hotel profile saved.'); redirect('modules/settings/hotel_profile.php');
    } catch (Throwable $ex) { flash($ex->getMessage(), 'danger'); }
}
$h = $h ?: hotel();
include ROOT . '/includes/header.php';
$f = fn($k, $l, $col = 6, $t = 'text') => '<div class="col-md-' . $col . '"><label class="form-label">' . $l . '</label><input type="' . $t . '" name="' . $k . '" value="' . e($h[$k] ?? '') . '" class="form-control"></div>';
?>
<div class="card" style="max-width:860px"><div class="card-header fw-semibold">Hotel profile</div><div class="card-body"><form method="post" enctype="multipart/form-data" class="row g-3"><?= csrf_field() ?>
 <?= $f('hotel_name', 'Hotel name *') ?><?= $f('tagline', 'Tagline') ?><?= $f('phone', 'Phone') ?><?= $f('email', 'Email', 6, 'email') ?><?= $f('address', 'Address', 12) ?><?= $f('city', 'City', 4) ?><?= $f('country', 'Country', 4) ?><?= $f('website', 'Website', 4) ?>
 <?= $f('currency', 'Currency symbol (Rs., PKR)', 4) ?><?= $f('tax_number', 'Tax number (NTN)', 4) ?>
 <div class="col-md-4"><label class="form-label">Logo</label><input type="file" name="logo" class="form-control" accept="image/*"><?php if (!empty($h['logo'])): ?><img src="<?= e(url('uploads/' . $h['logo'])) ?>" height="50" class="mt-2 border rounded bg-white"><?php endif; ?></div>
 <?= $f('receipt_footer', 'Receipt footer message', 12) ?>
 <div class="col-12"><button class="btn btn-gold">Save profile</button></div></form></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
