<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('settings');
$pageTitle = 'Receipt & Printing';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sz = in_array($_POST['receipt_size'] ?? '', ['58', '80', 'a4'], true) ? $_POST['receipt_size'] : '80';
    set_setting('receipt_size', $sz, 'printing');
    if (hotel()) q('UPDATE hotel_settings SET receipt_footer=?', [trim($_POST['receipt_footer'] ?? '')]);
    flash('Receipt settings saved.'); redirect('modules/settings/receipt_settings.php');
}
include ROOT . '/includes/header.php';
?>
<div class="card" style="max-width:560px"><div class="card-header fw-semibold">Receipt &amp; printing</div><div class="card-body"><form method="post" class="row g-3"><?= csrf_field() ?>
 <div class="col-12"><label class="form-label">Default receipt size</label><select name="receipt_size" class="form-select"><?php foreach (['58' => '58 mm thermal', '80' => '80 mm thermal', 'a4' => 'A4 page'] as $k => $l): ?><option value="<?= $k ?>" <?= setting('receipt_size', '80') == $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select><div class="form-text">Any receipt can also be opened in another size using <code>&amp;size=58</code>, <code>&amp;size=80</code> or <code>&amp;size=a4</code>.</div></div>
 <div class="col-12"><label class="form-label">Footer message</label><input name="receipt_footer" value="<?= e(hotel()['receipt_footer']) ?>" class="form-control"></div>
 <div class="col-12"><button class="btn btn-gold">Save</button></div></form></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
