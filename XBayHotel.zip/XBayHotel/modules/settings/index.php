<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('settings');
$pageTitle = 'Hotel Settings';
$cards = [['hotel_profile.php', 'bi-building', 'Hotel profile', 'Name, logo, phone, email, address, website, currency, tax number'],
 ['system_settings.php', 'bi-sliders', 'System settings', 'Check-in / check-out time, tax %, service charge %'],
 ['receipt_settings.php', 'bi-printer', 'Receipt & printing', 'Receipt size (58mm / 80mm / A4) and footer message'],
 ['../rooms/manage.php', 'bi-door-open', 'Room rates', 'Change room prices, floors, maintenance'],
 ['../menu/', 'bi-egg-fried', 'Menu prices', 'Items, prices, categories'],
 ['backup.php', 'bi-database-down', 'Database backup', 'Download or save a full SQL backup']];
include ROOT . '/includes/header.php';
?>
<div class="row g-3"><?php foreach ($cards as [$href, $icon, $t, $d]): ?><div class="col-md-6 col-xl-4"><a href="<?= e($href) ?>" class="feature d-block text-decoration-none text-dark"><i class="bi <?= $icon ?>"></i><h5 class="mt-2"><?= e($t) ?></h5><p class="text-muted small mb-0"><?= e($d) ?></p></a></div><?php endforeach; ?></div>
<?php include ROOT . '/includes/footer.php'; ?>
