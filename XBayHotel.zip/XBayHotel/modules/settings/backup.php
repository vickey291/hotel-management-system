<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('settings');
function make_dump(): string {
    $pdo = db(); $out = "-- XBay Hotel backup " . date('Y-m-d H:i:s') . "\nSET FOREIGN_KEY_CHECKS=0;\nSET NAMES utf8mb4;\n\n";
    foreach ($pdo->query('SHOW FULL TABLES WHERE Table_type="BASE TABLE"')->fetchAll(PDO::FETCH_NUM) as [$t]) {
        $out .= "DROP TABLE IF EXISTS `$t`;\n" . $pdo->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1] . ";\n\n";
        $st = $pdo->query("SELECT * FROM `$t`");
        while ($r = $st->fetch(PDO::FETCH_ASSOC)) $out .= "INSERT INTO `$t` (`" . implode('`,`', array_keys($r)) . "`) VALUES (" . implode(',', array_map(fn($v) => $v === null ? 'NULL' : $pdo->quote((string)$v), $r)) . ");\n";
        $out .= "\n";
    }
    return $out . "SET FOREIGN_KEY_CHECKS=1;\n";
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = 'xbay_backup_' . date('Ymd_His') . '.sql';
    try {
        $sql = make_dump();
        if (($_POST['mode'] ?? '') === 'save') {
            file_put_contents(ROOT . '/database/backup/' . $name, $sql);
            q("INSERT INTO database_backups (backup_file, created_by, backup_status) VALUES (?,?,'success')", [$name, user()['id']]); audit('backup', 'database', null, $name);
            flash("Backup saved in database/backup/$name"); redirect('modules/settings/backup.php');
        }
        q("INSERT INTO database_backups (backup_file, created_by, backup_status) VALUES (?,?,'success')", [$name . ' (download)', user()['id']]); audit('backup', 'database', null, $name . ' downloaded');
        header('Content-Type: application/sql'); header('Content-Disposition: attachment; filename="' . $name . '"'); echo $sql; exit;
    } catch (Throwable $ex) { try { q("INSERT INTO database_backups (backup_file, created_by, backup_status) VALUES (?,?,'failed')", [$name, user()['id']]); } catch (Throwable $e2) {} flash('Backup failed: ' . $ex->getMessage(), 'danger'); redirect('modules/settings/backup.php'); }
}
$pageTitle = 'Database Backup';
$list = rows('SELECT b.*, u.full_name FROM database_backups b LEFT JOIN users u ON u.id=b.created_by ORDER BY b.id DESC LIMIT 20');
include ROOT . '/includes/header.php';
?>
<div class="row g-3"><div class="col-lg-5"><div class="card"><div class="card-header fw-semibold">Create backup</div><div class="card-body"><p class="small text-muted">Creates a complete SQL file of the whole database (all 42 tables). Restore by importing it in phpMyAdmin. Take a backup daily and keep a copy on a USB drive or cloud.</p>
 <form method="post" class="d-grid gap-2"><?= csrf_field() ?><button name="mode" value="download" class="btn btn-gold"><i class="bi bi-download me-1"></i>Download backup</button><button name="mode" value="save" class="btn btn-outline-dark"><i class="bi bi-save me-1"></i>Save on server</button></form></div></div></div>
<div class="col-lg-7"><div class="card"><div class="card-header fw-semibold">Backup history</div><table class="table table-sm mb-0"><tbody><?php foreach ($list as $b): ?><tr><td class="small"><?= e(dt($b['backup_date'])) ?></td><td><?= e($b['backup_file']) ?></td><td><?= e($b['full_name']) ?></td><td><?= badge($b['backup_status'], $b['backup_status'] === 'success' ? 'success' : 'danger') ?></td></tr><?php endforeach; if (!$list) echo '<tr><td class="text-muted">No backups yet.</td></tr>'; ?></tbody></table></div></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
