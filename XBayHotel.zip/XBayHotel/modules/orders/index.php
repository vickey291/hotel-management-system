<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('pos');
$pageTitle = 'Orders';
$st = $_GET['status'] ?? 'open'; $ty = $_GET['type'] ?? ''; $tb = (int)($_GET['table_id'] ?? 0); $d = $_GET['date'] ?? '';
$sql = "SELECT o.*, t.table_number, r.room_number, k.kitchen_status, i.invoice_status FROM orders o LEFT JOIN restaurant_tables t ON t.id=o.table_id LEFT JOIN rooms r ON r.id=o.room_id LEFT JOIN kitchen_orders k ON k.order_id=o.id LEFT JOIN invoices i ON i.id=o.invoice_id WHERE 1=1"; $p = [];
if (in_array($st, ['open', 'completed', 'cancelled'])) { $sql .= ' AND o.order_status=?'; $p[] = $st; }
if (isset(ORDER_TYPES[$ty])) { $sql .= ' AND o.order_type=?'; $p[] = $ty; }
if ($tb) { $sql .= ' AND o.table_id=?'; $p[] = $tb; }
if ($d) { $sql .= ' AND DATE(o.order_date)=?'; $p[] = $d; }
$list = rows($sql . ' ORDER BY o.id DESC LIMIT 300', $p);
include ROOT . '/includes/header.php';
?>
<form class="d-flex flex-wrap gap-2 mb-3"><select name="status" class="form-select w-auto" onchange="this.form.submit()"><?php foreach (['open' => 'Open', 'completed' => 'Completed', 'cancelled' => 'Cancelled', 'all' => 'All'] as $k => $l): ?><option value="<?= $k ?>" <?= $st === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select>
 <select name="type" class="form-select w-auto" onchange="this.form.submit()"><option value="">All types</option><?php foreach (ORDER_TYPES as $k => $l): ?><option value="<?= $k ?>" <?= $ty === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select>
 <input type="date" name="date" value="<?= e($d) ?>" class="form-control w-auto" onchange="this.form.submit()"><a href="<?= e(url('modules/restaurant/')) ?>" class="btn btn-gold ms-auto"><i class="bi bi-plus-lg me-1"></i>New order</a></form>
<div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Order</th><th>Time</th><th>Type</th><th>Table / Room</th><th>Kitchen</th><th>Payment</th><th>Status</th><th class="text-end">Total</th><th></th></tr></thead><tbody>
<?php foreach ($list as $o): ?><tr><td><a class="fw-semibold" href="details.php?id=<?= (int)$o['id'] ?>"><?= e($o['order_number']) ?></a></td><td><?= e(dt($o['order_date'], 'd M, h:i A')) ?></td><td><?= e(ORDER_TYPES[$o['order_type']]) ?></td><td><?= e($o['table_number'] ?: ($o['room_number'] ? 'Room ' . $o['room_number'] : '-')) ?></td>
 <td><?= $o['kitchen_status'] ? badge(ucfirst($o['kitchen_status']), status_class($o['kitchen_status'])) : '-' ?></td><td><?= $o['order_type'] === 'room_service' ? '<span class="small text-muted">On room bill</span>' : ($o['invoice_status'] ? badge(ucfirst($o['invoice_status']), status_class($o['invoice_status'])) : badge('No bill', 'secondary')) ?></td>
 <td><?= badge(ucfirst($o['order_status']), status_class($o['order_status'])) ?></td><td class="text-end"><?= money($o['grand_total']) ?></td><td class="text-end"><a class="btn btn-sm btn-outline-dark" href="details.php?id=<?= (int)$o['id'] ?>"><i class="bi bi-eye"></i></a></td></tr>
<?php endforeach; if (!$list) echo '<tr><td colspan="9" class="text-center text-muted py-4">No orders.</td></tr>'; ?></tbody></table></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
