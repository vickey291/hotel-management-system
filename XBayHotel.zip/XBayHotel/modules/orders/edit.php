<?php header("Location: details.php?id=" . (int)($_GET["id"] ?? 0)); exit;
