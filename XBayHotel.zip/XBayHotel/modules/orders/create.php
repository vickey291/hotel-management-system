<?php header("Location: ../restaurant/"); exit;
