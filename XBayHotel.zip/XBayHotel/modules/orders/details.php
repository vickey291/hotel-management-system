<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('pos');
$id = (int)($_GET['id'] ?? 0);
$o = row('SELECT o.*, t.table_number, r.room_number, g.full_name FROM orders o LEFT JOIN restaurant_tables t ON t.id=o.table_id LEFT JOIN rooms r ON r.id=o.room_id LEFT JOIN guests g ON g.id=o.guest_id WHERE o.id=?', [$id]);
if (!$o) { flash('Order not found.', 'danger'); redirect('modules/orders/'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = db();
    try {
        $a = $_POST['_action'] ?? '';
        if ($a === 'bill') { ensure_order_invoice($id); flash('Bill generated.'); }
        elseif ($a === 'pay') {
            if ($o['order_type'] === 'room_service') throw new RuntimeException('Room service is charged to the room bill.');
            $pdo->beginTransaction();
            $iid = ensure_order_invoice($id);
            record_payment($iid, round((float)$_POST['amount'], 2), array_key_exists($_POST['payment_method'], PAYMENT_METHODS) ? $_POST['payment_method'] : 'cash', trim($_POST['reference'] ?? ''), null);
            $pdo->commit(); flash('Payment received.');
        } elseif ($a === 'cancel') {
            if ($o['order_status'] !== 'open') throw new RuntimeException('Only open orders can be cancelled.');
            if ($o['invoice_id'] && (float)val('SELECT paid_amount FROM invoices WHERE id=?', [$o['invoice_id']]) > 0) throw new RuntimeException('This order already has a payment.');
            $pdo->beginTransaction();
            foreach (rows('SELECT oi.quantity, oi.menu_item_id FROM order_items oi JOIN menu_items m ON m.id=oi.menu_item_id AND m.is_stock_managed=1 WHERE oi.order_id=?', [$id]) as $x) q('UPDATE menu_items SET stock_quantity = stock_quantity + ? WHERE id=?', [$x['quantity'], $x['menu_item_id']]);
            q("UPDATE orders SET order_status='cancelled' WHERE id=?", [$id]); q('DELETE FROM kitchen_orders WHERE order_id=?', [$id]);
            if ($o['invoice_id']) q('DELETE FROM invoices WHERE id=?', [$o['invoice_id']]);
            if ($o['table_id'] && !val("SELECT 1 FROM orders WHERE table_id=? AND order_status='open' LIMIT 1", [$o['table_id']])) q("UPDATE restaurant_tables SET status='available' WHERE id=?", [$o['table_id']]);
            if ($o['booking_id']) rebuild_invoice((int)$o['booking_id']);
            audit('cancel', 'orders', $id); $pdo->commit(); flash('Order cancelled.');
        }
    } catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); flash($ex->getMessage(), 'danger'); }
    redirect('modules/orders/details.php?id=' . $id);
}
$items = rows('SELECT * FROM order_items WHERE order_id=? ORDER BY id', [$id]);
$inv = $o['invoice_id'] ? row('SELECT * FROM invoices WHERE id=?', [$o['invoice_id']]) : null;
$k = row('SELECT * FROM kitchen_orders WHERE order_id=?', [$id]);
$pageTitle = 'Order ' . $o['order_number'];
include ROOT . '/includes/header.php';
?>
<div class="d-flex flex-wrap gap-2 mb-3 align-items-center"><a href="index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a><h4 class="mb-0"><?= e($o['order_number']) ?></h4><?= badge(ucfirst($o['order_status']), status_class($o['order_status'])) ?>
 <?= $k ? badge('Kitchen: ' . ucfirst($k['kitchen_status']), status_class($k['kitchen_status'])) : '' ?>
 <div class="ms-auto d-flex gap-2"><a target="_blank" class="btn btn-sm btn-outline-dark" href="<?= e(url('print/kitchen_token.php?id=' . $id)) ?>">Kitchen token</a>
 <?php if ($o['order_type'] !== 'room_service'): ?><a target="_blank" class="btn btn-sm btn-outline-dark" href="<?= e(url('print/restaurant_receipt.php?id=' . $id)) ?>">Print bill</a><?php endif; ?></div></div>
<div class="row g-3"><div class="col-lg-8"><div class="card"><div class="card-header fw-semibold"><?= e(ORDER_TYPES[$o['order_type']]) ?> &middot; <?= e($o['table_number'] ? 'Table ' . $o['table_number'] : ($o['room_number'] ? 'Room ' . $o['room_number'] . ' (' . $o['full_name'] . ')' : 'Takeaway')) ?> &middot; <?= e(dt($o['order_date'])) ?></div>
 <div class="table-responsive"><table class="table mb-0"><thead><tr><th>Item</th><th class="text-end">Qty</th><th class="text-end">Price</th><th class="text-end">Total</th></tr></thead><tbody>
 <?php foreach ($items as $x): $ad = rows('SELECT * FROM order_item_addons WHERE order_item_id=?', [$x['id']]); ?><tr><td><?= e($x['item_name']) ?><?php foreach ($ad as $a): ?><div class="small text-muted">+ <?= e($a['addon_name']) ?></div><?php endforeach; ?><?php if ($x['item_notes']): ?><div class="small text-info"><?= e($x['item_notes']) ?></div><?php endif; ?></td><td class="text-end"><?= (int)$x['quantity'] ?></td><td class="text-end"><?= money($x['unit_price']) ?></td><td class="text-end"><?= money($x['total_price']) ?></td></tr><?php endforeach; ?></tbody>
 <tfoot><tr><td colspan="3" class="text-end">Subtotal</td><td class="text-end"><?= money($o['subtotal']) ?></td></tr><?php if ($o['discount'] > 0): ?><tr><td colspan="3" class="text-end">Discount</td><td class="text-end">- <?= money($o['discount']) ?></td></tr><?php endif; ?>
 <?php if ($o['tax'] > 0): ?><tr><td colspan="3" class="text-end">Tax</td><td class="text-end"><?= money($o['tax']) ?></td></tr><?php endif; ?><?php if ($o['service_charges'] > 0): ?><tr><td colspan="3" class="text-end">Service charge</td><td class="text-end"><?= money($o['service_charges']) ?></td></tr><?php endif; ?>
 <tr class="fw-bold"><td colspan="3" class="text-end">Total</td><td class="text-end"><?= money($o['grand_total']) ?></td></tr></tfoot></table></div>
 <?php if ($o['notes']): ?><div class="card-footer small">Note: <?= e($o['notes']) ?></div><?php endif; ?></div></div>
<div class="col-lg-4"><div class="card"><div class="card-body">
 <?php if ($o['order_type'] === 'room_service'): ?><div class="alert alert-info small mb-0">Charged to the room bill of <b><?= e($o['full_name']) ?></b> (Room <?= e($o['room_number']) ?>). It is settled at check-out.</div>
 <?php elseif ($o['order_status'] === 'cancelled'): ?><div class="text-muted">Order cancelled.</div>
 <?php else: $rem = $inv ? (float)$inv['remaining_amount'] : (float)$o['grand_total']; ?>
  <?php if ($inv): ?><div class="d-flex justify-content-between"><span>Paid</span><b class="text-success"><?= money($inv['paid_amount']) ?></b></div><div class="d-flex justify-content-between"><span>Remaining</span><b class="text-danger"><?= money($inv['remaining_amount']) ?></b></div>
   <div class="small mt-1"><a href="<?= e(url('modules/billing/details.php?id=' . $inv['id'])) ?>"><?= e($inv['invoice_number']) ?></a> <?= badge(ucfirst($inv['invoice_status']), status_class($inv['invoice_status'])) ?></div><?php endif; ?>
  <?php if ($rem > 0 && can('payments')): ?><hr><form method="post" class="row g-2"><?= csrf_field() ?><input type="hidden" name="_action" value="pay">
   <div class="col-12"><label class="small">Amount</label><input type="number" step="any" min="1" max="<?= e($rem + 0) ?>" name="amount" value="<?= e($rem + 0) ?>" class="form-control"></div>
   <div class="col-12"><select name="payment_method" class="form-select"><?php foreach (PAYMENT_METHODS as $m => $l): ?><option value="<?= $m ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
   <div class="col-12"><button class="btn btn-gold w-100">Receive payment</button></div></form><?php endif; ?>
  <?php if (!$inv): ?><form method="post" class="mt-2"><?= csrf_field() ?><input type="hidden" name="_action" value="bill"><button class="btn btn-outline-dark w-100">Generate bill only</button></form><?php endif; ?>
 <?php endif; ?>
 <?php if ($o['order_status'] === 'open'): ?><form method="post" class="mt-3" onsubmit="return confirm('Cancel this order?')"><?= csrf_field() ?><input type="hidden" name="_action" value="cancel"><button class="btn btn-outline-danger btn-sm w-100">Cancel order</button></form><?php endif; ?>
</div></div></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
