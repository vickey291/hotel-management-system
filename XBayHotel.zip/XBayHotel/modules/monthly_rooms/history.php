<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('monthly');
$tid = (int)($_GET['tenant_id'] ?? 0);
$t = row('SELECT mt.*, g.full_name, r.room_number FROM monthly_tenants mt JOIN guests g ON g.id=mt.guest_id JOIN rooms r ON r.id=mt.room_id WHERE mt.id=?', [$tid]);
if (!$t) { flash('Tenant not found.', 'danger'); redirect('modules/monthly_rooms/'); }
$pageTitle = 'Tenant history';
$inv = rows('SELECT * FROM monthly_rent_invoices WHERE tenant_id=? ORDER BY billing_month DESC', [$tid]);
$pay = rows('SELECT p.*, i.billing_month, u.full_name AS who FROM tenant_payments p JOIN monthly_rent_invoices i ON i.id=p.rent_invoice_id LEFT JOIN users u ON u.id=p.received_by WHERE p.tenant_id=? ORDER BY p.id DESC', [$tid]);
$bal = array_sum(array_map(fn($i) => $i['total_amount'] - $i['paid_amount'], $inv));
include ROOT . '/includes/header.php';
?>
<a href="index.php" class="btn btn-sm btn-outline-secondary mb-3"><i class="bi bi-arrow-left"></i></a>
<div class="card mb-3"><div class="card-body d-flex flex-wrap justify-content-between"><div><h5 class="mb-0"><?= e($t['full_name']) ?> &mdash; Room <?= e($t['room_number']) ?></h5><div class="small text-muted"><?= e($t['contract_number']) ?> &middot; rent <?= money($t['monthly_rent']) ?>/month</div></div><div class="text-end"><div class="small text-muted">Current balance</div><div class="fs-4 fw-bold <?= $bal > 0 ? 'text-danger' : 'text-success' ?>"><?= money($bal) ?></div></div></div></div>
<div class="row g-3"><div class="col-lg-7"><div class="card"><div class="card-header fw-semibold">Monthly invoices</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Month</th><th>Total</th><th>Paid</th><th>Status</th></tr></thead><tbody>
<?php foreach ($inv as $i): ?><tr><td><?= e(date('M Y', strtotime($i['billing_month'] . '-01'))) ?></td><td><?= money($i['total_amount']) ?></td><td><?= money($i['paid_amount']) ?></td><td><?= badge(ucfirst($i['invoice_status']), status_class($i['invoice_status'])) ?></td></tr><?php endforeach; ?></tbody></table></div></div></div>
<div class="col-lg-5"><div class="card"><div class="card-header fw-semibold">Payments</div><div class="table-responsive"><table class="table table-sm mb-0"><tbody>
<?php foreach ($pay as $p): ?><tr><td><?= e(dt($p['payment_date'], 'd M y')) ?><div class="small text-muted"><?= e($p['receipt_number']) ?></div></td><td><?= e(date('M Y', strtotime($p['billing_month'] . '-01'))) ?></td><td class="text-end"><?= money($p['amount']) ?></td><td><a target="_blank" href="<?= e(url('print/monthly_receipt.php?id=' . $p['id'])) ?>"><i class="bi bi-printer"></i></a></td></tr><?php endforeach; if (!$pay) echo '<tr><td class="text-muted">No payments yet.</td></tr>'; ?></tbody></table></div></div></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
