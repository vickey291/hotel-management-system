<?php
require_once __DIR__ . '/../../includes/functions.php';
require_once ROOT . '/includes/monthly.php';
require_perm('monthly');
$pageTitle = 'Monthly Rent';
$tid = (int)($_GET['tenant_id'] ?? 0);
$month = preg_match('/^\d{4}-\d{2}$/', $_GET['month'] ?? '') ? $_GET['month'] : '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $a = $_POST['_action'] ?? '';
        if ($a === 'generate') { $n = generate_monthly_invoices($_POST['month'] ?? ''); flash("$n new rent invoice(s) created.", $n ? 'success' : 'info'); }
        elseif ($a === 'charges') {
            $iid = (int)$_POST['invoice_id'];
            q('UPDATE monthly_rent_invoices SET electricity_charges=?, water_charges=?, other_charges=?, discount=? WHERE id=?', [max(0, (float)$_POST['electricity']), max(0, (float)$_POST['water']), max(0, (float)$_POST['other']), max(0, (float)$_POST['discount']), $iid]);
            recalc_monthly_invoice($iid); flash('Charges updated.');
        } elseif ($a === 'pay') {
            $iid = (int)$_POST['invoice_id']; $i = row('SELECT * FROM monthly_rent_invoices WHERE id=?', [$iid]); if (!$i) throw new RuntimeException('Invoice not found.');
            $amt = round((float)$_POST['amount'], 2); $due = $i['total_amount'] - $i['paid_amount'];
            if ($amt <= 0 || $amt > $due + 0.009) throw new RuntimeException('Enter an amount between 1 and ' . number_format($due) . '.');
            q('INSERT INTO tenant_payments (tenant_id, rent_invoice_id, amount, payment_method, receipt_number, received_by) VALUES (?,?,?,?,?,?)', [$i['tenant_id'], $iid, $amt, array_key_exists($_POST['method'], PAYMENT_METHODS) ? $_POST['method'] : 'cash', next_number('TR-', 'tenant_payments'), user()['id']]);
            $pid = (int)db()->lastInsertId(); recalc_monthly_invoice($iid); audit('payment', 'tenant_payments', $pid, "Rent {$i['invoice_number']} $amt");
            flash('Rent received. Use the print icon in the list for the receipt.');
        }
    } catch (Throwable $ex) { flash($ex->getMessage(), 'danger'); }
    redirect($_SERVER['REQUEST_URI']);
}
generate_monthly_invoices(date('Y-m'));
$sql = "SELECT i.*, mt.contract_number, g.full_name, r.room_number, (SELECT MAX(id) FROM tenant_payments p WHERE p.rent_invoice_id=i.id) AS last_pay
        FROM monthly_rent_invoices i JOIN monthly_tenants mt ON mt.id=i.tenant_id JOIN guests g ON g.id=mt.guest_id JOIN rooms r ON r.id=mt.room_id WHERE 1=1"; $p = [];
if ($tid) { $sql .= ' AND i.tenant_id=?'; $p[] = $tid; }
if ($month) { $sql .= ' AND i.billing_month=?'; $p[] = $month; }
if (($_GET['show'] ?? 'open') === 'open') $sql .= " AND i.invoice_status <> 'paid'";
$list = rows($sql . ' ORDER BY i.billing_month DESC, r.room_number LIMIT 400', $p);
include ROOT . '/includes/header.php';
?>
<div class="d-flex flex-wrap gap-2 align-items-end mb-3">
 <form class="d-flex gap-2"><?php if ($tid): ?><input type="hidden" name="tenant_id" value="<?= $tid ?>"><?php endif; ?><input type="month" name="month" value="<?= e($month) ?>" class="form-control">
  <select name="show" class="form-select w-auto"><option value="open" <?= ($_GET['show'] ?? 'open') === 'open' ? 'selected' : '' ?>>Unpaid only</option><option value="all" <?= ($_GET['show'] ?? '') === 'all' ? 'selected' : '' ?>>All</option></select><button class="btn btn-outline-dark">Filter</button></form>
 <form method="post" class="ms-auto d-flex gap-2"><?= csrf_field() ?><input type="hidden" name="_action" value="generate"><input type="month" name="month" value="<?= date('Y-m') ?>" class="form-control"><button class="btn btn-gold text-nowrap">Generate rent invoices</button></form></div>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Month</th><th>Room</th><th>Tenant</th><th>Rent</th><th>Extras</th><th>Total</th><th>Paid</th><th>Due date</th><th>Status</th><th>Collect / adjust</th></tr></thead><tbody>
<?php foreach ($list as $i): $due = $i['total_amount'] - $i['paid_amount']; $late = $due > 0 && $i['due_date'] < date('Y-m-d'); ?>
 <tr><td><?= e(date('M Y', strtotime($i['billing_month'] . '-01'))) ?><div class="small text-muted"><?= e($i['invoice_number']) ?></div></td><td><b><?= e($i['room_number']) ?></b></td><td><?= e($i['full_name']) ?></td><td><?= money($i['rent_amount']) ?></td>
 <td class="small">E <?= number_format($i['electricity_charges']) ?> / W <?= number_format($i['water_charges']) ?> / O <?= number_format($i['other_charges']) ?><?= $i['discount'] > 0 ? ' / -' . number_format($i['discount']) : '' ?></td>
 <td><b><?= money($i['total_amount']) ?></b></td><td class="text-success"><?= money($i['paid_amount']) ?></td><td class="<?= $late ? 'text-danger fw-bold' : '' ?>"><?= e(dt($i['due_date'], 'd M')) ?><?= $late ? ' (overdue)' : '' ?></td><td><?= badge(ucfirst($i['invoice_status']), status_class($i['invoice_status'])) ?></td>
 <td class="text-nowrap"><?php if ($due > 0): ?><form method="post" class="d-inline-flex gap-1"><?= csrf_field() ?><input type="hidden" name="_action" value="pay"><input type="hidden" name="invoice_id" value="<?= (int)$i['id'] ?>"><input type="number" step="any" name="amount" value="<?= e($due + 0) ?>" class="form-control form-control-sm" style="width:90px"><select name="method" class="form-select form-select-sm" style="width:90px"><?php foreach (PAYMENT_METHODS as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?></option><?php endforeach; ?></select><button class="btn btn-sm btn-gold">Receive</button></form><?php endif; ?>
  <button class="btn btn-sm btn-outline-dark" type="button" data-bs-toggle="collapse" data-bs-target="#c<?= (int)$i['id'] ?>"><i class="bi bi-sliders"></i></button>
  <?php if ($i['last_pay']): ?><a target="_blank" class="btn btn-sm btn-outline-dark" href="<?= e(url('print/monthly_receipt.php?id=' . $i['last_pay'])) ?>"><i class="bi bi-printer"></i></a><?php endif; ?></td></tr>
 <tr class="collapse" id="c<?= (int)$i['id'] ?>"><td colspan="10" class="bg-light"><form method="post" class="row g-2 align-items-end"><?= csrf_field() ?><input type="hidden" name="_action" value="charges"><input type="hidden" name="invoice_id" value="<?= (int)$i['id'] ?>">
  <div class="col-auto"><label class="small">Electricity</label><input type="number" step="any" name="electricity" value="<?= e($i['electricity_charges'] + 0) ?>" class="form-control form-control-sm"></div><div class="col-auto"><label class="small">Water</label><input type="number" step="any" name="water" value="<?= e($i['water_charges'] + 0) ?>" class="form-control form-control-sm"></div>
  <div class="col-auto"><label class="small">Repair / other</label><input type="number" step="any" name="other" value="<?= e($i['other_charges'] + 0) ?>" class="form-control form-control-sm"></div><div class="col-auto"><label class="small">Discount</label><input type="number" step="any" name="discount" value="<?= e($i['discount'] + 0) ?>" class="form-control form-control-sm"></div>
  <div class="col-auto"><button class="btn btn-sm btn-outline-dark">Save charges</button></div></form></td></tr>
<?php endforeach; if (!$list) echo '<tr><td colspan="10" class="text-center text-muted py-4">Nothing to show.</td></tr>'; ?></tbody></table></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
