<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('monthly');
$id = (int)($_GET['id'] ?? 0);
$t = row('SELECT mt.*, g.full_name, g.father_husband_name, g.phone, g.address, g.city, r.room_number, r.floor_number FROM monthly_tenants mt JOIN guests g ON g.id=mt.guest_id JOIN rooms r ON r.id=mt.room_id WHERE mt.id=?', [$id]);
if (!$t) { flash('Contract not found.', 'danger'); redirect('modules/monthly_rooms/'); }
if (isset($_GET['download']) && $t['agreement_file']) {
    $path = realpath(ROOT . '/storage/' . $t['agreement_file']);
    if ($path && str_starts_with($path, realpath(ROOT . '/storage')) && is_file($path)) { audit('view_agreement', 'monthly_tenants', $id); header('Content-Type: ' . (new finfo(FILEINFO_MIME_TYPE))->file($path)); header('X-Content-Type-Options: nosniff'); readfile($path); exit; }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $a = $_POST['_action'] ?? '';
    if ($a === 'end') { q("UPDATE monthly_tenants SET tenant_status='ended', end_date=COALESCE(end_date, CURDATE()) WHERE id=?", [$id]); audit('end', 'monthly_tenants', $id); flash('Tenancy ended. The room is free now.'); }
    if ($a === 'toggle') { q("UPDATE monthly_tenants SET billing_status=IF(billing_status='active','suspended','active') WHERE id=?", [$id]); flash('Billing status changed.'); }
    if ($a === 'rent') { q('UPDATE monthly_tenants SET monthly_rent=?, security_deposit=?, end_date=?, rent_due_day=? WHERE id=?', [(float)$_POST['monthly_rent'], (float)$_POST['security_deposit'], $_POST['end_date'] ?: null, min(28, max(1, (int)$_POST['rent_due_day'])), $id]); flash('Contract updated (applies to future invoices).'); }
    redirect('modules/monthly_rooms/contract.php?id=' . $id);
}
$pageTitle = 'Contract ' . $t['contract_number'];
include ROOT . '/includes/header.php';
$H = hotel();
?>
<div class="d-flex gap-2 mb-3 no-print"><a href="index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a><button onclick="window.print()" class="btn btn-sm btn-outline-dark"><i class="bi bi-printer me-1"></i>Print agreement</button>
 <?php if ($t['agreement_file']): ?><a class="btn btn-sm btn-outline-dark" target="_blank" href="?id=<?= $id ?>&download=1">Signed copy</a><?php endif; ?></div>
<div class="row g-3"><div class="col-lg-8"><div class="card"><div class="card-body p-4">
 <div class="text-center mb-3"><h4 class="fw-bold mb-0"><?= e(strtoupper($H['hotel_name'])) ?></h4><div class="small text-muted"><?= e($H['tagline']) ?> &middot; <?= e($H['address']) ?>, <?= e($H['city']) ?> &middot; <?= e($H['phone']) ?></div><h5 class="mt-3 text-decoration-underline">ROOM RENTAL AGREEMENT</h5><div class="small">Contract No: <b><?= e($t['contract_number']) ?></b></div></div>
 <p>This agreement is made between <b><?= e($H['hotel_name']) ?></b> (Owner) and <b><?= e($t['full_name']) ?></b>, <?= e($t['father_husband_name'] ? 'S/o / D/o / W/o ' . $t['father_husband_name'] . ', ' : '') ?>resident of <?= e($t['address'] . ' ' . $t['city']) ?>, phone <?= e($t['phone']) ?> (Tenant), for <b>Room <?= e($t['room_number']) ?></b> (<?= e($t['floor_number']) ?>).</p>
 <table class="table table-sm w-auto"><tr><td>Monthly rent</td><td><b><?= money($t['monthly_rent']) ?></b></td></tr><tr><td>Security deposit</td><td><b><?= money($t['security_deposit']) ?></b></td></tr><tr><td>Start date</td><td><?= e(dt($t['start_date'], 'd M Y')) ?></td></tr><tr><td>End date</td><td><?= e($t['end_date'] ? dt($t['end_date'], 'd M Y') : 'Open ended') ?></td></tr><tr><td>Rent due on</td><td>Day <?= (int)$t['rent_due_day'] ?> of every month</td></tr></table>
 <ol class="small"><li>Rent is payable monthly in advance by the due date. Electricity, water and other service charges are billed separately.</li><li>The room shall be used only for residence and not sublet.</li><li>Damages beyond normal use will be deducted from the security deposit.</li><li>Either party may end this agreement with 30 days' written notice.</li></ol>
 <div class="d-flex justify-content-between mt-5 small"><span>_______________<br>Tenant signature</span><span>_______________<br>For <?= e($H['hotel_name']) ?></span></div>
 <?php if ($t['notes']): ?><div class="small text-muted mt-3">Notes: <?= e($t['notes']) ?></div><?php endif; ?>
</div></div></div>
<div class="col-lg-4 no-print"><div class="card"><div class="card-header fw-semibold">Manage contract</div><div class="card-body">
 <form method="post" class="row g-2"><?= csrf_field() ?><input type="hidden" name="_action" value="rent">
  <div class="col-12"><label class="small">Monthly rent</label><input type="number" step="any" name="monthly_rent" value="<?= e($t['monthly_rent'] + 0) ?>" class="form-control form-control-sm"></div>
  <div class="col-12"><label class="small">Security deposit</label><input type="number" step="any" name="security_deposit" value="<?= e($t['security_deposit'] + 0) ?>" class="form-control form-control-sm"></div>
  <div class="col-6"><label class="small">End date</label><input type="date" name="end_date" value="<?= e($t['end_date']) ?>" class="form-control form-control-sm"></div>
  <div class="col-6"><label class="small">Due day</label><input type="number" min="1" max="28" name="rent_due_day" value="<?= (int)$t['rent_due_day'] ?>" class="form-control form-control-sm"></div>
  <div class="col-12"><button class="btn btn-sm btn-outline-dark">Update</button></div></form><hr>
 <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="_action" value="toggle"><button class="btn btn-sm btn-outline-warning"><?= $t['billing_status'] === 'active' ? 'Suspend billing' : 'Resume billing' ?></button></form>
 <?php if ($t['tenant_status'] === 'active'): ?><form method="post" class="d-inline" onsubmit="return confirm('End this tenancy and free the room?')"><?= csrf_field() ?><input type="hidden" name="_action" value="end"><button class="btn btn-sm btn-outline-danger">End tenancy</button></form><?php endif; ?>
</div></div></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
