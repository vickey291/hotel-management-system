<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('monthly');
$pageTitle = 'New Monthly Tenant';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = db();
    try {
        $pdo->beginTransaction();
        $rid = (int)$_POST['room_id'];
        $room = row("SELECT r.*, t.booking_mode FROM rooms r JOIN room_types t ON t.id=r.room_type_id WHERE r.id=? FOR UPDATE", [$rid]);
        if (!$room || $room['booking_mode'] !== 'monthly') throw new RuntimeException('Choose a room of a Monthly type.');
        if (val("SELECT 1 FROM monthly_tenants WHERE room_id=? AND tenant_status='active'", [$rid])) throw new RuntimeException('This room already has an active tenant.');
        if (val("SELECT 1 FROM booking_rooms WHERE room_id=? AND room_status IN ('reserved','checked_in')", [$rid])) throw new RuntimeException('This room has a booking.');
        if (($_POST['guest_mode'] ?? 'new') === 'old') { $gid = (int)$_POST['guest_id']; if (!val('SELECT id FROM guests WHERE id=?', [$gid])) throw new RuntimeException('Select a guest.'); }
        else {
            $name = trim($_POST['full_name']); if ($name === '') throw new RuntimeException('Tenant name is required.');
            q('INSERT INTO guests (guest_code, full_name, father_husband_name, phone, address, city) VALUES (?,?,?,?,?,?)', [guest_code(), $name, trim($_POST['father_husband_name']), trim($_POST['phone']), trim($_POST['address']), trim($_POST['city'])]);
            $gid = (int)$pdo->lastInsertId();
            if (trim($_POST['cnic']) !== '') q('INSERT INTO guest_documents (guest_id, document_type, document_number, front_image, back_image) VALUES (?,?,?,?,?)', [$gid, 'CNIC', trim($_POST['cnic']), upload_file('cnic_front', 'guest_documents', true, true), upload_file('cnic_back', 'guest_documents', true, true)]);
        }
        $rent = (float)$_POST['monthly_rent']; if ($rent <= 0) throw new RuntimeException('Enter the monthly rent.');
        q('INSERT INTO monthly_tenants (guest_id, room_id, contract_number, monthly_rent, security_deposit, start_date, end_date, rent_due_day, agreement_file, notes) VALUES (?,?,?,?,?,?,?,?,?,?)',
            [$gid, $rid, next_number('MC-', 'monthly_tenants'), $rent, max(0, (float)$_POST['security_deposit']), $_POST['start_date'], $_POST['end_date'] ?: null, min(28, max(1, (int)$_POST['rent_due_day'])), upload_file('agreement', 'agreements', true, true), trim($_POST['notes'])]);
        $tid = (int)$pdo->lastInsertId(); audit('create', 'monthly_tenants', $tid);
        $pdo->commit(); flash('Tenant added. Rent invoice for this month is created automatically.');
        redirect('modules/monthly_rooms/contract.php?id=' . $tid);
    } catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); flash($ex->getMessage(), 'danger'); }
}
$rooms = rows("SELECT r.* FROM rooms r JOIN room_types t ON t.id=r.room_type_id WHERE t.booking_mode='monthly' AND r.is_active=1 AND NOT EXISTS (SELECT 1 FROM monthly_tenants m WHERE m.room_id=r.id AND m.tenant_status='active') ORDER BY r.room_number");
$guests = rows('SELECT id, full_name, guest_code FROM guests ORDER BY full_name LIMIT 500');
include ROOT . '/includes/header.php';
?>
<form method="post" enctype="multipart/form-data" class="card" style="max-width:900px"><?= csrf_field() ?><div class="card-header fw-semibold">Monthly tenant &amp; contract</div><div class="card-body row g-3">
 <div class="col-12"><div class="form-check form-check-inline"><input class="form-check-input" type="radio" name="guest_mode" value="new" id="n1" checked onchange="g()"><label for="n1" class="form-check-label">New tenant</label></div>
  <div class="form-check form-check-inline"><input class="form-check-input" type="radio" name="guest_mode" value="old" id="n2" onchange="g()"><label for="n2" class="form-check-label">Existing guest</label></div></div>
 <div class="col-12" id="old" style="display:none"><select name="guest_id" class="form-select"><option value="">-- select --</option><?php foreach ($guests as $g): ?><option value="<?= (int)$g['id'] ?>"><?= e($g['full_name'] . ' (' . $g['guest_code'] . ')') ?></option><?php endforeach; ?></select></div>
 <div id="new" class="row g-3 m-0 p-0">
  <div class="col-md-6"><label class="form-label">Tenant name *</label><input name="full_name" class="form-control"></div><div class="col-md-6"><label class="form-label">Father / Husband name</label><input name="father_husband_name" class="form-control"></div>
  <div class="col-md-4"><label class="form-label">CNIC</label><input name="cnic" class="form-control" placeholder="00000-0000000-0"></div><div class="col-md-4"><label class="form-label">Phone</label><input name="phone" class="form-control"></div><div class="col-md-4"><label class="form-label">City</label><input name="city" class="form-control"></div>
  <div class="col-md-6"><label class="form-label">CNIC front</label><input type="file" name="cnic_front" class="form-control" accept="image/*,application/pdf"></div><div class="col-md-6"><label class="form-label">CNIC back</label><input type="file" name="cnic_back" class="form-control" accept="image/*,application/pdf"></div>
  <div class="col-12"><label class="form-label">Address</label><input name="address" class="form-control"></div></div>
 <hr class="my-1">
 <div class="col-md-4"><label class="form-label">Room *</label><select name="room_id" class="form-select" required onchange="document.getElementById('rent').value=this.selectedOptions[0].dataset.p"><option value="">-- monthly rooms --</option><?php foreach ($rooms as $r): ?><option value="<?= (int)$r['id'] ?>" data-p="<?= e($r['room_price'] + 0) ?>"><?= e($r['room_number'] . ' - ' . $r['room_name']) ?></option><?php endforeach; ?></select></div>
 <div class="col-md-4"><label class="form-label">Monthly rent *</label><input type="number" step="any" id="rent" name="monthly_rent" class="form-control" required></div>
 <div class="col-md-4"><label class="form-label">Security deposit</label><input type="number" step="any" name="security_deposit" value="0" class="form-control"></div>
 <div class="col-md-4"><label class="form-label">Agreement start *</label><input type="date" name="start_date" value="<?= date('Y-m-d') ?>" class="form-control" required></div>
 <div class="col-md-4"><label class="form-label">Agreement end</label><input type="date" name="end_date" class="form-control"></div>
 <div class="col-md-4"><label class="form-label">Rent due day of month</label><input type="number" min="1" max="28" name="rent_due_day" value="1" class="form-control"></div>
 <div class="col-md-6"><label class="form-label">Signed agreement (scan)</label><input type="file" name="agreement" class="form-control" accept="image/*,application/pdf"></div>
 <div class="col-md-6"><label class="form-label">Notes</label><input name="notes" class="form-control"></div>
 <div class="col-12"><button class="btn btn-gold">Save contract</button> <a href="index.php" class="btn btn-outline-secondary">Cancel</a></div></div></form>
<?php $inlineScript = "function g(){var o=document.getElementById('n2').checked;document.getElementById('old').style.display=o?'':'none';document.getElementById('new').style.display=o?'none':'';}"; include ROOT . '/includes/footer.php'; ?>
