<?php
require_once __DIR__ . '/../../includes/functions.php';
require_once ROOT . '/includes/monthly.php';
require_perm('monthly');
$pageTitle = 'Monthly Rooms';
generate_monthly_invoices(date('Y-m'));   // rent due is created automatically every month
$list = rows("SELECT mt.*, g.full_name, g.phone, r.room_number,
  (SELECT COALESCE(SUM(total_amount-paid_amount),0) FROM monthly_rent_invoices i WHERE i.tenant_id=mt.id) AS balance,
  (SELECT MAX(payment_date) FROM tenant_payments p WHERE p.tenant_id=mt.id) AS last_payment
  FROM monthly_tenants mt JOIN guests g ON g.id=mt.guest_id JOIN rooms r ON r.id=mt.room_id ORDER BY mt.tenant_status, r.room_number");
include ROOT . '/includes/header.php';
?>
<div class="d-flex flex-wrap gap-2 mb-3"><a href="rent.php" class="btn btn-outline-dark"><i class="bi bi-cash-stack me-1"></i>Rent invoices &amp; collection</a><a href="tenant_add.php" class="btn btn-gold ms-auto"><i class="bi bi-plus-lg me-1"></i>New tenant / contract</a></div>
<div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Room</th><th>Tenant</th><th>Contract</th><th>Rent</th><th>Deposit</th><th>Agreement</th><th>Last payment</th><th class="text-end">Outstanding</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($list as $t): ?><tr><td><b><?= e($t['room_number']) ?></b></td><td><?= e($t['full_name']) ?><div class="small text-muted"><?= e($t['phone']) ?></div></td><td><?= e($t['contract_number']) ?></td><td><?= money($t['monthly_rent']) ?></td><td><?= money($t['security_deposit']) ?></td>
 <td class="small"><?= e(dt($t['start_date'], 'd M y')) ?> &rarr; <?= e($t['end_date'] ? dt($t['end_date'], 'd M y') : 'open') ?></td><td class="small"><?= e($t['last_payment'] ? dt($t['last_payment'], 'd M y') : '-') ?></td>
 <td class="text-end <?= $t['balance'] > 0 ? 'text-danger fw-bold' : '' ?>"><?= money($t['balance']) ?></td><td><?= badge(ucfirst($t['tenant_status']), $t['tenant_status'] === 'active' ? 'success' : 'secondary') ?></td>
 <td class="text-end text-nowrap"><a class="btn btn-sm btn-outline-dark" href="contract.php?id=<?= (int)$t['id'] ?>">Contract</a> <a class="btn btn-sm btn-gold" href="rent.php?tenant_id=<?= (int)$t['id'] ?>">Rent</a> <a class="btn btn-sm btn-outline-dark" href="history.php?tenant_id=<?= (int)$t['id'] ?>"><i class="bi bi-clock-history"></i></a></td></tr>
<?php endforeach; if (!$list) echo '<tr><td colspan="10" class="text-center text-muted py-4">No monthly tenants yet. Add rooms of a "Monthly" type first, then create a contract.</td></tr>'; ?></tbody></table></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
