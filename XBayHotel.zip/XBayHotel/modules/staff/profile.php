<?php
require_once __DIR__ . '/../../includes/functions.php';
require_login();
$pageTitle = 'Change password';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $u = row('SELECT * FROM users WHERE id=?', [user()['id']]);
        if (!password_verify($_POST['current'] ?? '', $u['password_hash'])) throw new RuntimeException('Current password is wrong.');
        if (strlen($_POST['new'] ?? '') < 8) throw new RuntimeException('New password must be at least 8 characters.');
        if ($_POST['new'] !== $_POST['confirm']) throw new RuntimeException('New passwords do not match.');
        q('UPDATE users SET password_hash=? WHERE id=?', [password_hash($_POST['new'], PASSWORD_DEFAULT), $u['id']]);
        unset($_SESSION['must_change_pw']); audit('password', 'users', (int)$u['id'], 'Password changed'); flash('Password changed.'); redirect('modules/dashboard/');
    } catch (Throwable $ex) { flash($ex->getMessage(), 'danger'); }
}
include ROOT . '/includes/header.php';
?>
<div class="card" style="max-width:460px"><div class="card-header fw-semibold">Change password</div><div class="card-body"><form method="post" class="row g-3"><?= csrf_field() ?>
 <div class="col-12"><label class="form-label">Current password <?php if (!empty($_SESSION['must_change_pw'])): ?><small class="text-muted">(default: Admin@123)</small><?php endif; ?></label><input type="password" name="current" class="form-control" required></div>
 <div class="col-12"><label class="form-label">New password</label><input type="password" name="new" minlength="8" class="form-control" required></div>
 <div class="col-12"><label class="form-label">Confirm new password</label><input type="password" name="confirm" minlength="8" class="form-control" required></div>
 <div class="col-12"><button class="btn btn-gold">Update password</button></div></form></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
