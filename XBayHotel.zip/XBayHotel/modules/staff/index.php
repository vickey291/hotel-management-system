<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = ['title' => 'Staff Management', 'table' => 'users', 'perm' => 'staff',
 'select' => 'SELECT u.*, r.role_name, (SELECT MAX(login_time) FROM login_logs l WHERE l.user_id=u.id AND l.status="success") AS last_login FROM users u JOIN roles r ON r.id=u.role_id ORDER BY u.full_name',
 'columns' => ['full_name' => 'Name', 'username' => 'Username', 'role_name' => 'Role', 'phone' => 'Phone', 'last_login' => 'Last login', 'is_active' => 'Status'], 'format' => ['is_active' => 'bool'],
 'toolbar' => '<a class="btn btn-outline-dark" href="roles.php">Roles</a><a class="btn btn-outline-dark" href="permissions.php">Permissions</a><a class="btn btn-outline-dark" href="logs.php">Activity log</a>',
 'fields' => [['name' => 'full_name', 'label' => 'Full name', 'required' => true], ['name' => 'username', 'label' => 'Username', 'required' => true],
  ['name' => 'role_id', 'label' => 'Role', 'type' => 'select', 'required' => true, 'sql' => 'SELECT id, role_name FROM roles ORDER BY id'], ['name' => 'phone', 'label' => 'Phone'], ['name' => 'email', 'label' => 'Email', 'type' => 'email'],
  ['name' => 'password', 'label' => 'Password (min 8 characters)', 'type' => 'password', 'required' => true, 'column' => 'password_hash'], ['name' => 'is_active', 'label' => 'Active (can log in)', 'type' => 'checkbox']]];
// The default admin (id of the first Admin) cannot be deleted by accident
if (($_POST['_action'] ?? '') === 'delete' && ((int)($_POST['id'] ?? 0) === (int)(user()['id'] ?? 0))) { require_perm('staff'); flash('You cannot delete your own account.', 'danger'); redirect('modules/staff/'); }
require ROOT . '/includes/crud.php';
