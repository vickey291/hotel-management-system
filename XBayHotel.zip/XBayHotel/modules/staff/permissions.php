<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('staff');
$pageTitle = 'Role Permissions';
$roles = rows('SELECT * FROM roles ORDER BY id'); $perms = rows('SELECT * FROM permissions ORDER BY id');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = db();
    try {
        $pdo->beginTransaction();
        foreach ($roles as $r) {
            if ((int)$r['id'] === 1) continue;                       // Admin always has everything
            q('DELETE FROM role_permissions WHERE role_id=?', [$r['id']]);
            foreach ((array)($_POST['p'][$r['id']] ?? []) as $pid) q('INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (?,?)', [$r['id'], (int)$pid]);
        }
        audit('update', 'role_permissions', null, 'Permissions changed'); $pdo->commit(); flash('Permissions saved. Staff must log in again to get new access.');
    } catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); flash($ex->getMessage(), 'danger'); }
    redirect('modules/staff/permissions.php');
}
$map = []; foreach (rows('SELECT role_id, permission_id FROM role_permissions') as $x) $map[$x['role_id']][$x['permission_id']] = 1;
include ROOT . '/includes/header.php';
?>
<form method="post"><?= csrf_field() ?><div class="card"><div class="table-responsive"><table class="table align-middle mb-0 text-center"><thead><tr><th class="text-start">Permission</th><?php foreach ($roles as $r): ?><th><?= e($r['role_name']) ?></th><?php endforeach; ?></tr></thead><tbody>
<?php foreach ($perms as $p): ?><tr><td class="text-start"><?= e($p['permission_name']) ?> <small class="text-muted">(<?= e($p['permission_key']) ?>)</small></td>
 <?php foreach ($roles as $r): ?><td><?php if ((int)$r['id'] === 1): ?><i class="bi bi-check-circle-fill text-success"></i><?php else: ?><input type="checkbox" class="form-check-input" name="p[<?= (int)$r['id'] ?>][]" value="<?= (int)$p['id'] ?>" <?= !empty($map[$r['id']][$p['id']]) ? 'checked' : '' ?>><?php endif; ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody></table></div>
<div class="card-footer"><button class="btn btn-gold">Save permissions</button> <a class="btn btn-outline-secondary" href="index.php">Back</a></div></div></form>
<?php include ROOT . '/includes/footer.php'; ?>
