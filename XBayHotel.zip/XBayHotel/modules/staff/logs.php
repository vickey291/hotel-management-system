<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('staff');
$pageTitle = 'Activity & Login Logs';
$audit = rows('SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200');
$logins = rows('SELECT l.*, u.full_name FROM login_logs l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 50');
include ROOT . '/includes/header.php';
?>
<div class="row g-3"><div class="col-lg-7"><div class="card"><div class="card-header fw-semibold">Staff activity (audit log)</div><div class="table-responsive" style="max-height:600px"><table class="table table-sm mb-0"><tbody>
<?php foreach ($audit as $a): ?><tr><td class="small text-nowrap"><?= e(dt($a['created_at'], 'd M h:i A')) ?></td><td><?= e($a['full_name'] ?: '-') ?></td><td><?= e($a['module_name']) ?> &middot; <b><?= e($a['action']) ?></b> <span class="text-muted small"><?= e($a['description']) ?></span></td></tr><?php endforeach; ?></tbody></table></div></div></div>
<div class="col-lg-5"><div class="card"><div class="card-header fw-semibold">Logins</div><div class="table-responsive" style="max-height:600px"><table class="table table-sm mb-0"><tbody>
<?php foreach ($logins as $l): ?><tr><td class="small"><?= e(dt($l['login_time'], 'd M h:i A')) ?></td><td><?= e($l['full_name'] ?: $l['username']) ?></td><td><?= badge($l['status'], $l['status'] === 'success' ? 'success' : 'danger') ?></td><td class="small text-muted"><?= e($l['ip_address']) ?></td></tr><?php endforeach; ?></tbody></table></div></div></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
