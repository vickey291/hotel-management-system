<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = ['title' => 'Roles', 'table' => 'roles', 'perm' => 'staff',
 'select' => 'SELECT r.*, (SELECT COUNT(*) FROM users u WHERE u.role_id=r.id) AS staff FROM roles r ORDER BY r.id',
 'columns' => ['role_name' => 'Role', 'description' => 'Description', 'staff' => 'Staff'],
 'toolbar' => '<a class="btn btn-outline-dark" href="permissions.php">Edit permissions</a><a class="btn btn-outline-dark" href="index.php">Staff</a>',
 'fields' => [['name' => 'role_name', 'label' => 'Role name', 'required' => true], ['name' => 'description', 'label' => 'Description', 'col' => 12]]];
require ROOT . '/includes/crud.php';
