<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = [
 'title' => 'Room Types', 'table' => 'room_types', 'perm' => 'rooms',
 'select' => 'SELECT * FROM room_types ORDER BY default_price',
 'columns' => ['type_name' => 'Type', 'booking_mode' => 'Mode', 'default_price' => 'Default Price', 'capacity' => 'Capacity', 'is_active' => 'Status'],
 'format' => ['default_price' => 'money', 'is_active' => 'bool'],
 'fields' => [
  ['name' => 'type_name', 'label' => 'Type name (Standard, Deluxe, VIP, Monthly)', 'required' => true],
  ['name' => 'booking_mode', 'label' => 'Booking mode', 'type' => 'select', 'required' => true, 'options' => ['daily' => 'Daily booking', 'vip' => 'VIP', 'monthly' => 'Monthly / Permanent']],
  ['name' => 'default_price', 'label' => 'Default price (per night / month)', 'type' => 'number', 'required' => true],
  ['name' => 'capacity', 'label' => 'Capacity (persons)', 'type' => 'number', 'step' => '1', 'required' => true, 'default' => 2],
  ['name' => 'description', 'label' => 'Description', 'col' => 12],
  ['name' => 'is_active', 'label' => 'Active', 'type' => 'checkbox'],
 ]];
require ROOT . '/includes/crud.php';
