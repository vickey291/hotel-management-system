<?php header("Location: index.php?action=add"); exit;
