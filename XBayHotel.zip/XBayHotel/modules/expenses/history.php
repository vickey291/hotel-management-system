<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('expenses');
$pageTitle = 'Expense Summary';
$from = $_GET['from'] ?? date('Y-m-01'); $to = $_GET['to'] ?? date('Y-m-d');
$by = rows('SELECT expense_category, COUNT(*) n, SUM(amount) total FROM expenses WHERE expense_date BETWEEN ? AND ? GROUP BY expense_category ORDER BY total DESC', [$from, $to]);
include ROOT . '/includes/header.php';
?>
<form class="row g-2 mb-3"><div class="col-auto"><input type="date" name="from" value="<?= e($from) ?>" class="form-control"></div><div class="col-auto"><input type="date" name="to" value="<?= e($to) ?>" class="form-control"></div><div class="col-auto"><button class="btn btn-outline-dark">Show</button></div><div class="col-auto ms-auto"><a href="index.php" class="btn btn-gold">All expenses</a></div></form>
<div class="card"><table class="table mb-0"><thead><tr><th>Category</th><th class="text-end">Entries</th><th class="text-end">Total</th></tr></thead><tbody>
<?php foreach ($by as $b): ?><tr><td><?= e($b['expense_category']) ?></td><td class="text-end"><?= (int)$b['n'] ?></td><td class="text-end"><?= money($b['total']) ?></td></tr><?php endforeach; ?></tbody>
<tfoot><tr class="fw-bold"><td colspan="2" class="text-end">Total</td><td class="text-end"><?= money(array_sum(array_column($by, 'total'))) ?></td></tr></tfoot></table></div>
<?php include ROOT . '/includes/footer.php'; ?>
