<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = ['title' => 'Expenses', 'table' => 'expenses', 'perm' => 'expenses',
 'select' => 'SELECT e.*, u.full_name AS who FROM expenses e LEFT JOIN users u ON u.id=e.created_by ORDER BY e.expense_date DESC, e.id DESC LIMIT 500',
 'columns' => ['expense_date' => 'Date', 'expense_title' => 'Title', 'expense_category' => 'Category', 'payment_method' => 'Method', 'amount' => 'Amount', 'who' => 'Entered by'],
 'format' => ['expense_date' => 'date', 'amount' => 'money'],
 'toolbar' => '<a class="btn btn-outline-dark" href="history.php">Summary</a>',
 'fields' => [
  ['name' => 'expense_title', 'label' => 'Title', 'required' => true],
  ['name' => 'expense_category', 'label' => 'Category', 'type' => 'select', 'required' => true, 'options' => array_combine($c = ['Salaries', 'Electricity', 'Gas', 'Water', 'Food & Kitchen', 'Housekeeping', 'Maintenance', 'Marketing', 'Rent', 'General'], $c)],
  ['name' => 'amount', 'label' => 'Amount', 'type' => 'number', 'required' => true], ['name' => 'expense_date', 'label' => 'Date', 'type' => 'date', 'required' => true, 'default' => date('Y-m-d')],
  ['name' => 'payment_method', 'label' => 'Paid by', 'type' => 'select', 'required' => true, 'options' => PAYMENT_METHODS], ['name' => 'description', 'label' => 'Notes', 'col' => 12]],
 'after_save' => function ($rid) { q('UPDATE expenses SET created_by = COALESCE(created_by, ?) WHERE id=?', [user()['id'], $rid]); }];
require ROOT . '/includes/crud.php';
