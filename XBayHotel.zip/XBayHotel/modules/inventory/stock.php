<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('inventory');
$pageTitle = 'Stock In / Out';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = db();
    try {
        $iid = (int)$_POST['item_id']; $type = $_POST['type'] ?? ''; $qty = (float)$_POST['quantity'];
        if (!in_array($type, ['in', 'out', 'adjust'], true) || $qty < 0 || ($type !== 'adjust' && $qty <= 0)) throw new RuntimeException('Enter a valid quantity.');
        $pdo->beginTransaction();
        $it = row('SELECT * FROM inventory_items WHERE id=? FOR UPDATE', [$iid]); if (!$it) throw new RuntimeException('Select an item.');
        if ($type === 'out' && $qty > $it['current_stock']) throw new RuntimeException('Not enough stock (available ' . ($it['current_stock'] + 0) . ').');
        $new = $type === 'in' ? $it['current_stock'] + $qty : ($type === 'out' ? $it['current_stock'] - $qty : $qty);
        q('UPDATE inventory_items SET current_stock=? WHERE id=?', [$new, $iid]);
        q('INSERT INTO stock_transactions (inventory_item_id, transaction_type, quantity, reference, created_by) VALUES (?,?,?,?,?)', [$iid, $type, $qty, trim($_POST['reference'] ?? ''), user()['id']]);
        audit('stock_' . $type, 'inventory_items', $iid, "$qty {$it['unit']}"); $pdo->commit(); flash('Stock updated.');
    } catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); flash($ex->getMessage(), 'danger'); }
    redirect('modules/inventory/stock.php');
}
$items = rows('SELECT * FROM inventory_items ORDER BY item_name');
include ROOT . '/includes/header.php';
?>
<div class="row g-3"><div class="col-lg-5"><div class="card"><div class="card-header fw-semibold">Update stock</div><div class="card-body"><form method="post" class="row g-3"><?= csrf_field() ?>
 <div class="col-12"><label class="form-label">Item</label><select name="item_id" class="form-select" required><option value="">-- select --</option><?php foreach ($items as $i): ?><option value="<?= (int)$i['id'] ?>"><?= e($i['item_name'] . ' (' . ($i['current_stock'] + 0) . ' ' . $i['unit'] . ')') ?></option><?php endforeach; ?></select></div>
 <div class="col-6"><label class="form-label">Action</label><select name="type" class="form-select"><option value="in">Stock IN (purchase)</option><option value="out">Stock OUT (used)</option><option value="adjust">Set exact count</option></select></div>
 <div class="col-6"><label class="form-label">Quantity</label><input type="number" step="any" name="quantity" class="form-control" required></div>
 <div class="col-12"><label class="form-label">Reference / note</label><input name="reference" class="form-control" placeholder="Supplier, bill no, reason..."></div>
 <div class="col-12"><button class="btn btn-gold">Save</button> <a href="index.php" class="btn btn-outline-secondary">Items</a></div></form></div></div></div>
<div class="col-lg-7"><div class="card"><div class="card-header fw-semibold">Current stock</div><div class="table-responsive"><table class="table table-sm mb-0"><tbody><?php foreach ($items as $i): $low = $i['current_stock'] <= $i['minimum_stock']; ?><tr class="<?= $low ? 'table-danger' : '' ?>"><td><?= e($i['item_name']) ?></td><td class="text-end"><?= e($i['current_stock'] + 0) ?> <?= e($i['unit']) ?></td><td class="text-end small text-muted">min <?= e($i['minimum_stock'] + 0) ?></td></tr><?php endforeach; ?></tbody></table></div></div></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
