<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('inventory');
$pageTitle = 'Stock Transactions';
$list = rows('SELECT s.*, i.item_name, i.unit, u.full_name AS who FROM stock_transactions s JOIN inventory_items i ON i.id=s.inventory_item_id LEFT JOIN users u ON u.id=s.created_by ORDER BY s.id DESC LIMIT 300');
include ROOT . '/includes/header.php';
?>
<div class="card"><div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Date</th><th>Item</th><th>Type</th><th class="text-end">Qty</th><th>Reference</th><th>By</th></tr></thead><tbody>
<?php foreach ($list as $s): ?><tr><td><?= e(dt($s['transaction_date'], 'd M, h:i A')) ?></td><td><?= e($s['item_name']) ?></td><td><?= badge(strtoupper($s['transaction_type']), ['in' => 'success', 'out' => 'danger', 'adjust' => 'warning'][$s['transaction_type']]) ?></td><td class="text-end"><?= e($s['quantity'] + 0) ?> <?= e($s['unit']) ?></td><td><?= e($s['reference']) ?></td><td><?= e($s['who']) ?></td></tr>
<?php endforeach; if (!$list) echo '<tr><td colspan="6" class="text-center text-muted py-4">No transactions.</td></tr>'; ?></tbody></table></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
