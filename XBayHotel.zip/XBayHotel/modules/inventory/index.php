<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = ['title' => 'Inventory Items', 'table' => 'inventory_items', 'perm' => 'inventory',
 'select' => 'SELECT i.*, c.category_name FROM inventory_items i LEFT JOIN inventory_categories c ON c.id=i.category_id ORDER BY i.item_name',
 'columns' => ['item_name' => 'Item', 'category_name' => 'Category', 'unit' => 'Unit', 'current_stock' => 'In stock', 'minimum_stock' => 'Minimum', 'purchase_price' => 'Cost'],
 'format' => ['purchase_price' => 'money'],
 'toolbar' => '<a class="btn btn-outline-dark" href="stock.php">Stock in / out</a><a class="btn btn-outline-dark" href="transactions.php">Transactions</a>',
 'fields' => [['name' => 'item_name', 'label' => 'Item name', 'required' => true], ['name' => 'category_id', 'label' => 'Category', 'type' => 'select', 'nullable' => true, 'sql' => 'SELECT id, category_name FROM inventory_categories ORDER BY category_name'],
  ['name' => 'unit', 'label' => 'Unit (pcs, kg, litre)', 'required' => true, 'default' => 'pcs'], ['name' => 'minimum_stock', 'label' => 'Minimum stock (low-stock alert)', 'type' => 'number', 'default' => 0],
  ['name' => 'purchase_price', 'label' => 'Purchase price per unit', 'type' => 'number', 'default' => 0], ['name' => 'current_stock', 'label' => 'Opening / current stock', 'type' => 'number', 'default' => 0, 'help' => 'Use "Stock in / out" for later changes so they are logged.']],
 'row_actions' => fn($r) => $r['current_stock'] <= $r['minimum_stock'] ? '<span class="badge text-bg-danger me-1">Low</span>' : ''];
require ROOT . '/includes/crud.php';
