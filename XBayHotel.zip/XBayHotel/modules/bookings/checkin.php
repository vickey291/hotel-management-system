<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('bookings');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('modules/bookings/');
$pdo = db(); $brid = (int)($_POST['booking_room_id'] ?? 0); $bid = 0;
try {
    $pdo->beginTransaction();
    $br = row('SELECT br.*, b.booking_status, b.booking_number FROM booking_rooms br JOIN bookings b ON b.id=br.booking_id WHERE br.id=? FOR UPDATE', [$brid]);
    if (!$br) throw new RuntimeException('Booking room not found.');
    $bid = (int)$br['booking_id'];
    if ($br['room_status'] !== 'reserved' || $br['booking_status'] !== 'confirmed') throw new RuntimeException('This room cannot be checked in (already checked-in or cancelled).');
    $room = row('SELECT * FROM rooms WHERE id=? FOR UPDATE', [$br['room_id']]);
    if ($room['maintenance_status'] !== 'active') throw new RuntimeException("Room {$room['room_number']} is under maintenance.");
    if ($room['cleaning_status'] !== 'clean') throw new RuntimeException("Room {$room['room_number']} is not marked clean yet. Update cleaning status first.");
    if (val("SELECT 1 FROM booking_rooms WHERE room_id=? AND room_status='checked_in' LIMIT 1", [$room['id']])) throw new RuntimeException("Room {$room['room_number']} still has a guest checked in.");
    if (val("SELECT 1 FROM monthly_tenants WHERE room_id=? AND tenant_status='active' LIMIT 1", [$room['id']])) throw new RuntimeException('Room has an active monthly tenant.');
    q("UPDATE booking_rooms SET room_status='checked_in' WHERE id=?", [$brid]);
    q('INSERT INTO checkin_checkout (booking_room_id, actual_checkin, checked_in_by, checkin_notes) VALUES (?,NOW(),?,?)', [$brid, user()['id'], trim($_POST['notes'] ?? '')]);
    q("UPDATE bookings SET booking_status='checked_in' WHERE id=?", [$bid]);
    q('INSERT INTO booking_status_history (booking_id, old_status, new_status, changed_by, remarks) VALUES (?,?,?,?,?)', [$bid, 'confirmed', 'checked_in', user()['id'], "Room {$room['room_number']} checked in"]);
    audit('checkin', 'bookings', $bid, "Room {$room['room_number']}");
    $pdo->commit();
    flash("Room {$room['room_number']} checked in.");
} catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); flash($ex->getMessage(), 'danger'); }
redirect('modules/bookings/details.php?id=' . $bid);
