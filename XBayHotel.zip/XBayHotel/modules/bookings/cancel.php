<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('bookings');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('modules/bookings/');
$bid = (int)($_POST['booking_id'] ?? 0);
try {
    $b = row('SELECT * FROM bookings WHERE id=?', [$bid]);
    if (!$b || $b['booking_status'] !== 'confirmed') throw new RuntimeException('Only confirmed (not yet checked-in) bookings can be cancelled.');
    q("UPDATE booking_rooms SET room_status='cancelled' WHERE booking_id=?", [$bid]);
    q("UPDATE bookings SET booking_status='cancelled' WHERE id=?", [$bid]);
    q('INSERT INTO booking_status_history (booking_id, old_status, new_status, changed_by, remarks) VALUES (?,?,?,?,?)', [$bid, 'confirmed', 'cancelled', user()['id'], trim($_POST['reason'] ?? '')]);
    rebuild_invoice($bid);
    audit('cancel', 'bookings', $bid, $b['booking_number']);
    flash('Booking cancelled. Rooms are free again.');
} catch (Throwable $ex) { flash($ex->getMessage(), 'danger'); }
redirect('modules/bookings/details.php?id=' . $bid);
