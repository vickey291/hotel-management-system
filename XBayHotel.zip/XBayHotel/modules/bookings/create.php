<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('bookings');
$pageTitle = 'New Room Booking';
$rooms = rows("SELECT r.*, t.type_name, t.booking_mode FROM rooms r JOIN room_types t ON t.id=r.room_type_id WHERE r.is_active=1 AND t.booking_mode <> 'monthly' ORDER BY r.room_number");
$guestsList = rows('SELECT id, full_name, guest_code, phone FROM guests ORDER BY id DESC LIMIT 500');
$ciTime = setting('checkin_time', '14:00'); $coTime = setting('checkout_time', '12:00');
$defIn = date('Y-m-d') . 'T' . $ciTime; $defOut = date('Y-m-d', strtotime('+1 day')) . 'T' . $coTime;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = db();
    try {
        $in = str_replace('T', ' ', $_POST['checkin']) . ':00'; $out = str_replace('T', ' ', $_POST['checkout']) . ':00';
        if (strtotime($out) <= strtotime($in)) throw new RuntimeException('Check-out must be after check-in.');
        $picked = array_map('intval', (array)($_POST['rooms'] ?? []));
        if (!$picked) throw new RuntimeException('Select at least one room.');
        $discount = max(0, (float)($_POST['discount'] ?? 0)); $advance = max(0, (float)($_POST['advance'] ?? 0));
        $pdo->beginTransaction();
        // 1) guest
        if (($_POST['guest_mode'] ?? 'new') === 'old') {
            $gid = (int)$_POST['guest_id']; if (!val('SELECT id FROM guests WHERE id=?', [$gid])) throw new RuntimeException('Select a guest.');
        } else {
            $name = trim($_POST['full_name'] ?? ''); if ($name === '') throw new RuntimeException('Guest name is required.');
            $cnic = trim($_POST['cnic'] ?? '');
            $gid = null;
            if ($cnic !== '') $gid = val('SELECT guest_id FROM guest_documents WHERE document_number=? LIMIT 1', [$cnic]);   // reuse guest with same CNIC
            if (!$gid) {
                q('INSERT INTO guests (guest_code, full_name, father_husband_name, phone, address, city) VALUES (?,?,?,?,?,?)', [guest_code(), $name, trim($_POST['father_husband_name'] ?? ''), trim($_POST['phone'] ?? ''), trim($_POST['address'] ?? ''), trim($_POST['city'] ?? '')]);
                $gid = (int)$pdo->lastInsertId();
                if ($cnic !== '') {
                    q('INSERT INTO guest_documents (guest_id, document_type, document_number, front_image, back_image) VALUES (?,?,?,?,?)', [$gid, 'CNIC', $cnic, upload_file('cnic_front', 'guest_documents', true, true), upload_file('cnic_back', 'guest_documents', true, true)]);
                }
            }
        }
        // 2) rooms: lock + overlap check (a room can never be double-booked)
        $total = 0; $lines = [];
        foreach ($picked as $rid) {
            $room = row('SELECT r.*, t.booking_mode FROM rooms r JOIN room_types t ON t.id=r.room_type_id WHERE r.id=? FOR UPDATE', [$rid]);
            if (!$room || !$room['is_active'] || $room['booking_mode'] === 'monthly') throw new RuntimeException('Invalid room selected.');
            if ($room['maintenance_status'] !== 'active') throw new RuntimeException("Room {$room['room_number']} is under maintenance.");
            $c = room_conflict($rid, $in, $out, true);
            if ($c) throw new RuntimeException("Room {$room['room_number']} is already booked ({$c['booking_number']}: " . dt($c['checkin_datetime'], 'd M h:i A') . ' to ' . dt($c['checkout_datetime'], 'd M h:i A') . '). Choose another room or different dates.');
            $rate = isset($_POST['rate'][$rid]) && $_POST['rate'][$rid] !== '' ? max(0, (float)$_POST['rate'][$rid]) : (float)$room['room_price'];
            $lines[] = [$rid, $rate]; $total += $rate * nights_between($in, $out);
        }
        if ($advance > max(0, $total - $discount) + 0.009) throw new RuntimeException('Advance cannot be more than the room total.');
        // 3) booking
        $bn = next_number('XB-', 'bookings');
        q('INSERT INTO bookings (booking_number, guest_id, booking_source, checkin_datetime, checkout_datetime, adults, children, total_nights, room_total, discount, grand_total, advance_amount, booking_status, special_notes, emergency_contact, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [$bn, $gid, $_POST['booking_source'] ?? 'walk_in', $in, $out, max(1, (int)$_POST['adults']), max(0, (int)$_POST['children']), nights_between($in, $out), $total, $discount, max(0, $total - $discount), $advance, 'confirmed', trim($_POST['notes'] ?? ''), trim($_POST['emergency_contact'] ?? ''), user()['id']]);
        $bid = (int)$pdo->lastInsertId();
        foreach ($lines as [$rid, $rate]) q("INSERT INTO booking_rooms (booking_id, room_id, room_rate, checkin_datetime, checkout_datetime, room_status) VALUES (?,?,?,?,?,'reserved')", [$bid, $rid, $rate, $in, $out]);
        q('INSERT INTO booking_occupants (booking_id, guest_id, is_primary_guest, relationship) VALUES (?,?,1,?)', [$bid, $gid, 'Self']);
        foreach ((array)($_POST['occ_name'] ?? []) as $i => $n) {
            $n = trim($n); if ($n === '') continue;
            q('INSERT INTO guests (guest_code, full_name, city) VALUES (?,?,?)', [guest_code(), $n, trim($_POST['city'] ?? '')]);
            q('INSERT INTO booking_occupants (booking_id, guest_id, is_primary_guest, relationship) VALUES (?,?,0,?)', [$bid, (int)$pdo->lastInsertId(), trim($_POST['occ_rel'][$i] ?? '')]);
        }
        q('INSERT INTO booking_status_history (booking_id, old_status, new_status, changed_by, remarks) VALUES (?,?,?,?,?)', [$bid, null, 'confirmed', user()['id'], 'Booking created']);
        $iid = rebuild_invoice($bid);
        if ($advance > 0) record_payment($iid, $advance, $_POST['payment_method'] ?? 'cash', null, 'Advance payment');
        audit('create', 'bookings', $bid, "Booking $bn");
        $pdo->commit();
        flash("Booking $bn confirmed.");
        redirect('modules/bookings/details.php?id=' . $bid);
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash($ex->getMessage(), 'danger');
        $defIn = $_POST['checkin'] ?? $defIn; $defOut = $_POST['checkout'] ?? $defOut;
    }
}
$preRoom = (int)($_GET['room_id'] ?? 0); $preGuest = (int)($_GET['guest_id'] ?? 0);
$pageScripts = ['assets/js/booking.js'];
include ROOT . '/includes/header.php';
?>
<form method="post" enctype="multipart/form-data" id="bookingForm"><?= csrf_field() ?>
<div class="row g-3">
<div class="col-lg-7">
 <div class="card mb-3"><div class="card-header fw-semibold">1. Guest information</div><div class="card-body">
  <div class="mb-3">
    <div class="form-check form-check-inline"><input class="form-check-input" type="radio" name="guest_mode" value="new" id="gmNew" <?= $preGuest ? '' : 'checked' ?>><label class="form-check-label" for="gmNew">New guest</label></div>
    <div class="form-check form-check-inline"><input class="form-check-input" type="radio" name="guest_mode" value="old" id="gmOld" <?= $preGuest ? 'checked' : '' ?>><label class="form-check-label" for="gmOld">Existing guest</label></div>
  </div>
  <div id="oldGuestBox"><select name="guest_id" class="form-select"><option value="">-- select guest --</option>
   <?php foreach ($guestsList as $g): ?><option value="<?= (int)$g['id'] ?>" <?= $preGuest == $g['id'] ? 'selected' : '' ?>><?= e($g['full_name'] . ' (' . $g['guest_code'] . ') ' . $g['phone']) ?></option><?php endforeach; ?></select></div>
  <div id="newGuestBox" class="row g-2">
    <div class="col-md-6"><label class="form-label">Full name *</label><input name="full_name" data-req class="form-control" value="<?= e($_POST['full_name'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">Father / Husband name</label><input name="father_husband_name" class="form-control" value="<?= e($_POST['father_husband_name'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">CNIC number</label><input name="cnic" class="form-control" placeholder="00000-0000000-0" pattern="[0-9]{5}-?[0-9]{7}-?[0-9]" value="<?= e($_POST['cnic'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">Mobile *</label><input name="phone" data-req class="form-control" type="tel" value="<?= e($_POST['phone'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">CNIC front image</label><input type="file" name="cnic_front" class="form-control" accept="image/*,application/pdf"></div>
    <div class="col-md-6"><label class="form-label">CNIC back image</label><input type="file" name="cnic_back" class="form-control" accept="image/*,application/pdf"></div>
    <div class="col-md-8"><label class="form-label">Address</label><input name="address" class="form-control" value="<?= e($_POST['address'] ?? '') ?>"></div>
    <div class="col-md-4"><label class="form-label">City</label><input name="city" class="form-control" value="<?= e($_POST['city'] ?? '') ?>"></div>
  </div>
  <div class="row g-2 mt-1"><div class="col-md-4"><label class="form-label">Adults</label><input type="number" name="adults" min="1" value="<?= e($_POST['adults'] ?? 1) ?>" class="form-control"></div>
   <div class="col-md-4"><label class="form-label">Children</label><input type="number" name="children" min="0" value="<?= e($_POST['children'] ?? 0) ?>" class="form-control"></div>
   <div class="col-md-4"><label class="form-label">Emergency contact</label><input name="emergency_contact" class="form-control" value="<?= e($_POST['emergency_contact'] ?? '') ?>"></div></div>
 </div></div>
 <div class="card"><div class="card-header fw-semibold d-flex justify-content-between">2. Family members / other occupants <button type="button" id="addOcc" class="btn btn-sm btn-outline-dark">+ Add</button></div><div class="card-body" id="occList"><div class="text-muted small">Optional. Names are linked to this booking.</div></div></div>
</div>
<div class="col-lg-5">
 <div class="card mb-3"><div class="card-header fw-semibold">3. Stay &amp; rooms</div><div class="card-body">
  <div class="row g-2 mb-3"><div class="col-6"><label class="form-label">Check-in</label><input type="datetime-local" name="checkin" class="form-control" value="<?= e($defIn) ?>" required></div>
   <div class="col-6"><label class="form-label">Check-out</label><input type="datetime-local" name="checkout" class="form-control" value="<?= e($defOut) ?>" required></div></div>
  <label class="form-label">Rooms (tick and adjust rate if needed)</label>
  <div style="max-height:260px;overflow:auto" class="border rounded p-2 mb-3">
  <?php foreach ($rooms as $r): [$k, $l, $c] = room_state($r); $dis = $r['maintenance_status'] !== 'active'; ?>
    <div class="room-pick d-flex align-items-center gap-2 mb-1">
      <input type="checkbox" class="form-check-input mt-0" name="rooms[]" value="<?= (int)$r['id'] ?>" id="rm<?= (int)$r['id'] ?>" <?= $dis ? 'disabled' : '' ?> <?= ($preRoom == $r['id'] || in_array($r['id'], (array)($_POST['rooms'] ?? []))) ? 'checked' : '' ?>>
      <label for="rm<?= (int)$r['id'] ?>" class="flex-grow-1 small"><b><?= e($r['room_number']) ?></b> <?= e($r['type_name']) ?> <span class="badge text-bg-<?= $c ?>"><?= e($l) ?></span></label>
      <input type="number" step="any" name="rate[<?= (int)$r['id'] ?>]" value="<?= e($r['room_price'] + 0) ?>" class="form-control form-control-sm" style="width:100px" disabled>
    </div>
  <?php endforeach; ?></div>
  <div class="row g-2"><div class="col-6"><label class="form-label">Discount</label><input type="number" step="any" min="0" name="discount" value="<?= e($_POST['discount'] ?? 0) ?>" class="form-control"></div>
   <div class="col-6"><label class="form-label">Advance payment</label><input type="number" step="any" min="0" name="advance" value="<?= e($_POST['advance'] ?? 0) ?>" class="form-control"></div>
   <div class="col-6"><label class="form-label">Payment method</label><select name="payment_method" class="form-select"><?php foreach (PAYMENT_METHODS as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
   <div class="col-6"><label class="form-label">Source</label><select name="booking_source" class="form-select"><?php foreach (BOOKING_SOURCES as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
   <div class="col-12"><label class="form-label">Notes</label><textarea name="notes" rows="2" class="form-control"><?= e($_POST['notes'] ?? '') ?></textarea></div></div>
 </div></div>
 <div class="card border-warning"><div class="card-body">
  <div class="d-flex justify-content-between"><span>Nights</span><b id="sumNights">1</b></div><div class="d-flex justify-content-between"><span>Rooms</span><b id="sumRooms">0</b></div>
  <div class="d-flex justify-content-between fs-5"><span>Room total</span><b id="sumTotal">0</b></div><div class="d-flex justify-content-between text-danger"><span>Remaining after advance</span><b id="sumRemain">0</b></div>
  <button class="btn btn-gold w-100 mt-3 py-2"><i class="bi bi-check2-circle me-1"></i>Confirm Booking</button></div></div>
</div></div></form>
<?php include ROOT . '/includes/footer.php'; ?>
