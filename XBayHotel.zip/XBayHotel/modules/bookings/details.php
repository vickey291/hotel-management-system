<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('bookings');
$id = (int)($_GET['id'] ?? 0);
$b = row('SELECT b.*, g.full_name, g.phone, g.father_husband_name, g.address, g.guest_code FROM bookings b JOIN guests g ON g.id=b.guest_id WHERE b.id=?', [$id]);
if (!$b) { flash('Booking not found.', 'danger'); redirect('modules/bookings/'); }
$pageTitle = 'Booking ' . $b['booking_number'];
$brs = rows('SELECT br.*, r.room_number, r.cleaning_status, t.type_name FROM booking_rooms br JOIN rooms r ON r.id=br.room_id JOIN room_types t ON t.id=r.room_type_id WHERE br.booking_id=?', [$id]);
$occ = rows('SELECT o.*, g.full_name FROM booking_occupants o JOIN guests g ON g.id=o.guest_id WHERE o.booking_id=?', [$id]);
$hist = rows('SELECT h.*, u.full_name AS who FROM booking_status_history h LEFT JOIN users u ON u.id=h.changed_by WHERE h.booking_id=? ORDER BY h.id DESC', [$id]);
$inv = row("SELECT * FROM invoices WHERE booking_id=? AND invoice_type IN ('room','checkout') LIMIT 1", [$id]);
$cnic = val('SELECT document_number FROM guest_documents WHERE guest_id=? ORDER BY id DESC LIMIT 1', [$b['guest_id']]);
include ROOT . '/includes/header.php';
$active = in_array($b['booking_status'], ['confirmed', 'checked_in']);
?>
<div class="d-flex flex-wrap gap-2 mb-3 align-items-center">
  <a href="index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
  <h4 class="mb-0"><?= e($b['booking_number']) ?></h4><?= badge(BOOKING_STATUSES[$b['booking_status']], status_class($b['booking_status'])) ?>
  <div class="ms-auto d-flex gap-2 flex-wrap">
    <a class="btn btn-sm btn-outline-dark" target="_blank" href="<?= e(url('print/booking_receipt.php?id=' . $id)) ?>"><i class="bi bi-printer me-1"></i>Booking receipt</a>
    <?php if ($active): ?><a class="btn btn-sm btn-outline-primary" href="edit.php?id=<?= $id ?>">Edit / extend</a>
    <a class="btn btn-sm btn-outline-dark" href="<?= e(url('modules/room_services/add_charge.php?booking_id=' . $id)) ?>">Add charge</a><?php endif; ?>
    <?php if ($b['booking_status'] === 'checked_in'): ?><a class="btn btn-sm btn-danger" href="<?= e(url('modules/billing/checkout.php?booking_id=' . $id)) ?>">Check-out</a><?php endif; ?>
  </div></div>
<div class="row g-3">
<div class="col-lg-6"><div class="card h-100"><div class="card-header fw-semibold">Guest</div><div class="card-body"><dl class="row small mb-0">
  <dt class="col-4">Name</dt><dd class="col-8"><a href="<?= e(url('modules/guests/details.php?id=' . $b['guest_id'])) ?>"><?= e($b['full_name']) ?></a> (<?= e($b['guest_code']) ?>)</dd>
  <dt class="col-4">Father/Husband</dt><dd class="col-8"><?= e($b['father_husband_name']) ?></dd><dt class="col-4">CNIC</dt><dd class="col-8"><?= e($cnic ?: '-') ?></dd>
  <dt class="col-4">Phone</dt><dd class="col-8"><?= e($b['phone']) ?></dd><dt class="col-4">Emergency</dt><dd class="col-8"><?= e($b['emergency_contact']) ?></dd>
  <dt class="col-4">Members</dt><dd class="col-8"><?= (int)$b['adults'] ?> adults, <?= (int)$b['children'] ?> children</dd>
  <dt class="col-4">Source</dt><dd class="col-8"><?= e(BOOKING_SOURCES[$b['booking_source']] ?? $b['booking_source']) ?></dd>
  <dt class="col-4">Notes</dt><dd class="col-8"><?= e($b['special_notes']) ?></dd></dl>
  <?php if (count($occ) > 1): ?><hr><div class="small fw-semibold">Family members</div><ul class="small mb-0"><?php foreach ($occ as $o): if ($o['is_primary_guest']) continue; ?><li><?= e($o['full_name']) ?> <span class="text-muted">(<?= e($o['relationship']) ?>)</span></li><?php endforeach; ?></ul><?php endif; ?>
</div></div></div>
<div class="col-lg-6"><div class="card h-100"><div class="card-header fw-semibold">Stay &amp; payment</div><div class="card-body"><dl class="row small mb-2">
  <dt class="col-5">Check-in</dt><dd class="col-7"><?= e(dt($b['checkin_datetime'])) ?></dd><dt class="col-5">Check-out</dt><dd class="col-7"><?= e(dt($b['checkout_datetime'])) ?></dd>
  <dt class="col-5">Nights</dt><dd class="col-7"><?= (int)$b['total_nights'] ?></dd></dl>
  <div class="d-flex justify-content-between"><span>Total bill</span><b><?= money($inv['grand_total'] ?? $b['grand_total']) ?></b></div>
  <div class="d-flex justify-content-between text-success"><span>Paid</span><b><?= money($inv['paid_amount'] ?? 0) ?></b></div>
  <div class="d-flex justify-content-between text-danger"><span>Remaining</span><b><?= money($inv['remaining_amount'] ?? 0) ?></b></div>
  <?php if ($inv): ?><a class="btn btn-sm btn-gold mt-3" href="<?= e(url('modules/billing/details.php?id=' . $inv['id'])) ?>">Open bill / receive payment</a><?php endif; ?></div></div></div>
<div class="col-12"><div class="card"><div class="card-header fw-semibold">Rooms</div><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Room</th><th>Type</th><th>Rate/night</th><th>Status</th><th class="text-end">Action</th></tr></thead><tbody>
<?php foreach ($brs as $r): ?><tr><td><b><?= e($r['room_number']) ?></b></td><td><?= e($r['type_name']) ?></td><td><?= money($r['room_rate']) ?></td><td><?= badge(ucfirst(str_replace('_', ' ', $r['room_status'])), status_class($r['room_status'] === 'reserved' ? 'confirmed' : $r['room_status'])) ?></td>
 <td class="text-end"><?php if ($r['room_status'] === 'reserved' && $b['booking_status'] === 'confirmed'): ?>
  <form method="post" action="checkin.php" class="d-inline"><?= csrf_field() ?><input type="hidden" name="booking_room_id" value="<?= (int)$r['id'] ?>"><button class="btn btn-sm btn-success"><i class="bi bi-box-arrow-in-right me-1"></i>Check-in</button></form><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<?php if ($b['booking_status'] === 'confirmed'): ?><div class="col-12"><form method="post" action="cancel.php" onsubmit="return confirm('Cancel this booking?')" class="d-flex gap-2"><?= csrf_field() ?><input type="hidden" name="booking_id" value="<?= $id ?>"><input name="reason" class="form-control form-control-sm" style="max-width:320px" placeholder="Reason (optional)"><button class="btn btn-sm btn-outline-danger">Cancel booking</button></form><div class="small text-muted mt-1">Any advance paid stays recorded on the invoice; refund is handled manually.</div></div><?php endif; ?>
<div class="col-12"><div class="card"><div class="card-header fw-semibold">Status history</div><ul class="list-group list-group-flush small"><?php foreach ($hist as $h): ?><li class="list-group-item"><?= e(dt($h['change_date'])) ?> &middot; <b><?= e($h['old_status'] ?: 'new') ?> &rarr; <?= e($h['new_status']) ?></b> &middot; <?= e($h['who']) ?> <span class="text-muted"><?= e($h['remarks']) ?></span></li><?php endforeach; ?></ul></div></div>
</div>
<?php include ROOT . '/includes/footer.php'; ?>
