<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('bookings');
$pageTitle = 'Bookings';
$st = $_GET['status'] ?? ''; $s = trim($_GET['q'] ?? '');
$sql = "SELECT b.*, g.full_name, g.phone, (SELECT GROUP_CONCAT(r.room_number ORDER BY r.room_number) FROM booking_rooms br JOIN rooms r ON r.id=br.room_id WHERE br.booking_id=b.id) AS rooms,
        (SELECT invoice_status FROM invoices i WHERE i.booking_id=b.id ORDER BY i.id LIMIT 1) AS pay_status
        FROM bookings b JOIN guests g ON g.id=b.guest_id WHERE 1=1";
$p = [];
if ($st && isset(BOOKING_STATUSES[$st])) { $sql .= ' AND b.booking_status=?'; $p[] = $st; }
if ($s !== '') { $sql .= ' AND (b.booking_number LIKE ? OR g.full_name LIKE ? OR g.phone LIKE ?)'; $p = array_merge($p, ["%$s%", "%$s%", "%$s%"]); }
$list = rows($sql . ' ORDER BY b.id DESC LIMIT 300', $p);
include ROOT . '/includes/header.php';
?>
<form class="d-flex flex-wrap gap-2 mb-3"><input name="q" value="<?= e($s) ?>" class="form-control" style="max-width:260px" placeholder="Booking no, guest, phone">
 <select name="status" class="form-select w-auto" onchange="this.form.submit()"><option value="">All statuses</option><?php foreach (BOOKING_STATUSES as $k => $l): ?><option value="<?= $k ?>" <?= $st === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select>
 <button class="btn btn-outline-dark">Search</button><a class="btn btn-gold ms-auto" href="create.php"><i class="bi bi-plus-lg me-1"></i>New Booking</a></form>
<div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Booking</th><th>Guest</th><th>Rooms</th><th>Check-in</th><th>Check-out</th><th>Status</th><th>Payment</th><th class="text-end">Total</th><th></th></tr></thead><tbody>
<?php foreach ($list as $b): ?><tr><td><a href="details.php?id=<?= (int)$b['id'] ?>" class="fw-semibold"><?= e($b['booking_number']) ?></a></td><td><?= e($b['full_name']) ?><div class="small text-muted"><?= e($b['phone']) ?></div></td><td><?= e($b['rooms']) ?></td>
 <td><?= e(dt($b['checkin_datetime'], 'd M, h:i A')) ?></td><td><?= e(dt($b['checkout_datetime'], 'd M, h:i A')) ?></td><td><?= badge(BOOKING_STATUSES[$b['booking_status']], status_class($b['booking_status'])) ?></td>
 <td><?= $b['pay_status'] ? badge(ucfirst($b['pay_status']), status_class($b['pay_status'])) : '-' ?></td><td class="text-end"><?= money($b['grand_total']) ?></td><td class="text-end"><a class="btn btn-sm btn-outline-dark" href="details.php?id=<?= (int)$b['id'] ?>"><i class="bi bi-eye"></i></a></td></tr>
<?php endforeach; if (!$list) echo '<tr><td colspan="9" class="text-center text-muted py-4">No bookings found.</td></tr>'; ?></tbody></table></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
