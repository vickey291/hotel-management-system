<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('bookings');
$id = (int)($_GET['id'] ?? 0);
$b = row('SELECT b.*, g.full_name FROM bookings b JOIN guests g ON g.id=b.guest_id WHERE b.id=?', [$id]);
if (!$b || !in_array($b['booking_status'], ['confirmed', 'checked_in'])) { flash('This booking cannot be edited.', 'danger'); redirect('modules/bookings/'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = db();
    try {
        $pdo->beginTransaction();
        $in = $b['booking_status'] === 'confirmed' ? str_replace('T', ' ', $_POST['checkin']) . ':00' : $b['checkin_datetime'];
        $out = str_replace('T', ' ', $_POST['checkout']) . ':00';
        if (strtotime($out) <= strtotime($in)) throw new RuntimeException('Check-out must be after check-in.');
        foreach (rows("SELECT br.*, r.room_number FROM booking_rooms br JOIN rooms r ON r.id=br.room_id WHERE br.booking_id=? AND br.room_status IN ('reserved','checked_in')", [$id]) as $br) {
            $c = room_conflict((int)$br['room_id'], $in, $out, true, $id);
            if ($c) throw new RuntimeException("Room {$br['room_number']} is already booked by {$c['booking_number']} in that period.");
        }
        q('UPDATE bookings SET checkin_datetime=?, checkout_datetime=?, total_nights=?, adults=?, children=?, discount=?, special_notes=?, emergency_contact=? WHERE id=?',
            [$in, $out, nights_between($in, $out), max(1, (int)$_POST['adults']), max(0, (int)$_POST['children']), max(0, (float)$_POST['discount']), trim($_POST['notes']), trim($_POST['emergency_contact']), $id]);
        q("UPDATE booking_rooms SET checkin_datetime=?, checkout_datetime=? WHERE booking_id=? AND room_status IN ('reserved','checked_in')", [$in, $out, $id]);
        q('INSERT INTO booking_status_history (booking_id, old_status, new_status, changed_by, remarks) VALUES (?,?,?,?,?)', [$id, $b['booking_status'], $b['booking_status'], user()['id'], 'Booking edited / stay changed']);
        rebuild_invoice($id); audit('update', 'bookings', $id, 'Edited');
        $pdo->commit(); flash('Booking updated.'); redirect('modules/bookings/details.php?id=' . $id);
    } catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); flash($ex->getMessage(), 'danger'); }
}
$pageTitle = 'Edit ' . $b['booking_number'];
include ROOT . '/includes/header.php';
?>
<div class="card" style="max-width:720px"><div class="card-header fw-semibold">Edit / extend stay &mdash; <?= e($b['full_name']) ?></div><div class="card-body">
<form method="post" class="row g-3"><?= csrf_field() ?>
 <div class="col-md-6"><label class="form-label">Check-in</label><input type="datetime-local" name="checkin" class="form-control" value="<?= e(date('Y-m-d\TH:i', strtotime($b['checkin_datetime']))) ?>" <?= $b['booking_status'] === 'checked_in' ? 'readonly' : '' ?>></div>
 <div class="col-md-6"><label class="form-label">Check-out</label><input type="datetime-local" name="checkout" class="form-control" value="<?= e(date('Y-m-d\TH:i', strtotime($b['checkout_datetime']))) ?>"></div>
 <div class="col-md-4"><label class="form-label">Adults</label><input type="number" min="1" name="adults" class="form-control" value="<?= (int)$b['adults'] ?>"></div>
 <div class="col-md-4"><label class="form-label">Children</label><input type="number" min="0" name="children" class="form-control" value="<?= (int)$b['children'] ?>"></div>
 <div class="col-md-4"><label class="form-label">Discount</label><input type="number" step="any" min="0" name="discount" class="form-control" value="<?= e($b['discount'] + 0) ?>"></div>
 <div class="col-12"><label class="form-label">Emergency contact</label><input name="emergency_contact" class="form-control" value="<?= e($b['emergency_contact']) ?>"></div>
 <div class="col-12"><label class="form-label">Notes</label><textarea name="notes" class="form-control" rows="2"><?= e($b['special_notes']) ?></textarea></div>
 <div class="col-12 d-flex gap-2"><button class="btn btn-gold">Save changes</button><a class="btn btn-outline-secondary" href="details.php?id=<?= $id ?>">Cancel</a></div>
</form></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
