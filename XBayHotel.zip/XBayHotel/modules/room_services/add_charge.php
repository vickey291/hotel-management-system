<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('bookings');
$pageTitle = 'Add Room Charge';
$bid = (int)($_GET['booking_id'] ?? $_POST['booking_id'] ?? 0);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $b = row("SELECT * FROM bookings WHERE id=? AND booking_status IN ('confirmed','checked_in')", [$bid]);
        if (!$b) throw new RuntimeException('Select an active booking.');
        $qty = (float)$_POST['quantity']; $price = (float)$_POST['unit_price'];
        if ($qty <= 0 || $price < 0) throw new RuntimeException('Enter a valid quantity and price.');
        q('INSERT INTO room_charges (booking_id, room_id, charge_type, description, quantity, unit_price, total_amount, created_by) VALUES (?,?,?,?,?,?,?,?)',
            [$bid, (int)$_POST['room_id'] ?: null, array_key_exists($_POST['charge_type'], CHARGE_TYPES) ? $_POST['charge_type'] : 'other', trim($_POST['description']), $qty, $price, round($qty * $price, 2), user()['id']]);
        rebuild_invoice($bid); audit('create', 'room_charges', (int)db()->lastInsertId(), "Charge on {$b['booking_number']}");
        flash('Charge added to the guest bill.'); redirect('modules/room_services/service_history.php?booking_id=' . $bid);
    } catch (Throwable $ex) { flash($ex->getMessage(), 'danger'); }
}
$active = rows("SELECT b.id, b.booking_number, g.full_name, (SELECT GROUP_CONCAT(r.room_number) FROM booking_rooms br JOIN rooms r ON r.id=br.room_id WHERE br.booking_id=b.id) AS rooms FROM bookings b JOIN guests g ON g.id=b.guest_id WHERE b.booking_status IN ('confirmed','checked_in') ORDER BY b.id DESC");
$roomsOfB = $bid ? rows('SELECT r.id, r.room_number FROM booking_rooms br JOIN rooms r ON r.id=br.room_id WHERE br.booking_id=?', [$bid]) : [];
include ROOT . '/includes/header.php';
?>
<div class="card" style="max-width:680px"><div class="card-header fw-semibold">Add charge to a guest's bill</div><div class="card-body">
<form method="post" class="row g-3"><?= csrf_field() ?>
 <div class="col-12"><label class="form-label">Booking</label><select name="booking_id" class="form-select" required onchange="if(this.value)location='?booking_id='+this.value"><option value="">-- select --</option>
  <?php foreach ($active as $a): ?><option value="<?= (int)$a['id'] ?>" <?= $bid == $a['id'] ? 'selected' : '' ?>><?= e($a['booking_number'] . ' - ' . $a['full_name'] . ' (Room ' . $a['rooms'] . ')') ?></option><?php endforeach; ?></select></div>
 <div class="col-md-6"><label class="form-label">Room</label><select name="room_id" class="form-select"><option value="">-</option><?php foreach ($roomsOfB as $r): ?><option value="<?= (int)$r['id'] ?>" <?= ($_GET['room_id'] ?? 0) == $r['id'] ? 'selected' : '' ?>><?= e($r['room_number']) ?></option><?php endforeach; ?></select></div>
 <div class="col-md-6"><label class="form-label">Charge type</label><select name="charge_type" class="form-select"><?php foreach (CHARGE_TYPES as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
 <div class="col-12"><label class="form-label">Description</label><input name="description" class="form-control" placeholder="e.g. 5 clothes laundry"></div>
 <div class="col-md-6"><label class="form-label">Quantity</label><input type="number" step="any" min="0.01" name="quantity" value="1" class="form-control" required></div>
 <div class="col-md-6"><label class="form-label">Unit price</label><input type="number" step="any" min="0" name="unit_price" class="form-control" required></div>
 <div class="col-12"><button class="btn btn-gold">Add charge</button></div>
</form></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
