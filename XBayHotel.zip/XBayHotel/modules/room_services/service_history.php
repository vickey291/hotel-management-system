<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('bookings');
$pageTitle = 'Room Service Charges';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['_action'] ?? '') === 'delete') {
    $c = row('SELECT * FROM room_charges WHERE id=?', [(int)$_POST['id']]);
    if ($c) { q('DELETE FROM room_charges WHERE id=?', [$c['id']]); rebuild_invoice((int)$c['booking_id']); audit('delete', 'room_charges', (int)$c['id']); flash('Charge removed.'); }
    redirect($_SERVER['REQUEST_URI']);
}
$bid = (int)($_GET['booking_id'] ?? 0);
$list = rows('SELECT c.*, b.booking_number, g.full_name, r.room_number FROM room_charges c JOIN bookings b ON b.id=c.booking_id JOIN guests g ON g.id=b.guest_id LEFT JOIN rooms r ON r.id=c.room_id' . ($bid ? ' WHERE c.booking_id=?' : '') . ' ORDER BY c.id DESC LIMIT 300', $bid ? [$bid] : []);
include ROOT . '/includes/header.php';
?>
<div class="d-flex mb-3"><a class="btn btn-gold ms-auto" href="add_charge.php<?= $bid ? '?booking_id=' . $bid : '' ?>"><i class="bi bi-plus-lg me-1"></i>Add charge</a></div>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Date</th><th>Booking</th><th>Guest</th><th>Room</th><th>Type</th><th>Description</th><th class="text-end">Total</th><th></th></tr></thead><tbody>
<?php foreach ($list as $c): ?><tr><td><?= e(dt($c['charge_date'], 'd M, h:i A')) ?></td><td><a href="<?= e(url('modules/bookings/details.php?id=' . $c['booking_id'])) ?>"><?= e($c['booking_number']) ?></a></td><td><?= e($c['full_name']) ?></td><td><?= e($c['room_number']) ?></td><td><?= e(CHARGE_TYPES[$c['charge_type']] ?? $c['charge_type']) ?></td><td><?= e($c['description']) ?></td><td class="text-end"><?= money($c['total_amount']) ?></td>
 <td><form method="post" onsubmit="return confirm('Remove this charge?')"><?= csrf_field() ?><input type="hidden" name="_action" value="delete"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>"><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button></form></td></tr>
<?php endforeach; if (!$list) echo '<tr><td colspan="8" class="text-center text-muted py-4">No charges yet.</td></tr>'; ?></tbody></table></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
