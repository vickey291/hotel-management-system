<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = ['title' => 'Menu Items', 'table' => 'menu_items', 'perm' => 'menu',
 'select' => 'SELECT m.*, c.category_name FROM menu_items m JOIN menu_categories c ON c.id=m.category_id ORDER BY c.sort_order, m.item_name',
 'columns' => ['item_image' => 'Image', 'item_code' => 'Code', 'item_name' => 'Item', 'category_name' => 'Category', 'purchase_price' => 'Cost', 'sale_price' => 'Price', 'stock_quantity' => 'Stock', 'is_available' => 'Available'],
 'format' => ['item_image' => 'img', 'purchase_price' => 'money', 'sale_price' => 'money', 'is_available' => 'bool'],
 'toolbar' => '<a class="btn btn-outline-dark" href="categories.php">Categories</a><a class="btn btn-outline-dark" href="variants.php">Variants</a><a class="btn btn-outline-dark" href="addons.php">Add-ons</a>',
 'fields' => [
  ['name' => 'item_name', 'label' => 'Item name', 'required' => true], ['name' => 'item_code', 'label' => 'Item code', 'nullable' => true],
  ['name' => 'category_id', 'label' => 'Category', 'type' => 'select', 'required' => true, 'sql' => 'SELECT id, category_name FROM menu_categories WHERE is_active=1 ORDER BY sort_order'],
  ['name' => 'item_image', 'label' => 'Image', 'type' => 'file', 'dir' => 'menu_images'],
  ['name' => 'purchase_price', 'label' => 'Purchase price', 'type' => 'number', 'default' => 0], ['name' => 'sale_price', 'label' => 'Sale price', 'type' => 'number', 'required' => true],
  ['name' => 'stock_quantity', 'label' => 'Stock quantity', 'type' => 'number', 'step' => '1', 'default' => 0],
  ['name' => 'is_stock_managed', 'label' => 'Track stock (reduce on every order)', 'type' => 'checkbox', 'default' => 0],
  ['name' => 'description', 'label' => 'Description', 'col' => 12], ['name' => 'is_available', 'label' => 'Available for sale', 'type' => 'checkbox']]];
require ROOT . '/includes/crud.php';
