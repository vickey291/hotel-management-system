<?php
require_once __DIR__ . '/../../includes/functions.php';
// Assign an add-on to menu items: ?assign=<addon id>
if (isset($_GET['assign'])) {
    require_perm('menu');
    $aid = (int)$_GET['assign']; $a = row('SELECT * FROM menu_addons WHERE id=?', [$aid]);
    if (!$a) redirect('modules/menu/addons.php');
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        q('DELETE FROM menu_item_addons WHERE addon_id=?', [$aid]);
        foreach ((array)($_POST['items'] ?? []) as $mid) q('INSERT IGNORE INTO menu_item_addons (menu_item_id, addon_id) VALUES (?,?)', [(int)$mid, $aid]);
        flash('Add-on assignment saved.'); redirect('modules/menu/addons.php');
    }
    $items = rows('SELECT m.id, m.item_name, c.category_name FROM menu_items m JOIN menu_categories c ON c.id=m.category_id ORDER BY c.sort_order, m.item_name');
    $mine = array_column(rows('SELECT menu_item_id FROM menu_item_addons WHERE addon_id=?', [$aid]), 'menu_item_id');
    $pageTitle = 'Assign add-on'; include ROOT . '/includes/header.php'; ?>
    <div class="card" style="max-width:700px"><div class="card-header fw-semibold">Where is "<?= e($a['addon_name']) ?>" (<?= money($a['addon_price']) ?>) offered?</div><div class="card-body"><form method="post"><?= csrf_field() ?>
    <div class="row"><?php foreach ($items as $m): ?><div class="col-md-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="items[]" value="<?= (int)$m['id'] ?>" id="i<?= (int)$m['id'] ?>" <?= in_array($m['id'], $mine) ? 'checked' : '' ?>><label class="form-check-label" for="i<?= (int)$m['id'] ?>"><?= e($m['item_name']) ?> <small class="text-muted"><?= e($m['category_name']) ?></small></label></div></div><?php endforeach; ?></div>
    <button class="btn btn-gold mt-3">Save</button> <a href="addons.php" class="btn btn-outline-secondary mt-3">Back</a></form></div></div>
    <?php include ROOT . '/includes/footer.php'; exit;
}
$crud = ['title' => 'Add-ons (Extra Cheese, Extra Sauce...)', 'table' => 'menu_addons', 'perm' => 'menu',
 'select' => 'SELECT a.*, (SELECT COUNT(*) FROM menu_item_addons x WHERE x.addon_id=a.id) AS items FROM menu_addons a ORDER BY addon_name',
 'columns' => ['addon_name' => 'Add-on', 'addon_price' => 'Price', 'items' => 'Offered on items', 'is_active' => 'Status'], 'format' => ['addon_price' => 'money', 'is_active' => 'bool'],
 'row_actions' => fn($r) => '<a class="btn btn-sm btn-outline-dark" href="?assign=' . (int)$r['id'] . '">Assign to items</a> ',
 'toolbar' => '<a class="btn btn-outline-dark" href="index.php">Menu items</a>',
 'fields' => [['name' => 'addon_name', 'label' => 'Add-on name', 'required' => true], ['name' => 'addon_price', 'label' => 'Price', 'type' => 'number', 'required' => true], ['name' => 'is_active', 'label' => 'Active', 'type' => 'checkbox']]];
require ROOT . '/includes/crud.php';
