<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = ['title' => 'Item Variants (Small / Medium / Large)', 'table' => 'menu_item_variants', 'perm' => 'menu',
 'select' => 'SELECT v.*, m.item_name FROM menu_item_variants v JOIN menu_items m ON m.id=v.menu_item_id ORDER BY m.item_name, v.price',
 'columns' => ['item_name' => 'Item', 'variant_name' => 'Variant', 'price' => 'Price', 'is_active' => 'Status'], 'format' => ['price' => 'money', 'is_active' => 'bool'],
 'toolbar' => '<a class="btn btn-outline-dark" href="index.php">Menu items</a>',
 'fields' => [['name' => 'menu_item_id', 'label' => 'Menu item', 'type' => 'select', 'required' => true, 'sql' => 'SELECT id, item_name FROM menu_items ORDER BY item_name'],
  ['name' => 'variant_name', 'label' => 'Variant name', 'required' => true], ['name' => 'price', 'label' => 'Price (replaces item price)', 'type' => 'number', 'required' => true], ['name' => 'is_active', 'label' => 'Active', 'type' => 'checkbox']]];
require ROOT . '/includes/crud.php';
