<?php
require_once __DIR__ . '/../../includes/functions.php';
$crud = ['title' => 'Menu Categories', 'table' => 'menu_categories', 'perm' => 'menu',
 'select' => 'SELECT * FROM menu_categories ORDER BY sort_order, category_name',
 'columns' => ['category_image' => 'Image', 'category_name' => 'Category', 'sort_order' => 'Order', 'is_active' => 'Status'],
 'format' => ['category_image' => 'img', 'is_active' => 'bool'],
 'toolbar' => '<a class="btn btn-outline-dark" href="index.php">Menu items</a>',
 'fields' => [['name' => 'category_name', 'label' => 'Category name', 'required' => true], ['name' => 'sort_order', 'label' => 'Sort order', 'type' => 'number', 'step' => '1', 'default' => 0],
  ['name' => 'description', 'label' => 'Description', 'col' => 12], ['name' => 'category_image', 'label' => 'Image', 'type' => 'file', 'dir' => 'menu_images'], ['name' => 'is_active', 'label' => 'Active', 'type' => 'checkbox']]];
require ROOT . '/includes/crud.php';
