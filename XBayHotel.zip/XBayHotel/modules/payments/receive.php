<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('payments');
$pageTitle = 'Receive Payment';
$iid = (int)($_GET['invoice_id'] ?? $_POST['invoice_id'] ?? 0);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $m = array_key_exists($_POST['payment_method'], PAYMENT_METHODS) ? $_POST['payment_method'] : 'cash';
        $pid = record_payment($iid, round((float)$_POST['amount'], 2), $m, trim($_POST['reference'] ?? ''), trim($_POST['notes'] ?? ''));
        flash('Payment received.');
        redirect(!empty($_POST['back']) && (str_starts_with($_POST['back'], BASE_URL) && !str_starts_with($_POST['back'], '//')) ? $_POST['back'] : 'modules/billing/details.php?id=' . $iid);
    } catch (Throwable $ex) { flash($ex->getMessage(), 'danger'); redirect(!empty($_POST['back']) && (str_starts_with($_POST['back'], BASE_URL) && !str_starts_with($_POST['back'], '//')) ? $_POST['back'] : 'modules/payments/receive.php?invoice_id=' . $iid); }
}
$open = rows("SELECT i.*, g.full_name FROM invoices i LEFT JOIN guests g ON g.id=i.guest_id WHERE i.invoice_status IN ('pending','unpaid','partial') AND i.remaining_amount > 0 ORDER BY i.id DESC");
$cur = $iid ? row('SELECT * FROM invoices WHERE id=?', [$iid]) : null;
include ROOT . '/includes/header.php';
?>
<div class="card" style="max-width:640px"><div class="card-header fw-semibold">Receive payment</div><div class="card-body">
<form method="post" class="row g-3"><?= csrf_field() ?>
 <div class="col-12"><label class="form-label">Invoice</label><select name="invoice_id" class="form-select" required onchange="location='?invoice_id='+this.value"><option value="">-- select open invoice --</option>
  <?php foreach ($open as $i): ?><option value="<?= (int)$i['id'] ?>" <?= $iid == $i['id'] ? 'selected' : '' ?>><?= e($i['invoice_number'] . ' | ' . ($i['full_name'] ?: 'Walk-in') . ' | due ' . number_format($i['remaining_amount'])) ?></option><?php endforeach; ?></select></div>
 <?php if ($cur): ?><div class="col-12"><div class="alert alert-light border mb-0">Total <b><?= money($cur['grand_total']) ?></b> &middot; Paid <b><?= money($cur['paid_amount']) ?></b> &middot; <span class="text-danger">Remaining <b><?= money($cur['remaining_amount']) ?></b></span></div></div><?php endif; ?>
 <div class="col-md-6"><label class="form-label">Amount</label><input type="number" step="any" min="1" name="amount" value="<?= e($cur ? $cur['remaining_amount'] + 0 : '') ?>" class="form-control" required></div>
 <div class="col-md-6"><label class="form-label">Method</label><select name="payment_method" class="form-select"><?php foreach (PAYMENT_METHODS as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
 <div class="col-md-6"><label class="form-label">Transaction reference</label><input name="reference" class="form-control" placeholder="Bank / card ref (optional)"></div>
 <div class="col-md-6"><label class="form-label">Notes</label><input name="notes" class="form-control"></div>
 <div class="col-12"><button class="btn btn-gold">Save payment</button></div>
</form></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
