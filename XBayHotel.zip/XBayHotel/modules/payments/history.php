<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('payments');
$pageTitle = 'Payments';
$from = $_GET['from'] ?? date('Y-m-01'); $to = $_GET['to'] ?? date('Y-m-d'); $m = $_GET['method'] ?? '';
$sql = "SELECT p.*, i.invoice_number, i.invoice_type, g.full_name, u.full_name AS who FROM payments p JOIN invoices i ON i.id=p.invoice_id LEFT JOIN guests g ON g.id=i.guest_id LEFT JOIN users u ON u.id=p.received_by WHERE DATE(p.payment_date) BETWEEN ? AND ?";
$par = [$from, $to]; if ($m && isset(PAYMENT_METHODS[$m])) { $sql .= ' AND p.payment_method=?'; $par[] = $m; }
$list = rows($sql . ' ORDER BY p.id DESC', $par);
$sum = array_sum(array_column($list, 'amount'));
include ROOT . '/includes/header.php';
?>
<form class="row g-2 mb-3 align-items-end"><div class="col-auto"><label class="small">From</label><input type="date" name="from" value="<?= e($from) ?>" class="form-control"></div><div class="col-auto"><label class="small">To</label><input type="date" name="to" value="<?= e($to) ?>" class="form-control"></div>
 <div class="col-auto"><label class="small">Method</label><select name="method" class="form-select"><option value="">All</option><?php foreach (PAYMENT_METHODS as $k => $l): ?><option value="<?= $k ?>" <?= $m === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
 <div class="col-auto"><button class="btn btn-outline-dark">Filter</button></div><div class="col-auto ms-auto"><a href="receive.php" class="btn btn-gold"><i class="bi bi-plus-lg me-1"></i>Receive payment</a></div></form>
<div class="card"><div class="card-header d-flex justify-content-between"><span class="fw-semibold">Payments received</span><b><?= money($sum) ?></b></div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>No.</th><th>Date</th><th>Invoice</th><th>Guest</th><th>Method</th><th>Received by</th><th class="text-end">Amount</th><th></th></tr></thead><tbody>
<?php foreach ($list as $p): ?><tr><td><?= e($p['payment_number']) ?></td><td><?= e(dt($p['payment_date'], 'd M, h:i A')) ?></td><td><a href="<?= e(url('modules/billing/details.php?id=' . $p['invoice_id'])) ?>"><?= e($p['invoice_number']) ?></a></td><td><?= e($p['full_name'] ?: 'Walk-in') ?></td><td><?= e(PAYMENT_METHODS[$p['payment_method']] ?? $p['payment_method']) ?></td><td><?= e($p['who']) ?></td><td class="text-end"><?= money($p['amount']) ?></td>
 <td><a target="_blank" class="btn btn-sm btn-outline-dark" href="<?= e(url('print/payment_receipt.php?id=' . $p['id'])) ?>"><i class="bi bi-printer"></i></a></td></tr>
<?php endforeach; if (!$list) echo '<tr><td colspan="8" class="text-center text-muted py-4">No payments in this period.</td></tr>'; ?></tbody></table></div></div>
<?php include ROOT . '/includes/footer.php'; ?>
