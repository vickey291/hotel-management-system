<?php
require_once __DIR__ . '/../../includes/functions.php';
require_perm('dashboard');
$pageTitle = 'Dashboard';
$rooms = rows("SELECT r.* FROM rooms r WHERE r.is_active=1");
$cnt = ['available' => 0, 'occupied' => 0, 'reserved' => 0, 'cleaning' => 0, 'monthly' => 0, 'maintenance' => 0];
foreach ($rooms as $r) $cnt[room_state($r)[0]]++;
$todayPay = (float)val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE DATE(payment_date)=CURDATE()");
$todayRent = (float)val("SELECT COALESCE(SUM(amount),0) FROM tenant_payments WHERE DATE(payment_date)=CURDATE()");
$todayExp = (float)val("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE expense_date=CURDATE()");
$restSales = (float)val("SELECT COALESCE(SUM(grand_total),0) FROM orders WHERE DATE(order_date)=CURDATE() AND order_status<>'cancelled'");
$pending = (float)val("SELECT COALESCE(SUM(remaining_amount),0) FROM invoices WHERE invoice_status IN ('unpaid','partial')") + (float)val("SELECT COALESCE(SUM(total_amount-paid_amount),0) FROM monthly_rent_invoices WHERE invoice_status<>'paid'");
$arrivals = rows("SELECT b.id,b.booking_number,b.checkin_datetime,g.full_name FROM bookings b JOIN guests g ON g.id=b.guest_id WHERE b.booking_status='confirmed' AND DATE(b.checkin_datetime)=CURDATE() ORDER BY b.checkin_datetime");
$departures = rows("SELECT b.id,b.booking_number,b.checkout_datetime,g.full_name FROM bookings b JOIN guests g ON g.id=b.guest_id WHERE b.booking_status='checked_in' AND DATE(b.checkout_datetime)<=CURDATE() ORDER BY b.checkout_datetime");
$lowStock = rows('SELECT item_name,current_stock,minimum_stock,unit FROM inventory_items WHERE current_stock <= minimum_stock ORDER BY current_stock LIMIT 6');
$chart = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i day"));
    $chart[] = ['d' => date('D', strtotime($d)),
        'in' => (float)val('SELECT COALESCE(SUM(amount),0) FROM payments WHERE DATE(payment_date)=?', [$d]) + (float)val('SELECT COALESCE(SUM(amount),0) FROM tenant_payments WHERE DATE(payment_date)=?', [$d]),
        'ex' => (float)val('SELECT COALESCE(SUM(amount),0) FROM expenses WHERE expense_date=?', [$d])];
}
$pageScripts = ['https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js'];
$inlineScript = 'const c=' . json_encode($chart) . ';new Chart(document.getElementById("rev"),{type:"bar",data:{labels:c.map(x=>x.d),datasets:[{label:"Collections",data:c.map(x=>x.in),backgroundColor:"#c9a24a"},{label:"Expenses",data:c.map(x=>x.ex),backgroundColor:"#27497a"}]},options:{responsive:true,plugins:{legend:{position:"bottom"}},scales:{y:{beginAtZero:true}}}});';
include ROOT . '/includes/header.php';
$stats = [['Available Rooms', $cnt['available'], 'bg-g2', 'bi-door-open'], ['Occupied', $cnt['occupied'], 'bg-g3', 'bi-person-fill-lock'], ['Reserved', $cnt['reserved'], 'bg-g5', 'bi-bookmark-check'],
    ['Needs Cleaning', $cnt['cleaning'], 'bg-g4', 'bi-bucket'], ['Monthly Occupied', $cnt['monthly'], 'bg-g6', 'bi-calendar-month'], ['Maintenance', $cnt['maintenance'], 'bg-g1', 'bi-tools']];
?>
<div class="row g-3 mb-3"><?php foreach ($stats as [$l, $n, $c, $i]): ?>
  <div class="col-6 col-md-4 col-xl-2"><div class="stat-card <?= $c ?>"><i class="bi <?= $i ?>"></i><div class="num"><?= (int)$n ?></div><div class="lbl"><?= e($l) ?></div></div></div>
<?php endforeach; ?></div>
<div class="row g-3 mb-3">
  <div class="col-6 col-md-3"><div class="card p-3"><div class="text-muted small">Collected today</div><div class="fs-4 fw-bold text-success"><?= money($todayPay + $todayRent) ?></div></div></div>
  <div class="col-6 col-md-3"><div class="card p-3"><div class="text-muted small">Restaurant sales today</div><div class="fs-4 fw-bold"><?= money($restSales) ?></div></div></div>
  <div class="col-6 col-md-3"><div class="card p-3"><div class="text-muted small">Expenses today</div><div class="fs-4 fw-bold text-danger"><?= money($todayExp) ?></div></div></div>
  <div class="col-6 col-md-3"><div class="card p-3"><div class="text-muted small">Total pending dues</div><div class="fs-4 fw-bold text-warning"><?= money($pending) ?></div></div></div>
</div>
<div class="row g-3">
  <div class="col-lg-7"><div class="card h-100"><div class="card-header fw-semibold">Last 7 days &mdash; collections vs expenses</div><div class="card-body"><canvas id="rev" height="130"></canvas></div></div></div>
  <div class="col-lg-5"><div class="card mb-3"><div class="card-header fw-semibold">Today's arrivals (<?= count($arrivals) ?>)</div><ul class="list-group list-group-flush">
    <?php foreach ($arrivals as $a): ?><li class="list-group-item d-flex justify-content-between"><span><?= e($a['full_name']) ?> <small class="text-muted"><?= e($a['booking_number']) ?></small></span><a href="<?= e(url('modules/bookings/details.php?id=' . $a['id'])) ?>" class="small"><?= e(dt($a['checkin_datetime'], 'h:i A')) ?> &rarr;</a></li><?php endforeach; if (!$arrivals) echo '<li class="list-group-item text-muted">No arrivals today.</li>'; ?></ul></div>
  <div class="card mb-3"><div class="card-header fw-semibold">Due for check-out (<?= count($departures) ?>)</div><ul class="list-group list-group-flush">
    <?php foreach ($departures as $a): ?><li class="list-group-item d-flex justify-content-between"><span><?= e($a['full_name']) ?> <small class="text-muted"><?= e($a['booking_number']) ?></small></span><a href="<?= e(url('modules/billing/checkout.php?booking_id=' . $a['id'])) ?>" class="small">Check-out &rarr;</a></li><?php endforeach; if (!$departures) echo '<li class="list-group-item text-muted">Nothing due.</li>'; ?></ul></div>
  <?php if ($lowStock): ?><div class="card"><div class="card-header fw-semibold text-danger">Low stock</div><ul class="list-group list-group-flush"><?php foreach ($lowStock as $s): ?><li class="list-group-item d-flex justify-content-between"><?= e($s['item_name']) ?><span class="text-danger"><?= e($s['current_stock'] + 0) ?> <?= e($s['unit']) ?></span></li><?php endforeach; ?></ul></div><?php endif; ?></div>
</div>
<?php include ROOT . '/includes/footer.php'; ?>
