<?php
require_once __DIR__ . '/_layout.php';
if (!can('payments') && !can('billing')) die('Access denied');
$p = row('SELECT p.*, i.invoice_number, i.grand_total, i.remaining_amount, g.full_name, u.full_name AS who FROM payments p JOIN invoices i ON i.id=p.invoice_id LEFT JOIN guests g ON g.id=i.guest_id LEFT JOIN users u ON u.id=p.received_by WHERE p.id=?', [(int)($_GET['id'] ?? 0)]);
if (!$p) die('Payment not found');
pr_start('Payment ' . $p['payment_number']);
echo '<div class="c b big">PAYMENT RECEIPT</div><table>' . pr_row('Receipt #', e($p['payment_number'])) . pr_row('Date', e(dt($p['payment_date']))) . pr_row('Invoice', e($p['invoice_number'])) . pr_row('Received from', e($p['full_name'] ?: 'Walk-in')) . pr_row('Method', e(PAYMENT_METHODS[$p['payment_method']] ?? '')) . ($p['transaction_reference'] ? pr_row('Reference', e($p['transaction_reference'])) : '')
 . '</table><div class="hr"></div><table>' . pr_row('AMOUNT RECEIVED', money($p['amount']), true) . pr_row('Invoice total', money($p['grand_total'])) . pr_row('Balance remaining', money($p['remaining_amount']), true) . '</table><div class="hr"></div><div>Received by: ' . e($p['who']) . '</div>';
pr_end();
