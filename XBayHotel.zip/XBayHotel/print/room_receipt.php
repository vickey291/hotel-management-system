<?php
// Room bill of a booking: ?id=<booking id>
require_once __DIR__ . '/_layout.php';
if (!can('billing') && !can('bookings')) die('Access denied');
$bid = (int)($_GET['id'] ?? 0);
if (!val('SELECT id FROM bookings WHERE id=?', [$bid])) die('Booking not found');
$iid = rebuild_invoice($bid); $i = row('SELECT * FROM invoices WHERE id=?', [$iid]);
pr_start('Room bill'); pr_invoice_body($i); pr_end();
