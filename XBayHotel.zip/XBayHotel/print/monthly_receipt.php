<?php
require_once __DIR__ . '/_layout.php';
if (!can('monthly')) die('Access denied');
$p = row('SELECT p.*, i.invoice_number, i.billing_month, i.total_amount, i.paid_amount, mt.contract_number, g.full_name, r.room_number, u.full_name AS who FROM tenant_payments p JOIN monthly_rent_invoices i ON i.id=p.rent_invoice_id JOIN monthly_tenants mt ON mt.id=p.tenant_id JOIN guests g ON g.id=mt.guest_id JOIN rooms r ON r.id=mt.room_id LEFT JOIN users u ON u.id=p.received_by WHERE p.id=?', [(int)($_GET['id'] ?? 0)]);
if (!$p) die('Receipt not found');
pr_start('Rent receipt ' . $p['receipt_number']);
echo '<div class="c b big">MONTHLY RENT RECEIPT</div><table>' . pr_row('Receipt #', e($p['receipt_number'])) . pr_row('Date', e(dt($p['payment_date']))) . pr_row('Tenant', e($p['full_name'])) . pr_row('Room', e($p['room_number'])) . pr_row('Contract', e($p['contract_number'])) . pr_row('Rent month', e(date('F Y', strtotime($p['billing_month'] . '-01')))) . pr_row('Method', e(PAYMENT_METHODS[$p['payment_method']] ?? ''))
 . '</table><div class="hr"></div><table>' . pr_row('AMOUNT RECEIVED', money($p['amount']), true) . pr_row('Month total', money($p['total_amount'])) . pr_row('Paid so far', money($p['paid_amount'])) . pr_row('Balance', money($p['total_amount'] - $p['paid_amount']), true) . '</table><div class="hr"></div><div>Received by: ' . e($p['who']) . '</div>';
pr_end();
