<?php
require_once __DIR__ . '/../includes/functions.php';
require_login();
function pr_size(): string { $s = $_GET['size'] ?? setting('receipt_size', '80'); return in_array((string)$s, ['58', '80', 'a4'], true) ? (string)$s : '80'; }
function pr_start(string $title, bool $auto = false): void {
    $sz = pr_size(); $H = hotel();
    $w = $sz === 'a4' ? '190mm' : ($sz === '58' ? '54mm' : '76mm'); $fs = $sz === 'a4' ? '13px' : ($sz === '58' ? '10.5px' : '12px');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . e($title) . '</title><style>
    @page{size:' . ($sz === 'a4' ? 'A4' : ($sz === '58' ? '58mm auto' : '80mm auto')) . ';margin:' . ($sz === 'a4' ? '10mm' : '2mm') . '}
    *{box-sizing:border-box}body{font-family:' . ($sz === 'a4' ? '"Segoe UI",Arial,sans-serif' : '"Courier New",monospace') . ';font-size:' . $fs . ';color:#000;margin:0;background:#eee}
    .sheet{width:' . $w . ';margin:8px auto;background:#fff;padding:' . ($sz === 'a4' ? '10mm' : '3mm') . '}
    h1,h2,h3{margin:0}.c{text-align:center}.r{text-align:right}.b{font-weight:700}.hr{border-top:1px dashed #000;margin:6px 0}
    table{width:100%;border-collapse:collapse}td,th{padding:2px 0;vertical-align:top;text-align:left}th.r,td.r{text-align:right}
    .tools{width:' . $w . ';margin:8px auto;display:flex;gap:6px;font-family:Arial}.tools a,.tools button{padding:6px 10px;border:1px solid #333;background:#fff;cursor:pointer;text-decoration:none;color:#000;font-size:12px}
    .big{font-size:' . ($sz === 'a4' ? '20px' : '15px') . '}
    @media print{body{background:#fff}.sheet{margin:0;width:auto;padding:0}.tools{display:none}}</style></head><body>';
    $base = strtok($_SERVER['REQUEST_URI'], '?'); $q = $_GET; unset($q['size']);
    echo '<div class="tools"><button onclick="window.print()">Print</button>';
    foreach (['58' => '58mm', '80' => '80mm', 'a4' => 'A4'] as $k => $l) echo '<a href="' . e($base . '?' . http_build_query($q + ['size' => $k])) . '">' . $l . '</a>';
    echo '</div><div class="sheet"><div class="c">';
    if ($H['logo'] && $sz === 'a4') echo '<img src="' . e(url('uploads/' . $H['logo'])) . '" style="height:50px"><br>';
    echo '<h2>' . e(strtoupper($H['hotel_name'])) . '</h2><div>' . e($H['tagline']) . '</div><div>' . e(trim($H['address'] . ', ' . $H['city'], ', ')) . '</div><div>' . e($H['phone']) . '</div>' . ($H['tax_number'] ? '<div>NTN: ' . e($H['tax_number']) . '</div>' : '') . '</div><div class="hr"></div>';
    if ($auto) echo '<script>window.addEventListener("load",function(){setTimeout(function(){window.print()},300)})</script>';
}
function pr_end(): void { $H = hotel(); echo '<div class="hr"></div><div class="c">' . e($H['receipt_footer']) . '</div><div class="c" style="font-size:9px;margin-top:4px">Printed ' . date('d M Y h:i A') . ' by ' . e(user()['full_name'] ?? '') . '</div></div></body></html>'; }
function pr_row(string $l, $v, bool $bold = false): string { return '<tr class="' . ($bold ? 'b' : '') . '"><td>' . e($l) . '</td><td class="r">' . $v . '</td></tr>'; }
function pr_invoice_body(array $i): void {
    $items = rows('SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY id', [$i['id']]);
    $g = $i['guest_id'] ? row('SELECT * FROM guests WHERE id=?', [$i['guest_id']]) : null;
    echo '<div class="c b">' . e(strtoupper(str_replace('_', ' ', $i['invoice_type']))) . ' INVOICE</div><table>' . pr_row('Invoice #', e($i['invoice_number'])) . pr_row('Date', e(dt($i['invoice_date'])));
    if ($g) echo pr_row('Guest', e($g['full_name'])) . pr_row('Phone', e($g['phone']));
    if ($i['booking_id']) { $b = row('SELECT booking_number, checkin_datetime, checkout_datetime FROM bookings WHERE id=?', [$i['booking_id']]); if ($b) echo pr_row('Booking', e($b['booking_number'])) . pr_row('Stay', e(dt($b['checkin_datetime'], 'd M h:i A') . ' - ' . dt($b['checkout_datetime'], 'd M h:i A'))); }
    echo '</table><div class="hr"></div><table><tr><th>Description</th><th class="r">Qty</th><th class="r">Amount</th></tr>';
    foreach ($items as $x) echo '<tr><td>' . e($x['description']) . '</td><td class="r">' . e($x['quantity'] + 0) . '</td><td class="r">' . money($x['total_price']) . '</td></tr>';
    echo '</table><div class="hr"></div><table>' . pr_row('Subtotal', money($i['subtotal']));
    if ($i['discount'] > 0) echo pr_row('Discount', '- ' . money($i['discount']));
    if ($i['tax_amount'] > 0) echo pr_row('Tax', money($i['tax_amount']));
    if ($i['service_charges'] > 0) echo pr_row('Service charge', money($i['service_charges']));
    echo pr_row('GRAND TOTAL', money($i['grand_total']), true) . pr_row('Paid', money($i['paid_amount'])) . pr_row('BALANCE DUE', money($i['remaining_amount']), true) . pr_row('Status', e(strtoupper($i['invoice_status']))) . '</table>';
    $pays = rows('SELECT * FROM payments WHERE invoice_id=? ORDER BY id', [$i['id']]);
    if ($pays) { echo '<div class="hr"></div><div class="b">Payments</div><table>'; foreach ($pays as $p) echo '<tr><td>' . e(dt($p['payment_date'], 'd M y') . ' ' . (PAYMENT_METHODS[$p['payment_method']] ?? '')) . '</td><td class="r">' . money($p['amount']) . '</td></tr>'; echo '</table>'; }
}
