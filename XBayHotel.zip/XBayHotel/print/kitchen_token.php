<?php
require_once __DIR__ . '/../includes/functions.php';
require_login();
if (!can('pos') && !can('kitchen')) die('Access denied');
$o = row('SELECT o.*, t.table_number, r.room_number FROM orders o LEFT JOIN restaurant_tables t ON t.id=o.table_id LEFT JOIN rooms r ON r.id=o.room_id WHERE o.id=?', [(int)($_GET['id'] ?? 0)]);
if (!$o) die('Order not found');
$items = rows('SELECT * FROM order_items WHERE order_id=? ORDER BY id', [$o['id']]);
$sz = in_array($_GET['size'] ?? '', ['58', '80'], true) ? $_GET['size'] : (setting('receipt_size', '80') === '58' ? '58' : '80');
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Kitchen token <?= e($o['order_number']) ?></title><style>
@page{size:<?= $sz ?>mm auto;margin:2mm}body{font-family:"Courier New",monospace;font-size:<?= $sz === '58' ? '12' : '14' ?>px;width:<?= $sz === '58' ? '54' : '76' ?>mm;margin:0 auto}
.c{text-align:center}.hr{border-top:2px dashed #000;margin:5px 0}.big{font-size:22px;font-weight:700}.i{margin:3px 0;font-weight:700}.s{font-weight:400;font-size:90%}</style></head><body>
<div class="c b">KITCHEN ORDER</div><div class="c big"><?= e($o['table_number'] ? 'TABLE ' . $o['table_number'] : ($o['room_number'] ? 'ROOM ' . $o['room_number'] : 'TAKEAWAY')) ?></div>
<div class="c"><?= e($o['order_number']) ?> &middot; <?= e(ORDER_TYPES[$o['order_type']]) ?><br><?= e(dt($o['order_date'], 'd M h:i A')) ?></div><div class="hr"></div>
<?php foreach ($items as $x): ?><div class="i"><?= (int)$x['quantity'] ?> x <?= e($x['item_name']) ?></div>
 <?php foreach (rows('SELECT * FROM order_item_addons WHERE order_item_id=?', [$x['id']]) as $a): ?><div class="s">&nbsp;&nbsp;+ <?= e($a['addon_name']) ?></div><?php endforeach; ?>
 <?php if ($x['item_notes']): ?><div class="s">&nbsp;&nbsp;* <?= e($x['item_notes']) ?></div><?php endif; ?><?php endforeach; ?>
<?php if ($o['notes']): ?><div class="hr"></div><div>NOTE: <?= e($o['notes']) ?></div><?php endif; ?>
<div class="hr"></div><div class="c">Waiter: <?= e(val('SELECT full_name FROM users WHERE id=?', [$o['created_by']])) ?></div>
<script>window.addEventListener('load',function(){setTimeout(function(){window.print()},300)})</script></body></html>
