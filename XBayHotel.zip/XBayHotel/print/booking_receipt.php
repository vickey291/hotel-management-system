<?php
require_once __DIR__ . '/_layout.php';
if (!can('bookings')) die('Access denied');
$b = row('SELECT b.*, g.full_name, g.phone, g.father_husband_name FROM bookings b JOIN guests g ON g.id=b.guest_id WHERE b.id=?', [(int)($_GET['id'] ?? 0)]);
if (!$b) die('Booking not found');
$rooms = rows('SELECT br.*, r.room_number, t.type_name FROM booking_rooms br JOIN rooms r ON r.id=br.room_id JOIN room_types t ON t.id=r.room_type_id WHERE br.booking_id=?', [$b['id']]);
$inv = row("SELECT * FROM invoices WHERE booking_id=? AND invoice_type IN ('room','checkout') LIMIT 1", [$b['id']]);
$cnic = val('SELECT document_number FROM guest_documents WHERE guest_id=? ORDER BY id DESC LIMIT 1', [$b['guest_id']]);
pr_start('Booking ' . $b['booking_number']);
echo '<div class="c b big">ROOM RESERVATION</div><div class="c">' . e(strtoupper(BOOKING_STATUSES[$b['booking_status']])) . '</div><div class="c b">Booking #' . e($b['booking_number']) . '</div><div class="hr"></div><table>'
 . pr_row('Guest', e($b['full_name'])) . ($b['father_husband_name'] ? pr_row('S/o, D/o, W/o', e($b['father_husband_name'])) : '') . pr_row('CNIC', e($cnic ?: '-')) . pr_row('Phone', e($b['phone'])) . pr_row('Members', (int)$b['adults'] . ' adults, ' . (int)$b['children'] . ' children')
 . '</table><div class="hr"></div><table>' . pr_row('Check-in', e(dt($b['checkin_datetime']))) . pr_row('Check-out', e(dt($b['checkout_datetime']))) . pr_row('Nights', (int)$b['total_nights']) . '</table><div class="hr"></div><table><tr><th>Room</th><th class="r">Rate/night</th></tr>';
foreach ($rooms as $r) echo '<tr><td>' . e($r['room_number'] . ' ' . $r['type_name']) . '</td><td class="r">' . money($r['room_rate']) . '</td></tr>';
echo '</table><div class="hr"></div><table>' . pr_row('Room rent (' . (int)$b['total_nights'] . ' nights)', money($b['room_total']));
if ($b['discount'] > 0) echo pr_row('Discount', '- ' . money($b['discount']));
echo pr_row('Total', money($inv['grand_total'] ?? $b['grand_total']), true) . pr_row('Advance paid', money($inv['paid_amount'] ?? 0)) . pr_row('Remaining', money($inv['remaining_amount'] ?? 0), true) . '</table>';
echo '<div class="hr"></div><div style="font-size:90%">Check-in time ' . e(setting('checkin_time', '14:00')) . ' &middot; Check-out time ' . e(setting('checkout_time', '12:00')) . '. Please carry original CNIC at check-in.</div>';
echo '<table style="margin-top:22px"><tr><td>____________<br>Guest</td><td class="r">____________<br>Reception</td></tr></table>';
pr_end();
