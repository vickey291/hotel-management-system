<?php
require_once __DIR__ . '/_layout.php';
if (!can('billing')) die('Access denied');
$i = row('SELECT * FROM invoices WHERE id=?', [(int)($_GET['id'] ?? 0)]);
if (!$i) die('Invoice not found');
if ($i['booking_id'] && $i['invoice_type'] === 'room') { rebuild_invoice((int)$i['booking_id']); $i = row('SELECT * FROM invoices WHERE id=?', [$i['id']]); }
pr_start('Invoice ' . $i['invoice_number']); pr_invoice_body($i); pr_end();
