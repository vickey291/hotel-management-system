<?php
require_once __DIR__ . '/_layout.php';
if (!can('pos') && !can('billing')) die('Access denied');
$o = row('SELECT o.*, t.table_number, r.room_number FROM orders o LEFT JOIN restaurant_tables t ON t.id=o.table_id LEFT JOIN rooms r ON r.id=o.room_id WHERE o.id=?', [(int)($_GET['id'] ?? 0)]);
if (!$o) die('Order not found');
$items = rows('SELECT * FROM order_items WHERE order_id=? ORDER BY id', [$o['id']]);
$inv = $o['invoice_id'] ? row('SELECT * FROM invoices WHERE id=?', [$o['invoice_id']]) : null;
pr_start('Bill ' . $o['order_number']);
echo '<div class="c b">RESTAURANT BILL</div><table>' . pr_row('Order #', e($o['order_number'])) . ($inv ? pr_row('Invoice #', e($inv['invoice_number'])) : '') . pr_row('Date', e(dt($o['order_date']))) . pr_row('Type', e(ORDER_TYPES[$o['order_type']])) . ($o['table_number'] ? pr_row('Table', e($o['table_number'])) : '') . ($o['room_number'] ? pr_row('Room', e($o['room_number'])) : '')
 . '</table><div class="hr"></div><table><tr><th>Item</th><th class="r">Qty</th><th class="r">Amount</th></tr>';
foreach ($items as $x) { echo '<tr><td>' . e($x['item_name']) . '</td><td class="r">' . (int)$x['quantity'] . '</td><td class="r">' . money($x['total_price']) . '</td></tr>'; foreach (rows('SELECT * FROM order_item_addons WHERE order_item_id=?', [$x['id']]) as $a) echo '<tr><td colspan="3">&nbsp;+ ' . e($a['addon_name']) . '</td></tr>'; }
echo '</table><div class="hr"></div><table>' . pr_row('Subtotal', money($o['subtotal'])) . ($o['discount'] > 0 ? pr_row('Discount', '- ' . money($o['discount'])) : '') . ($o['tax'] > 0 ? pr_row('Tax', money($o['tax'])) : '') . ($o['service_charges'] > 0 ? pr_row('Service charge', money($o['service_charges'])) : '') . pr_row('TOTAL', money($o['grand_total']), true);
if ($inv) echo pr_row('Paid', money($inv['paid_amount'])) . pr_row('Balance', money($inv['remaining_amount']), true);
echo '</table>';
pr_end();
