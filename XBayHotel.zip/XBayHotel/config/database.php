<?php
// XAMPP default credentials. Change 'pass' in production.
return [
    'host' => 'localhost',
    'name' => 'xbay_hotel_db',
    'user' => 'root',
    'pass' => '',
];
