<?php
const BOOKING_STATUSES = ['confirmed' => 'Confirmed', 'checked_in' => 'Checked-in', 'checked_out' => 'Checked-out', 'cancelled' => 'Cancelled', 'no_show' => 'No-show'];
const PAYMENT_METHODS  = ['cash' => 'Cash', 'bank_transfer' => 'Bank Transfer', 'card' => 'Card', 'online' => 'Online Payment'];
const BOOKING_SOURCES  = ['walk_in' => 'Walk-in', 'phone' => 'Phone', 'online' => 'Online', 'agent' => 'Agent'];
const CHARGE_TYPES     = ['laundry' => 'Laundry', 'extra_bed' => 'Extra Bed', 'food' => 'Food', 'room_service' => 'Room Service', 'electricity' => 'Electricity', 'damage' => 'Damage / Repair', 'other' => 'Other'];
const ORDER_TYPES      = ['dine_in' => 'Dine-in', 'room_service' => 'Room Service', 'takeaway' => 'Takeaway'];
