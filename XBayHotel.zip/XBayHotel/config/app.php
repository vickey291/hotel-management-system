<?php
define('ROOT', dirname(__DIR__));
$docRoot = rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
$rootPath = str_replace('\\', '/', ROOT);
// URL of the project folder, e.g. /XBayHotel/ (works when the folder sits inside htdocs)
if ($docRoot !== '' && strncasecmp($rootPath, $docRoot, strlen($docRoot)) === 0) {
    define('BASE_URL', rtrim(substr($rootPath, strlen($docRoot)), '/') . '/');
} else {
    define('BASE_URL', '/' . basename(ROOT) . '/');
}
define('APP_NAME', 'XBay Hotel');
define('APP_FULL_NAME', 'Cross Bay Hotel & Motel');
date_default_timezone_set('Asia/Karachi');
error_reporting(E_ALL);
ini_set('display_errors', '0');       // set to '1' while developing
ini_set('log_errors', '1');
