// Booking form: live nights + total, new/existing guest toggle, family member rows
document.addEventListener('DOMContentLoaded', () => {
  const f = document.getElementById('bookingForm'); if (!f) return;
  const inEl = f.querySelector('[name=checkin]'), outEl = f.querySelector('[name=checkout]');
  const calc = () => {
    const a = new Date(inEl.value), b = new Date(outEl.value);
    let n = Math.max(1, Math.ceil((b - a) / 86400000)); if (isNaN(n)) n = 1;
    let total = 0, cnt = 0;
    f.querySelectorAll('.room-pick').forEach(row => {
      const cb = row.querySelector('input[type=checkbox]'), rate = row.querySelector('input[type=number]');
      rate.disabled = !cb.checked;
      if (cb.checked) { total += (parseFloat(rate.value) || 0) * n; cnt++; }
    });
    const disc = parseFloat(f.querySelector('[name=discount]').value) || 0;
    const adv = parseFloat(f.querySelector('[name=advance]').value) || 0;
    const net = Math.max(0, total - disc);
    document.getElementById('sumNights').textContent = n;
    document.getElementById('sumRooms').textContent = cnt;
    document.getElementById('sumTotal').textContent = fmt(net);
    document.getElementById('sumRemain').textContent = fmt(Math.max(0, net - adv));
  };
  f.addEventListener('input', calc); f.addEventListener('change', calc); calc();
  const modeRadios = f.querySelectorAll('[name=guest_mode]');
  const toggle = () => {
    const m = f.querySelector('[name=guest_mode]:checked').value;
    document.getElementById('newGuestBox').style.display = m === 'new' ? '' : 'none';
    document.getElementById('oldGuestBox').style.display = m === 'old' ? '' : 'none';
    f.querySelectorAll('#newGuestBox [data-req]').forEach(i => i.required = m === 'new');
    f.querySelector('[name=guest_id]').required = m === 'old';
  };
  modeRadios.forEach(r => r.addEventListener('change', toggle)); toggle();
  document.getElementById('addOcc').addEventListener('click', () => {
    const d = document.createElement('div'); d.className = 'row g-2 mb-2';
    d.innerHTML = '<div class="col-7"><input name="occ_name[]" class="form-control form-control-sm" placeholder="Family member name"></div><div class="col-4"><input name="occ_rel[]" class="form-control form-control-sm" placeholder="Relation"></div><div class="col-1"><button type="button" class="btn btn-sm btn-outline-danger">&times;</button></div>';
    d.querySelector('button').onclick = () => d.remove();
    document.getElementById('occList').appendChild(d);
  });
});
