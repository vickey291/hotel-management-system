// Restaurant POS: category filter, variant/add-on modal, cart, submit to api/orders/create.php
(() => {
  const D = window.POS_DATA; if (!D) return;
  let cart = [];
  const $ = s => document.querySelector(s);
  const grid = $('#posItems'), linesEl = $('#cartLines');
  const modalEl = $('#itemModal'), modal = new bootstrap.Modal(modalEl);
  let cur = null;

  document.querySelectorAll('.cat-tabs button').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('.cat-tabs button').forEach(x => x.classList.remove('active')); b.classList.add('active');
    const c = b.dataset.cat; document.querySelectorAll('.pos-item').forEach(i => i.style.display = (c === 'all' || i.dataset.cat === c) ? '' : 'none');
  }));
  $('#posSearch').addEventListener('input', e => { const s = e.target.value.toLowerCase(); document.querySelectorAll('.pos-item').forEach(i => i.style.display = i.dataset.name.includes(s) ? '' : 'none'); });
  grid.addEventListener('click', e => { const el = e.target.closest('.pos-item'); if (el) openItem(+el.dataset.id); });

  function openItem(id) {
    const it = D.items.find(x => x.id === id); cur = it;
    if (!it.variants.length && !it.addons.length) { add({id, name: it.name, price: it.price, variant_id: null, addons: [], addonNames: [], note: ''}); return; }
    $('#mName').textContent = it.name;
    $('#mVariants').innerHTML = it.variants.length ? '<div class="fw-semibold small mb-1">Size / variant</div>' + it.variants.map((v, i) => `<div class="form-check"><input class="form-check-input" type="radio" name="mv" id="mv${v.id}" value="${v.id}" ${i === 0 ? 'checked' : ''}><label class="form-check-label" for="mv${v.id}">${v.name} &mdash; ${fmt(v.price)}</label></div>`).join('') : '';
    $('#mAddons').innerHTML = it.addons.length ? '<div class="fw-semibold small mt-2 mb-1">Extras</div>' + it.addons.map(a => `<div class="form-check"><input class="form-check-input ma" type="checkbox" value="${a.id}" id="ma${a.id}"><label class="form-check-label" for="ma${a.id}">${a.name} (+${fmt(a.price)})</label></div>`).join('') : '';
    $('#mNote').value = ''; modal.show();
  }
  $('#mAdd').addEventListener('click', () => {
    const it = cur; let price = it.price, name = it.name, vid = null;
    const vr = document.querySelector('input[name=mv]:checked');
    if (vr) { const v = it.variants.find(x => x.id == vr.value); price = v.price; name += ' (' + v.name + ')'; vid = v.id; }
    const ad = [], an = [];
    document.querySelectorAll('.ma:checked').forEach(c => { const a = it.addons.find(x => x.id == c.value); ad.push(a.id); an.push(a.name); price += a.price; });
    add({id: it.id, name, price, variant_id: vid, addons: ad, addonNames: an, note: $('#mNote').value.trim()}); modal.hide();
  });
  function add(l) {
    const key = JSON.stringify([l.id, l.variant_id, l.addons, l.note]);
    const ex = cart.find(c => c.key === key); if (ex) ex.qty++; else cart.push({...l, qty: 1, key}); render();
  }
  window.posChange = (i, d) => { cart[i].qty += d; if (cart[i].qty <= 0) cart.splice(i, 1); render(); };
  function totals() {
    const sub = cart.reduce((s, c) => s + c.price * c.qty, 0), disc = Math.min(sub, Math.max(0, parseFloat($('#discount').value) || 0));
    const type = $('#orderType').value, net = sub - disc;
    const tax = type === 'room_service' ? 0 : net * D.taxPct / 100, svc = type === 'dine_in' ? net * D.svcPct / 100 : 0;
    return {sub, disc, tax, svc, grand: net + tax + svc};
  }
  function render() {
    linesEl.innerHTML = cart.length ? cart.map((c, i) => `<div class="cart-line"><div class="flex-grow-1"><div class="fw-semibold">${c.name}</div><div class="small text-muted">${c.addonNames.join(', ')}${c.note ? ' &middot; ' + c.note : ''}</div></div>
      <div class="qty d-flex align-items-center gap-1"><button class="btn btn-outline-secondary btn-sm" onclick="posChange(${i},-1)">&minus;</button><b>${c.qty}</b><button class="btn btn-outline-secondary btn-sm" onclick="posChange(${i},1)">+</button></div><div class="text-end" style="width:80px">${fmt(c.price * c.qty)}</div></div>`).join('') : '<div class="text-center text-muted py-5">Tap items to add</div>';
    const t = totals(); $('#tSub').textContent = fmt(t.sub); $('#tTax').textContent = fmt(t.tax + t.svc); $('#tGrand').textContent = fmt(t.grand);
  }
  function typeUI() { const t = $('#orderType').value; $('#tableBox').style.display = t === 'dine_in' ? '' : 'none'; $('#roomBox').style.display = t === 'room_service' ? '' : 'none'; render(); }
  $('#orderType').addEventListener('change', typeUI); $('#discount').addEventListener('input', render); typeUI();
  $('#placeOrder').addEventListener('click', async () => {
    if (!cart.length) return alert('Cart is empty');
    const btn = $('#placeOrder'); btn.disabled = true;
    const r = await postJSON(XB.base + 'api/orders/create.php', {type: $('#orderType').value, table_id: $('#tableSel').value, room_id: $('#roomSel').value, discount: $('#discount').value, notes: $('#orderNotes').value,
      items: cart.map(c => ({id: c.id, variant_id: c.variant_id, qty: c.qty, addons: c.addons, note: c.note}))});
    btn.disabled = false;
    if (!r.ok) return alert(r.error);
    window.open(r.kitchen_token, '_blank'); location.href = r.url;
  });
})();
