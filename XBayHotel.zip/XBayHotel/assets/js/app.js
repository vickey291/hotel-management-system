// Global behaviour for every page
document.addEventListener('DOMContentLoaded', () => {
  const sb = document.getElementById('sidebar'), tg = document.getElementById('sidebarToggle');
  if (tg && sb) tg.addEventListener('click', () => sb.classList.toggle('open'));
  // client-side table filter: <input data-table-filter="#tableId">
  document.querySelectorAll('[data-table-filter]').forEach(inp => {
    const t = document.querySelector(inp.dataset.tableFilter);
    inp.addEventListener('input', () => {
      const s = inp.value.toLowerCase();
      t.querySelectorAll('tbody tr').forEach(tr => tr.style.display = tr.textContent.toLowerCase().includes(s) ? '' : 'none');
    });
  });
  // auto-dismiss alerts
  setTimeout(() => document.querySelectorAll('.alert-success').forEach(a => bootstrap.Alert.getOrCreateInstance(a).close()), 4500);
});
window.fmt = n => (window.XB ? XB.currency + ' ' : '') + Number(n).toLocaleString(undefined, {maximumFractionDigits: 2});
window.postJSON = async (url, data) => {
  const r = await fetch(url, {method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': XB.csrf}, body: JSON.stringify(data)});
  return r.json();
};
