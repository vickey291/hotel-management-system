<?php
require_once __DIR__ . '/includes/functions.php';
if (!empty($_SESSION['login_log_id'])) { try { q('UPDATE login_logs SET logout_time = NOW() WHERE id=?', [$_SESSION['login_log_id']]); } catch (Throwable $e) {} }
$_SESSION = [];
session_destroy();
header('Location: ' . BASE_URL . 'login.php');
exit;
