<?php
$menu = require __DIR__ . '/permissions.php';
$H = hotel();
$cur = $_SERVER['REQUEST_URI'] ?? '';
?>
<aside class="sidebar" id="sidebar">
  <a class="brand" href="<?= e(url('modules/dashboard/')) ?>">
    <?php if (!empty($H['logo'])): ?><img src="<?= e(url('uploads/' . $H['logo'])) ?>" alt="logo"><?php else: ?><span class="brand-mark">XB</span><?php endif; ?>
    <span class="brand-text"><strong><?= e(strtoupper($H['hotel_name'])) ?></strong><small><?= e($H['city'] ?: 'KOTLI') ?></small></span>
  </a>
  <nav class="side-nav">
    <?php foreach ($menu as [$label, $icon, $path, $perm]):
        if (!can($perm)) continue;
        $href = url($path);
        $active = rtrim(strtok($cur, '?'), '/') === rtrim($href, '/') || (str_ends_with($href, '/') && str_starts_with($cur, $href) && $path !== 'modules/bookings/create.php' && !str_contains($cur, 'create.php')); ?>
      <a href="<?= e($href) ?>" class="<?= $active ? 'active' : '' ?>"><i class="bi <?= e($icon) ?>"></i><span><?= e($label) ?></span></a>
    <?php endforeach; ?>
  </nav>
  <div class="side-foot">XBay &middot; <?= e(APP_FULL_NAME) ?></div>
</aside>
