<?php
// Usage: set $pageTitle (and optionally $pageScripts = ['assets/js/x.js'], $pageStyles = []) then include this file.
$pageTitle = $pageTitle ?? 'Dashboard';
$H = hotel();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?= e(csrf()) ?>">
<title><?= e($pageTitle) ?> &middot; <?= e($H['hotel_name']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= e(url('assets/css/style.css')) ?>" rel="stylesheet">
<?php foreach (($pageStyles ?? []) as $s): ?><link href="<?= e(url($s)) ?>" rel="stylesheet"><?php endforeach; ?>
</head>
<body>
<div class="app-shell">
<?php include __DIR__ . '/sidebar.php'; ?>
<div class="app-main">
<?php include __DIR__ . '/navbar.php'; ?>
<main class="app-content">
<?= flash_html() ?>
