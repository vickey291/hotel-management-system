<?php
// Helper: sidebar menu definition (label, icon, path, permission key)
return [
    ['Dashboard', 'bi-speedometer2', 'modules/dashboard/', 'dashboard'],
    ['Room Management', 'bi-door-open', 'modules/rooms/', 'rooms'],
    ['Room Booking', 'bi-calendar-plus', 'modules/bookings/create.php', 'bookings'],
    ['Bookings / Check-in / Out', 'bi-journal-check', 'modules/bookings/', 'bookings'],
    ['Monthly Rooms', 'bi-calendar-month', 'modules/monthly_rooms/', 'monthly'],
    ['Guest Management', 'bi-people', 'modules/guests/', 'guests'],
    ['Restaurant POS', 'bi-cart4', 'modules/restaurant/', 'pos'],
    ['Orders', 'bi-receipt-cutoff', 'modules/orders/', 'pos'],
    ['Room Service Charges', 'bi-bell', 'modules/room_services/', 'bookings'],
    ['Kitchen Orders', 'bi-fire', 'modules/kitchen/', 'kitchen'],
    ['Menu Management', 'bi-egg-fried', 'modules/menu/', 'menu'],
    ['Table Management', 'bi-grid-3x3-gap', 'modules/tables/', 'menu'],
    ['Billing', 'bi-file-earmark-text', 'modules/billing/', 'billing'],
    ['Payments', 'bi-cash-coin', 'modules/payments/', 'payments'],
    ['Expenses', 'bi-wallet2', 'modules/expenses/', 'expenses'],
    ['Inventory', 'bi-boxes', 'modules/inventory/', 'inventory'],
    ['Reports', 'bi-bar-chart-line', 'modules/reports/', 'reports'],
    ['Staff Management', 'bi-person-badge', 'modules/staff/', 'staff'],
    ['Hotel Settings', 'bi-gear', 'modules/settings/', 'settings'],
];
