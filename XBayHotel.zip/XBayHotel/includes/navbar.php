<header class="topbar">
  <button class="btn btn-light d-lg-none" id="sidebarToggle" type="button"><i class="bi bi-list"></i></button>
  <div class="topbar-title"><?= e($pageTitle ?? '') ?></div>
  <div class="ms-auto d-flex align-items-center gap-3">
    <?php if (can('bookings')): ?><a href="<?= e(url('modules/bookings/create.php')) ?>" class="btn btn-gold btn-sm d-none d-md-inline-flex"><i class="bi bi-plus-lg me-1"></i>New Booking</a><?php endif; ?>
    <?php if (can('pos')): ?><a href="<?= e(url('modules/restaurant/')) ?>" class="btn btn-outline-dark btn-sm d-none d-md-inline-flex"><i class="bi bi-cart4 me-1"></i>POS</a><?php endif; ?>
    <div class="dropdown">
      <a class="d-flex align-items-center text-decoration-none text-dark dropdown-toggle" href="#" data-bs-toggle="dropdown">
        <span class="avatar"><?= e(strtoupper(substr(user()['full_name'] ?? 'U', 0, 1))) ?></span>
        <span class="ms-2 d-none d-md-inline small fw-semibold"><?= e(user()['full_name'] ?? '') ?></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><span class="dropdown-item-text small text-muted"><?= e(user()['role_name'] ?? '') ?></span></li>
        <li><a class="dropdown-item" href="<?= e(url('modules/staff/profile.php')) ?>"><i class="bi bi-key me-2"></i>Change password</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="<?= e(url('logout.php')) ?>"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</header>
