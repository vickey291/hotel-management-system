<?php
/** Creates the rent invoice of every active tenant for $month (YYYY-MM). Safe to call repeatedly. */
function generate_monthly_invoices(string $month): int {
    if (!preg_match('/^\d{4}-\d{2}$/', $month)) return 0;
    $n = 0;
    $tenants = rows("SELECT * FROM monthly_tenants WHERE tenant_status='active' AND billing_status='active' AND start_date <= LAST_DAY(?) AND (end_date IS NULL OR end_date >= ?)", [$month . '-01', $month . '-01']);
    foreach ($tenants as $t) {
        $day = min(max(1, (int)$t['rent_due_day']), (int)date('t', strtotime($month . '-01')));
        $st = q('INSERT IGNORE INTO monthly_rent_invoices (tenant_id, invoice_number, billing_month, rent_amount, total_amount, due_date) VALUES (?,?,?,?,?,?)',
            [$t['id'], next_number('MI-', 'monthly_rent_invoices'), $month, $t['monthly_rent'], $t['monthly_rent'], sprintf('%s-%02d', $month, $day)]);
        $n += $st->rowCount();
    }
    return $n;
}
function recalc_monthly_invoice(int $id): void {
    $i = row('SELECT * FROM monthly_rent_invoices WHERE id=?', [$id]); if (!$i) return;
    $total = max(0, $i['rent_amount'] + $i['electricity_charges'] + $i['water_charges'] + $i['other_charges'] - $i['discount']);
    $paid = (float)val('SELECT COALESCE(SUM(amount),0) FROM tenant_payments WHERE rent_invoice_id=?', [$id]);
    $st = $paid <= 0 ? 'unpaid' : ($paid + 0.009 >= $total ? 'paid' : 'partial');
    q('UPDATE monthly_rent_invoices SET total_amount=?, paid_amount=?, invoice_status=? WHERE id=?', [$total, $paid, $st, $id]);
}
