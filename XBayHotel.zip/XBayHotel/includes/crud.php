<?php
/**
 * Generic CRUD page. A module page sets $crud and includes this file.
 * $crud = [title, table, perm, select (SQL), columns [key=>label], format [key=>money|bool|img|status|date],
 *          fields [[name,label,type,required,sql|options,dir,nullable,step,col,help,default]], row_actions (callable), toolbar (html), after_save (callable)]
 */
require_perm($crud['perm']);
$table = $crud['table'];
$fields = $crud['fields'];

function crud_options(array $f): array {
    if (isset($f['options'])) return $f['options'];
    $o = [];
    if (isset($f['sql'])) foreach (rows($f['sql']) as $r) { $v = array_values($r); $o[$v[0]] = $v[1]; }
    return $o;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $act = $_POST['_action'] ?? '';
        if ($act === 'delete') {
            $did = (int)$_POST['id'];
            q("DELETE FROM `$table` WHERE id=?", [$did]);
            audit('delete', $table, $did);
            flash('Record deleted.');
        } elseif ($act === 'save') {
            $eid = (int)($_POST['id'] ?? 0);
            $data = [];
            foreach ($fields as $f) {
                $n = $f['name']; $t = $f['type'] ?? 'text';
                if ($t === 'checkbox') { $data[$n] = isset($_POST[$n]) ? 1 : 0; continue; }
                if ($t === 'file') { $up = upload_file($n, $f['dir'] ?? 'other'); if ($up) $data[$n] = $up; continue; }
                if ($t === 'password') {
                    $pw = $_POST[$n] ?? '';
                    if ($pw === '' && !$eid) throw new RuntimeException(($f['label'] ?? 'Password') . ' is required for a new record.');
                    if ($pw !== '') { if (strlen($pw) < 8) throw new RuntimeException('Password must be at least 8 characters.'); $data[$f['column'] ?? $n] = password_hash($pw, PASSWORD_DEFAULT); }
                    continue;
                }
                $v = trim((string)($_POST[$n] ?? ''));
                if (!empty($f['required']) && $v === '') throw new RuntimeException(($f['label'] ?? $n) . ' is required.');
                $data[$n] = ($v === '' && !empty($f['nullable'])) ? null : $v;
            }
            if ($eid) {
                $set = implode(',', array_map(fn($k) => "`$k`=?", array_keys($data)));
                q("UPDATE `$table` SET $set WHERE id=?", [...array_values($data), $eid]);
                $rid = $eid; audit('update', $table, $rid);
            } else {
                $cols = implode(',', array_map(fn($k) => "`$k`", array_keys($data)));
                q("INSERT INTO `$table` ($cols) VALUES (" . implode(',', array_fill(0, count($data), '?')) . ')', array_values($data));
                $rid = (int)db()->lastInsertId(); audit('create', $table, $rid);
            }
            if (!empty($crud['after_save'])) ($crud['after_save'])($rid);
            flash('Saved successfully.');
        }
    } catch (PDOException $ex) {
        flash($ex->getCode() == 23000 ? 'Could not complete: duplicate value, or this record is used elsewhere.' : 'Database error: ' . $ex->getMessage(), 'danger');
    } catch (Throwable $ex) { flash($ex->getMessage(), 'danger'); }
    redirect(strtok($_SERVER['REQUEST_URI'], '?'));
}

$action = $_GET['action'] ?? 'list';
$id = (int)($_GET['id'] ?? 0);
$pageTitle = $crud['title'];
include ROOT . '/includes/header.php';

if ($action === 'add' || $action === 'edit'):
    $rec = $action === 'edit' ? row("SELECT * FROM `$table` WHERE id=?", [$id]) : [];
    if ($action === 'edit' && !$rec) { echo '<div class="alert alert-danger">Record not found.</div>'; include ROOT . '/includes/footer.php'; exit; }
?>
<div class="card shadow-sm"><div class="card-header fw-semibold"><?= $action === 'edit' ? 'Edit' : 'Add' ?> &mdash; <?= e($crud['title']) ?></div>
<div class="card-body">
<form method="post" enctype="multipart/form-data" class="row g-3">
  <?= csrf_field() ?><input type="hidden" name="_action" value="save"><input type="hidden" name="id" value="<?= (int)$id ?>">
  <?php foreach ($fields as $f):
    $n = $f['name']; $t = $f['type'] ?? 'text'; $v = $rec[$n] ?? ($f['default'] ?? ''); $col = $f['col'] ?? 6; ?>
    <div class="col-md-<?= (int)$col ?>">
    <?php if ($t === 'checkbox'): ?>
      <div class="form-check form-switch mt-4"><input class="form-check-input" type="checkbox" name="<?= e($n) ?>" id="f_<?= e($n) ?>" value="1" <?= ($action === 'edit' ? !empty($rec[$n]) : ($f['default'] ?? 1)) ? 'checked' : '' ?>><label class="form-check-label" for="f_<?= e($n) ?>"><?= e($f['label']) ?></label></div>
    <?php else: ?>
      <label class="form-label"><?= e($f['label']) ?><?= !empty($f['required']) ? ' <span class="text-danger">*</span>' : '' ?></label>
      <?php if ($t === 'select'): ?>
        <select name="<?= e($n) ?>" class="form-select" <?= !empty($f['required']) ? 'required' : '' ?>>
          <?php if (!empty($f['nullable']) || empty($f['required'])): ?><option value="">-- select --</option><?php endif; ?>
          <?php foreach (crud_options($f) as $ov => $ol): ?><option value="<?= e($ov) ?>" <?= (string)$ov === (string)$v ? 'selected' : '' ?>><?= e($ol) ?></option><?php endforeach; ?>
        </select>
      <?php elseif ($t === 'textarea'): ?>
        <textarea name="<?= e($n) ?>" rows="3" class="form-control"><?= e($v) ?></textarea>
      <?php elseif ($t === 'file'): ?>
        <input type="file" name="<?= e($n) ?>" class="form-control" accept="image/*">
        <?php if (!empty($rec[$n])): ?><img src="<?= e(url('uploads/' . $rec[$n])) ?>" class="mt-2 rounded border" style="height:60px"><?php endif; ?>
      <?php elseif ($t === 'password'): ?>
        <input type="password" name="<?= e($n) ?>" class="form-control" autocomplete="new-password" minlength="8" <?= ($action === 'add' && !empty($f['required'])) ? 'required' : '' ?>>
        <?php if ($action === 'edit'): ?><div class="form-text">Leave blank to keep the current password.</div><?php endif; ?>
      <?php else: ?>
        <input type="<?= e($t) ?>" name="<?= e($n) ?>" value="<?= e($v) ?>" class="form-control" <?= !empty($f['step']) ? 'step="' . e($f['step']) . '"' : ($t === 'number' ? 'step="any"' : '') ?> <?= !empty($f['required']) ? 'required' : '' ?>>
      <?php endif; ?>
      <?php if (!empty($f['help'])): ?><div class="form-text"><?= e($f['help']) ?></div><?php endif; ?>
    <?php endif; ?>
    </div>
  <?php endforeach; ?>
  <div class="col-12 d-flex gap-2"><button class="btn btn-gold"><i class="bi bi-check2-circle me-1"></i>Save</button><a class="btn btn-outline-secondary" href="<?= e(strtok($_SERVER['REQUEST_URI'], '?')) ?>">Cancel</a></div>
</form></div></div>
<?php else:
    $list = rows($crud['select']);
    $fmt = $crud['format'] ?? [];
?>
<div class="d-flex flex-wrap gap-2 align-items-center mb-3">
  <input type="search" class="form-control" style="max-width:280px" placeholder="Search..." data-table-filter="#crudTable">
  <div class="ms-auto d-flex gap-2"><?= $crud['toolbar'] ?? '' ?><a href="?action=add" class="btn btn-gold"><i class="bi bi-plus-lg me-1"></i>Add New</a></div>
</div>
<div class="card shadow-sm"><div class="table-responsive">
<table class="table table-hover align-middle mb-0" id="crudTable">
  <thead><tr><?php foreach ($crud['columns'] as $label): ?><th><?= e($label) ?></th><?php endforeach; ?><th class="text-end">Actions</th></tr></thead>
  <tbody>
  <?php foreach ($list as $r): ?>
    <tr>
      <?php foreach ($crud['columns'] as $k => $label): $x = $r[$k] ?? ''; $f = $fmt[$k] ?? ''; ?>
        <td><?php
          if ($f === 'money') echo money($x);
          elseif ($f === 'bool') echo $x ? badge('Active', 'success') : badge('Inactive', 'secondary');
          elseif ($f === 'img') echo $x ? '<img src="' . e(url('uploads/' . $x)) . '" style="height:38px" class="rounded">' : '<span class="text-muted">-</span>';
          elseif ($f === 'status') echo badge(ucwords(str_replace('_', ' ', $x)), status_class((string)$x));
          elseif ($f === 'date') echo e(dt($x, 'd M Y'));
          else echo e($x);
        ?></td>
      <?php endforeach; ?>
      <td class="text-end text-nowrap">
        <?= !empty($crud['row_actions']) ? ($crud['row_actions'])($r) : '' ?>
        <a class="btn btn-sm btn-outline-primary" href="?action=edit&id=<?= (int)$r['id'] ?>"><i class="bi bi-pencil"></i></a>
        <form method="post" class="d-inline" onsubmit="return confirm('Delete this record?')"><?= csrf_field() ?><input type="hidden" name="_action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button></form>
      </td>
    </tr>
  <?php endforeach; if (!$list): ?><tr><td colspan="<?= count($crud['columns']) + 1 ?>" class="text-center text-muted py-4">No records yet.</td></tr><?php endif; ?>
  </tbody>
</table></div></div>
<?php endif;
include ROOT . '/includes/footer.php';
