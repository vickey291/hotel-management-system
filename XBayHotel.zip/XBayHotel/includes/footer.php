</main>
<footer class="app-footer">&copy; <?= date('Y') ?> <?= e(hotel()['hotel_name']) ?> &middot; Hotel Management &amp; POS System</footer>
</div><!-- /app-main -->
</div><!-- /app-shell -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>window.XB = { base: <?= json_encode(BASE_URL) ?>, csrf: <?= json_encode(csrf()) ?>, currency: <?= json_encode(hotel()['currency']) ?> };</script>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
<?php foreach (($pageScripts ?? []) as $s): ?><script <?= str_starts_with($s, 'http') ? '' : '' ?>src="<?= e(str_starts_with($s, 'http') ? $s : url($s)) ?>"></script><?php endforeach; ?>
<?php if (!empty($inlineScript)): ?><script><?= $inlineScript ?></script><?php endif; ?>
</body>
</html>
