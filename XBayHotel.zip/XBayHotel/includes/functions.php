<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/constants.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('xbay_session');
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

/* ---------- Database ---------- */
function db(): PDO {
    static $pdo = null;
    if (!$pdo) {
        $c = require ROOT . '/config/database.php';
        $pdo = new PDO("mysql:host={$c['host']};dbname={$c['name']};charset=utf8mb4", $c['user'], $c['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}
function q(string $sql, array $p = []): PDOStatement { $s = db()->prepare($sql); $s->execute($p); return $s; }
function rows(string $sql, array $p = []): array { return q($sql, $p)->fetchAll(); }
function row(string $sql, array $p = []): ?array { $r = q($sql, $p)->fetch(); return $r ?: null; }
function val(string $sql, array $p = []) { $r = q($sql, $p)->fetchColumn(); return $r === false ? null : $r; }

/* ---------- Helpers ---------- */
function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function url(string $p = ''): string { return BASE_URL . ltrim($p, '/'); }
function redirect(string $p) { header('Location: ' . ($p !== '' && $p[0] === '/' || str_starts_with($p, 'http') ? $p : url($p))); exit; }
function flash(string $m, string $t = 'success') { $_SESSION['flash'][] = [$t, $m]; }
function flash_html(): string {
    $h = '';
    foreach ($_SESSION['flash'] ?? [] as [$t, $m]) $h .= '<div class="alert alert-' . e($t) . ' alert-dismissible fade show" role="alert">' . e($m) . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    unset($_SESSION['flash']);
    return $h;
}
function csrf(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . csrf() . '">'; }
function csrf_check(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $t = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!hash_equals($_SESSION['csrf'] ?? '', (string)$t)) { http_response_code(419); die('Invalid or expired security token. Please go back, reload the page and try again.'); }
    }
}
function money($n): string { $n = (float)$n; return e(hotel()['currency']) . ' ' . number_format($n, fmod($n, 1) ? 2 : 0); }
function dt($s, string $f = 'd M Y, h:i A'): string { return $s ? date($f, strtotime($s)) : '-'; }
function badge(string $text, string $cls = 'secondary'): string { return '<span class="badge text-bg-' . e($cls) . '">' . e($text) . '</span>'; }
function status_class(string $s): string {
    return ['paid' => 'success', 'completed' => 'success', 'verified' => 'success', 'checked_out' => 'secondary', 'confirmed' => 'primary', 'checked_in' => 'danger',
        'partial' => 'warning', 'pending' => 'warning', 'unpaid' => 'danger', 'cancelled' => 'dark', 'no_show' => 'dark', 'open' => 'info', 'ready' => 'success', 'preparing' => 'info'][$s] ?? 'secondary';
}
function hotel(): array {
    static $h = null;
    if ($h === null) {
        try { $h = row('SELECT * FROM hotel_settings LIMIT 1') ?: []; } catch (Throwable $e) { $h = []; }
        $h += ['hotel_name' => 'XBay Hotel', 'tagline' => 'Cross Bay Hotel & Motel', 'logo' => '', 'phone' => '', 'email' => '', 'address' => '', 'city' => 'Kotli', 'country' => 'Pakistan', 'website' => '', 'currency' => 'Rs.', 'tax_number' => '', 'receipt_footer' => ''];
    }
    return $h;
}
function setting(string $k, $d = '') {
    static $all = null;
    if ($all === null) { $all = []; try { foreach (rows('SELECT setting_key, setting_value FROM system_settings') as $r) $all[$r['setting_key']] = $r['setting_value']; } catch (Throwable $e) {} }
    return $all[$k] ?? $d;
}
function set_setting(string $k, string $v, string $g = 'general'): void {
    q('INSERT INTO system_settings (setting_key, setting_value, setting_group) VALUES (?,?,?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)', [$k, $v, $g]);
}
function next_number(string $prefix, string $table): string {
    $n = (int)val("SELECT COALESCE(MAX(id),0)+1 FROM `$table`");
    return $prefix . (1000 + $n);
}
function audit(string $action, string $module, ?int $rid = null, string $desc = ''): void {
    try { q('INSERT INTO audit_logs (user_id, action, module_name, record_id, description) VALUES (?,?,?,?,?)', [user()['id'] ?? null, $action, $module, $rid, $desc]); } catch (Throwable $e) {}
}
function nights_between(string $in, string $out): int { return max(1, (int)ceil((strtotime($out) - strtotime($in)) / 86400)); }

/* ---------- File uploads ---------- */
function upload_file(string $field, string $dir, bool $private = false, bool $allowPdf = false): ?string {
    if (empty($_FILES[$field]['name']) || ($_FILES[$field]['error'] ?? 4) === UPLOAD_ERR_NO_FILE) return null;
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('File upload failed.');
    if ($f['size'] > 5 * 1024 * 1024) throw new RuntimeException('File is too large (max 5 MB).');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $ok = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if ($allowPdf) $ok['application/pdf'] = 'pdf';
    if (!isset($ok[$mime])) throw new RuntimeException('Only JPG, PNG, WEBP' . ($allowPdf ? ' or PDF' : '') . ' files are allowed.');
    $base = ROOT . ($private ? '/storage/' : '/uploads/') . $dir;
    if (!is_dir($base)) mkdir($base, 0775, true);
    $name = bin2hex(random_bytes(10)) . '.' . $ok[$mime];
    if (!move_uploaded_file($f['tmp_name'], "$base/$name")) throw new RuntimeException('Could not save the uploaded file.');
    return "$dir/$name";
}

/* ---------- Auth & permissions ---------- */
function user(): ?array { return $_SESSION['user'] ?? null; }
function can(string $k): bool {
    $u = user(); if (!$u) return false;
    return (int)$u['role_id'] === 1 || in_array($k, $_SESSION['perms'] ?? [], true);
}
function require_login(): void {
    if (!user()) redirect('login.php');
    csrf_check();
}
function require_perm(string $k): void {
    require_login();
    if (!can($k)) { http_response_code(403); die('<div style="font-family:sans-serif;padding:40px"><h2>403 - Access denied</h2><p>You do not have permission to open this page.</p><a href="' . e(url('modules/dashboard/')) . '">Back to dashboard</a></div>'); }
}
function load_permissions(int $roleId): void {
    $_SESSION['perms'] = array_column(rows('SELECT p.permission_key FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = ?', [$roleId]), 'permission_key');
}

/* ---------- Rooms ---------- */
function room_state(array $r): array {
    $id = (int)$r['id'];
    if (($r['maintenance_status'] ?? 'active') !== 'active') return ['maintenance', 'Maintenance', 'dark'];
    if (val("SELECT 1 FROM monthly_tenants WHERE room_id=? AND tenant_status='active' LIMIT 1", [$id])) return ['monthly', 'Monthly Occupied', 'info'];
    if (val("SELECT 1 FROM booking_rooms WHERE room_id=? AND room_status='checked_in' LIMIT 1", [$id])) return ['occupied', 'Occupied', 'danger'];
    if (($r['cleaning_status'] ?? 'clean') !== 'clean') return ['cleaning', 'Needs Cleaning', 'warning'];
    if (val("SELECT 1 FROM booking_rooms WHERE room_id=? AND room_status='reserved' AND checkin_datetime <= DATE_ADD(NOW(), INTERVAL 1 DAY) AND checkout_datetime > NOW() LIMIT 1", [$id])) return ['reserved', 'Reserved', 'primary'];
    return ['available', 'Available', 'success'];
}
/** Returns the conflicting booking_room row, or null when the room is free for [in, out). */
function room_conflict(int $roomId, string $in, string $out, bool $lock = false, int $excludeBooking = 0): ?array {
    $sql = "SELECT br.*, b.booking_number FROM booking_rooms br JOIN bookings b ON b.id = br.booking_id
            WHERE br.room_id = ? AND br.booking_id <> {$excludeBooking} AND br.room_status IN ('reserved','checked_in') AND b.booking_status NOT IN ('cancelled','no_show','checked_out')
              AND ((? < br.checkout_datetime AND ? > br.checkin_datetime) OR (br.room_status = 'checked_in' AND ? > br.checkin_datetime))
            LIMIT 1" . ($lock ? ' FOR UPDATE' : '');
    return row($sql, [$roomId, $in, $out, $out]);
}

/* ---------- Invoices & payments ---------- */
function recalc_invoice(int $iid): void {
    $inv = row('SELECT * FROM invoices WHERE id=?', [$iid]);
    if (!$inv) return;
    $paid = (float)val('SELECT COALESCE(SUM(amount),0) FROM payments WHERE invoice_id=?', [$iid]);
    $rem = max(0, round((float)$inv['grand_total'] - $paid, 2));
    $open = $inv['invoice_type'] === 'room';
    if ($paid <= 0) $st = $open ? 'pending' : 'unpaid';
    elseif ($rem <= 0.009 && (float)$inv['grand_total'] > 0) $st = 'paid';
    else $st = 'partial';
    q('UPDATE invoices SET paid_amount=?, remaining_amount=?, invoice_status=? WHERE id=?', [$paid, $rem, $st, $iid]);
}
/** Rebuilds the single running invoice of a booking: rent + extra charges + room-service orders. */
function rebuild_invoice(int $bid): int {
    $b = row('SELECT * FROM bookings WHERE id=?', [$bid]);
    $inv = row("SELECT * FROM invoices WHERE booking_id=? AND invoice_type IN ('room','checkout') ORDER BY id LIMIT 1", [$bid]);
    if (!$inv) {
        q("INSERT INTO invoices (invoice_number, guest_id, booking_id, invoice_type, invoice_status, invoice_date, created_by) VALUES (?,?,?,'room','pending',NOW(),?)",
            [next_number('INV-', 'invoices'), $b['guest_id'], $bid, user()['id'] ?? null]);
        $iid = (int)db()->lastInsertId();
    } else $iid = (int)$inv['id'];
    q('DELETE FROM invoice_items WHERE invoice_id=?', [$iid]);
    $ins = db()->prepare('INSERT INTO invoice_items (invoice_id, description, item_type, reference_id, quantity, unit_price, total_price) VALUES (?,?,?,?,?,?,?)');
    $base = 0; $roomSub = 0; $ordersTotal = 0;
    foreach (rows("SELECT br.*, r.room_number FROM booking_rooms br JOIN rooms r ON r.id = br.room_id WHERE br.booking_id=? AND br.room_status <> 'cancelled'", [$bid]) as $x) {
        $n = nights_between($x['checkin_datetime'], $x['checkout_datetime']); $t = $n * (float)$x['room_rate'];
        $ins->execute([$iid, "Room {$x['room_number']} rent ($n night" . ($n > 1 ? 's' : '') . ")", 'room', $x['id'], $n, $x['room_rate'], $t]);
        $base += $t; $roomSub += $t;
    }
    foreach (rows('SELECT * FROM room_charges WHERE booking_id=? ORDER BY id', [$bid]) as $c) {
        $ins->execute([$iid, ucfirst(str_replace('_', ' ', $c['charge_type'])) . ($c['description'] ? ': ' . $c['description'] : ''), 'charge', $c['id'], $c['quantity'], $c['unit_price'], $c['total_amount']]);
        $base += (float)$c['total_amount'];
    }
    foreach (rows("SELECT * FROM orders WHERE booking_id=? AND order_type='room_service' AND order_status <> 'cancelled' ORDER BY id", [$bid]) as $o) {
        $ins->execute([$iid, 'Room service order ' . $o['order_number'], 'order', $o['id'], 1, $o['grand_total'], $o['grand_total']]);
        $ordersTotal += (float)$o['grand_total'];
    }
    $disc = min((float)$b['discount'], $base);
    $tax = round(($base - $disc) * (float)setting('tax_percent', 0) / 100, 2);
    $grand = round($base - $disc + $tax + $ordersTotal, 2);
    q('UPDATE invoices SET subtotal=?, discount=?, tax_amount=?, grand_total=? WHERE id=?', [$base + $ordersTotal, $disc, $tax, $grand, $iid]);
    q('UPDATE bookings SET room_total=?, tax_amount=?, grand_total=? WHERE id=?', [$roomSub, $tax, $grand, $bid]);
    recalc_invoice($iid);
    return $iid;
}
function record_payment(int $iid, float $amount, string $method, ?string $ref = null, ?string $notes = null): int {
    $inv = row('SELECT * FROM invoices WHERE id=?', [$iid]);
    if (!$inv) throw new RuntimeException('Invoice not found.');
    if ($amount <= 0) throw new RuntimeException('Amount must be greater than zero.');
    if ($amount > (float)$inv['remaining_amount'] + 0.009) throw new RuntimeException('Amount is more than the remaining balance (' . money($inv['remaining_amount']) . ').');
    q('INSERT INTO payments (payment_number, invoice_id, amount, payment_method, transaction_reference, payment_date, received_by, notes) VALUES (?,?,?,?,?,NOW(),?,?)',
        [next_number('PAY-', 'payments'), $iid, $amount, $method, $ref ?: null, user()['id'] ?? null, $notes]);
    $pid = (int)db()->lastInsertId();
    recalc_invoice($iid);
    // restaurant invoice fully paid -> close the order and free the table
    $ord = row('SELECT id, table_id FROM orders WHERE invoice_id=?', [$iid]);
    if ($ord && val('SELECT invoice_status FROM invoices WHERE id=?', [$iid]) === 'paid') {
        q("UPDATE orders SET order_status='completed' WHERE id=?", [$ord['id']]);
        if ($ord['table_id'] && !val("SELECT 1 FROM orders WHERE table_id=? AND order_status='open' LIMIT 1", [$ord['table_id']])) q("UPDATE restaurant_tables SET status='available' WHERE id=?", [$ord['table_id']]);
    }
    audit('payment', 'payments', $pid, "Received $amount on invoice {$inv['invoice_number']}");
    return $pid;
}
function guest_code(): string { return next_number('G-', 'guests'); }

/** Creates (once) the restaurant invoice of a dine-in / takeaway order. */
function ensure_order_invoice(int $oid): int {
    $o = row('SELECT * FROM orders WHERE id=?', [$oid]);
    if (!$o) throw new RuntimeException('Order not found.');
    if ($o['invoice_id']) return (int)$o['invoice_id'];
    q("INSERT INTO invoices (invoice_number, guest_id, invoice_type, subtotal, discount, tax_amount, service_charges, grand_total, remaining_amount, invoice_status, invoice_date, created_by) VALUES (?,?,?,?,?,?,?,?,?,'unpaid',NOW(),?)",
        [next_number('INV-', 'invoices'), $o['guest_id'], 'restaurant', $o['subtotal'], $o['discount'], $o['tax'], $o['service_charges'], $o['grand_total'], $o['grand_total'], user()['id'] ?? null]);
    $iid = (int)db()->lastInsertId();
    foreach (rows('SELECT * FROM order_items WHERE order_id=?', [$oid]) as $x) {
        $ad = array_column(rows('SELECT addon_name FROM order_item_addons WHERE order_item_id=?', [$x['id']]), 'addon_name');
        q('INSERT INTO invoice_items (invoice_id, description, item_type, reference_id, quantity, unit_price, total_price) VALUES (?,?,?,?,?,?,?)',
            [$iid, $x['item_name'] . ($ad ? ' + ' . implode(', ', $ad) : ''), 'food', $x['id'], $x['quantity'], $x['unit_price'], $x['total_price']]);
    }
    q('UPDATE orders SET invoice_id=? WHERE id=?', [$iid, $oid]);
    return $iid;
}
